"""
Ablation Baseline: Basic Retinex without ECCV innovations

This is the baseline for ablation study:
- Basic illumination estimator only
- No Map-Element-Aware illumination
- No Query-Guided illumination
"""

_base_ = ['./retinex_maptr_tiny_r50_24ep.py']

# Override retinex config for baseline
retinex_cfg = dict(
    n_fea_middle=40,
    fusion_type='add',
    neck_out_channels=256,
    with_mvb_loss=True,
    overlap_ratio=0.125,
    mvb_loss_weight=0.1,
    num_views=6,
    # ========== Disable all innovations ==========
    use_map_element_aware=False,  # OFF
    use_query_guided=False,        # OFF
    use_query_guided_v2=False,
    element_loss_weight=0.0,
    num_heads=4,
    bank_size=100,
)

model = dict(
    retinex_cfg=retinex_cfg,
)
