"""
Map-Aware Light Adaptation for Robust HD Map Construction

===============================================================================
训练原理：Zero-DCE 如何学习"光照自适应"
===============================================================================

训练流程：
    原图 ──> 人工光照扰动 ──> Zero-DCE 增强 ──> MapTR 检测 ──> 检测损失
                │                     │
                └──── 结构约束损失 ────┘  (保护结构，不破坏 Map 元素)
                └──── Map 感知损失 ────┘  (针对 Map 元素的特殊保护)

Zero-DCE 通过两种监督信号学习：
1. 【检测损失】反向传播到 Zero-DCE，告诉它 "什么样的光照调整对检测有利"
2. 【结构损失】告诉 Zero-DCE "调整光照时不要破坏重要结构"

推理流程：
    任意光照图像 ──> Zero-DCE 自适应调整 ──> MapTR 检测 ──> 输出
    
因为训练时 Zero-DCE 学会了：
- 对暗图像：适当增亮（因为人工扰动包含变暗，增亮后检测效果更好）
- 对亮图像：适当降亮（因为人工扰动包含过曝，降亮后检测效果更好）
- 对正常图像：保持不变（Identity Loss 约束）
所以推理时它能自适应处理各种光照条件！

===============================================================================
核心创新（双层 Map 元素感知约束）
===============================================================================

方向1 - Map 元素类别感知约束（不同元素用不同保护策略）:
   - 车道线 (divider): 边缘约束（Sobel 保护线性边缘）
   - 人行横道 (ped_crossing): 纹理约束（Gabor 保护周期性条纹）
   - 道路边界 (boundary): 形状约束（Laplacian 保护边界轮廓）

方向3 - Map 几何先验约束（利用 Map 元素的固有几何特性）:
   - 车道线: 平行约束（方向场一致性）
   - 人行横道: 周期约束（FFT 幅度谱一致性）
   - 道路边界: 平滑约束（二阶梯度一致性）

基础结构保护约束:
   - 边缘一致性: 保护边界
   - 结构相似度 (SSIM): 保护整体结构
   - 相位一致性: 保护几何结构 (参考 FDA)
   - 高频保护: 保护纹理细节

训练命令：
    ./tools/dist_train.sh projects/configs/maptr/maptr_tiny_r50_24e_light_enhance.py 8
"""

_base_ = [
    '../datasets/custom_nus-3d.py',
    '../_base_/default_runtime.py'
]

plugin = True
plugin_dir = 'projects/mmdet3d_plugin/'

# Point Cloud Range
point_cloud_range = [-15.0, -30.0, -2.0, 15.0, 30.0, 2.0]
voxel_size = [0.15, 0.15, 4]

# 图像归一化配置（重要：模型中会用到进行反归一化）
img_norm_cfg = dict(
    mean=[123.675, 116.28, 103.53], std=[58.395, 57.12, 57.375], to_rgb=True)

# 类别定义
class_names = [
    'car', 'truck', 'construction_vehicle', 'bus', 'trailer', 'barrier',
    'motorcycle', 'bicycle', 'pedestrian', 'traffic_cone'
]
map_classes = ['divider', 'ped_crossing', 'boundary']
fixed_ptsnum_per_gt_line = 20
fixed_ptsnum_per_pred_line = 20
eval_use_same_gt_sample_num_flag = True
num_map_classes = len(map_classes)

input_modality = dict(
    use_lidar=False,
    use_camera=True,
    use_radar=False,
    use_map=False,
    use_external=True)

# 模型维度配置
_dim_ = 256
_pos_dim_ = _dim_ // 2
_ffn_dim_ = _dim_ * 2
_num_levels_ = 1
bev_h_ = 200
bev_w_ = 100
queue_length = 1

# ==================== 模型配置 ====================
model = dict(
    type='LightEnhanceMapTR',
    
    # ===== 光照增强配置 =====
    # 传入 img_norm_cfg，用于在模型内部进行归一化/反归一化
    img_norm_cfg=img_norm_cfg,
    
    # 增强器配置
    enhancer=dict(
        type='ZeroDCE',
        in_channels=3,
        hidden_channels=32,
        n_iter=8,
    ),
    
    # GPU 扰动配置
    perturb_cfg=dict(
        perturb_prob=0.8,         # 扰动概率
        identity_prob=0.2,        # 保持不变概率
        darken_range=(0.3, 0.7),  # 变暗范围
        brighten_range=(1.2, 1.8),# 变亮范围
        gamma_range=(0.5, 2.0),   # Gamma 范围
        noise_std_range=(0.02, 0.08),  # 噪声标准差范围
    ),
    
    # 一致性学习配置（已禁用 Teacher-Student，节省显存）
    use_consistency_training=False,
    consistency_weight=1.0,
    identity_weight=0.1,
    enhance_loss_weight=0.1,
    feature_consistency_layer='neck',
    
    # ===== 基础结构保护约束 =====
    use_structure_loss=True,  # 自监督结构约束
    structure_loss_weight=0.5,
    structure_loss_cfg=dict(
        use_edge_loss=True,      # 边缘一致性（保护边界）
        use_ssim_loss=True,      # 结构相似度（保护整体结构）
        use_phase_loss=True,     # 相位一致性（保护几何结构，参考 FDA）
        use_freq_loss=True,      # 高频保护（保护纹理细节）
        edge_weight=1.0,
        ssim_weight=1.0,
        phase_weight=0.5,
        freq_weight=0.5,
        ssim_window_size=11,
        low_freq_ratio=0.1,
    ),
    
    # ===== 核心创新：Map 元素感知的双层约束 =====
    use_map_aware_loss=True,  # Map-Aware 自监督约束
    map_aware_loss_weight=1.0,
    map_aware_loss_cfg=dict(
        # 方向1：类别感知约束（不同 Map 元素使用不同保护策略）
        use_category_loss=True,
        num_classes=3,                # divider, ped_crossing, boundary
        lane_weight=1.0,              # 车道线边缘约束（Sobel）
        crossing_weight=1.0,          # 人行横道纹理约束（Gabor）
        boundary_weight=1.0,          # 道路边界形状约束（Laplacian）
        
        # 方向3：几何先验约束（利用 Map 元素固有几何特性）
        use_geometry_loss=True,
        parallel_weight=1.0,          # 车道线平行约束（方向场一致性）
        smoothness_weight=1.0,        # 道路边界平滑约束（二阶梯度）
        periodicity_weight=1.0,       # 人行横道周期约束（FFT）
        
        # 总权重
        category_loss_weight=1.0,     # 类别感知损失总权重
        geometry_loss_weight=1.0,     # 几何先验损失总权重
    ),
    
    # ===== MapTR 原有配置 =====
    use_grid_mask=True,
    video_test_mode=False,
    pretrained=dict(img='ckpts/resnet50-19c8e357.pth'),
    
    img_backbone=dict(
        type='ResNet',
        depth=50,
        num_stages=4,
        out_indices=(3,),
        frozen_stages=1,
        norm_cfg=dict(type='BN', requires_grad=False),
        norm_eval=True,
        style='pytorch'),
    
    img_neck=dict(
        type='FPN',
        in_channels=[2048],
        out_channels=_dim_,
        start_level=0,
        add_extra_convs='on_output',
        num_outs=_num_levels_,
        relu_before_extra_convs=True),
    
    pts_bbox_head=dict(
        type='MapTRHead',
        bev_h=bev_h_,
        bev_w=bev_w_,
        num_query=900,
        num_vec=50,
        num_pts_per_vec=fixed_ptsnum_per_pred_line,
        num_pts_per_gt_vec=fixed_ptsnum_per_gt_line,
        dir_interval=1,
        query_embed_type='instance_pts',
        transform_method='minmax',
        gt_shift_pts_pattern='v2',
        num_classes=num_map_classes,
        in_channels=_dim_,
        sync_cls_avg_factor=True,
        with_box_refine=True,
        as_two_stage=False,
        code_size=2,
        code_weights=[1.0, 1.0, 1.0, 1.0],
        transformer=dict(
            type='MapTRPerceptionTransformer',
            rotate_prev_bev=True,
            use_shift=True,
            use_can_bus=True,
            embed_dims=_dim_,
            encoder=dict(
                type='BEVFormerEncoder',
                num_layers=1,
                pc_range=point_cloud_range,
                num_points_in_pillar=4,
                return_intermediate=False,
                transformerlayers=dict(
                    type='BEVFormerLayer',
                    attn_cfgs=[
                        dict(
                            type='TemporalSelfAttention',
                            embed_dims=_dim_,
                            num_levels=1),
                        dict(
                            type='GeometrySptialCrossAttention',
                            pc_range=point_cloud_range,
                            attention=dict(
                                type='GeometryKernelAttention',
                                embed_dims=_dim_,
                                num_heads=4,
                                dilation=1,
                                kernel_size=(3, 5),
                                num_levels=_num_levels_),
                            embed_dims=_dim_,
                        )
                    ],
                    feedforward_channels=_ffn_dim_,
                    ffn_dropout=0.1,
                    operation_order=('self_attn', 'norm', 'cross_attn', 'norm',
                                     'ffn', 'norm'))),
            decoder=dict(
                type='MapTRDecoder',
                num_layers=6,
                return_intermediate=True,
                transformerlayers=dict(
                    type='DetrTransformerDecoderLayer',
                    attn_cfgs=[
                        dict(
                            type='MultiheadAttention',
                            embed_dims=_dim_,
                            num_heads=8,
                            dropout=0.1),
                        dict(
                            type='CustomMSDeformableAttention',
                            embed_dims=_dim_,
                            num_levels=1),
                    ],
                    feedforward_channels=_ffn_dim_,
                    ffn_dropout=0.1,
                    operation_order=('self_attn', 'norm', 'cross_attn', 'norm',
                                     'ffn', 'norm')))),
        bbox_coder=dict(
            type='MapTRNMSFreeCoder',
            post_center_range=[-20, -35, -20, -35, 20, 35, 20, 35],
            pc_range=point_cloud_range,
            max_num=50,
            voxel_size=voxel_size,
            num_classes=num_map_classes),
        positional_encoding=dict(
            type='LearnedPositionalEncoding',
            num_feats=_pos_dim_,
            row_num_embed=bev_h_,
            col_num_embed=bev_w_,
        ),
        loss_cls=dict(
            type='FocalLoss',
            use_sigmoid=True,
            gamma=2.0,
            alpha=0.25,
            loss_weight=2.0),
        loss_bbox=dict(type='L1Loss', loss_weight=0.0),
        loss_iou=dict(type='GIoULoss', loss_weight=0.0),
        loss_pts=dict(type='PtsL1Loss', loss_weight=5.0),
        loss_dir=dict(type='PtsDirCosLoss', loss_weight=0.005)),
    
    train_cfg=dict(pts=dict(
        grid_size=[512, 512, 1],
        voxel_size=voxel_size,
        point_cloud_range=point_cloud_range,
        out_size_factor=4,
        assigner=dict(
            type='MapTRAssigner',
            cls_cost=dict(type='FocalLossCost', weight=2.0),
            reg_cost=dict(type='BBoxL1Cost', weight=0.0, box_format='xywh'),
            iou_cost=dict(type='IoUCost', iou_mode='giou', weight=0.0),
            pts_cost=dict(type='OrderedPtsL1Cost', weight=5),
            pc_range=point_cloud_range))))


# ==================== 数据配置 ====================
dataset_type = 'CustomNuScenesLocalMapDataset'
data_root = 'data/nuscenes/'
file_client_args = dict(backend='disk')

# ===== 训练 Pipeline（标准流程，无需额外的光照扰动）=====
train_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=True),
    dict(type='PhotoMetricDistortionMultiViewImage'),
    dict(type='LoadAnnotations3D', with_bbox_3d=True, with_label_3d=True, with_attr_label=False),
    dict(type='ObjectRangeFilter', point_cloud_range=point_cloud_range),
    dict(type='ObjectNameFilter', classes=class_names),
    dict(type='NormalizeMultiviewImage', **img_norm_cfg),
    dict(type='RandomScaleImageMultiViewImage', scales=[0.5]),
    dict(type='PadMultiViewImage', size_divisor=32),
    dict(type='DefaultFormatBundle3D', class_names=class_names),
    dict(type='CustomCollect3D', keys=['gt_bboxes_3d', 'gt_labels_3d', 'img'])
]

# ===== 测试 Pipeline =====
test_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=True),
    dict(type='NormalizeMultiviewImage', **img_norm_cfg),
    dict(
        type='MultiScaleFlipAug3D',
        img_scale=(1600, 900),
        pts_scale_ratio=1,
        flip=False,
        transforms=[
            dict(type='RandomScaleImageMultiViewImage', scales=[0.5]),
            dict(type='PadMultiViewImage', size_divisor=32),
            dict(
                type='DefaultFormatBundle3D',
                class_names=class_names,
                with_label=False),
            dict(type='CustomCollect3D', keys=['img'])
        ])
]

data = dict(
    samples_per_gpu=4,  # 无 Teacher 后显存充足，可用 4
    workers_per_gpu=4,
    train=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file=data_root + 'nuscenes_infos_temporal_train.pkl',
        pipeline=train_pipeline,
        classes=class_names,
        modality=input_modality,
        test_mode=False,
        use_valid_flag=True,
        bev_size=(bev_h_, bev_w_),
        pc_range=point_cloud_range,
        fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
        eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
        padding_value=-10000,
        map_classes=map_classes,
        queue_length=queue_length,
        box_type_3d='LiDAR'),
    val=dict(type=dataset_type,
             data_root=data_root,
             ann_file=data_root + 'nuscenes_infos_temporal_val.pkl',
             map_ann_file=data_root + 'nuscenes_map_anns_val.json',
             pipeline=test_pipeline, bev_size=(bev_h_, bev_w_),
             pc_range=point_cloud_range,
             fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
             eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
             padding_value=-10000,
             map_classes=map_classes,
             classes=class_names, modality=input_modality, samples_per_gpu=1),
    test=dict(type=dataset_type,
              data_root=data_root,
              ann_file=data_root + 'nuscenes_infos_temporal_val.pkl',
              map_ann_file=data_root + 'nuscenes_map_anns_val.json',
              pipeline=test_pipeline, bev_size=(bev_h_, bev_w_),
              pc_range=point_cloud_range,
              fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
              eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
              padding_value=-10000,
              map_classes=map_classes,
              classes=class_names, modality=input_modality),
    shuffler_sampler=dict(type='DistributedGroupSampler'),
    nonshuffler_sampler=dict(type='DistributedSampler')
)

# ==================== 优化器配置 ====================
optimizer = dict(
    type='AdamW',
    lr=6e-4,
    paramwise_cfg=dict(
        custom_keys={
            'img_backbone': dict(lr_mult=0.1),
            'enhancer': dict(lr_mult=1.0),
        }),
    weight_decay=0.01)

optimizer_config = dict(grad_clip=dict(max_norm=35, norm_type=2))

lr_config = dict(
    policy='CosineAnnealing',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=1.0 / 3,
    min_lr_ratio=1e-3)

total_epochs = 24
evaluation = dict(interval=2, pipeline=test_pipeline, metric='chamfer')

runner = dict(type='EpochBasedRunner', max_epochs=total_epochs)

log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook'),
        dict(type='TensorboardLoggerHook')
    ])

fp16 = dict(loss_scale=512.)
checkpoint_config = dict(interval=1)
