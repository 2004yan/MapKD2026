"""
Retinex-MapTR: Illumination-aware HD Map Construction.

Based on Retinex-BEVFormer paper, this integrates Retinex illumination
estimation into MapTR for robust night-time map construction.

Key innovations:
1. Illumination Estimator: Extract illumination features from multi-view images
2. MVB-Retinex: Multi-view illumination consistency across camera overlaps
3. Feature Fusion: Combine illumination features with backbone features

ECCV-level Innovations (Ablation switches available):
4. Map-Element-Aware Illumination: Different processing for different map elements
5. Query-Guided Illumination: Use MapTR queries to guide illumination retrieval
"""

import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet.models import DETECTORS
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
from projects.mmdet3d_plugin.models.utils.grid_mask import GridMask
from mmcv.runner import force_fp32, auto_fp16
from mmdet3d.ops import Voxelization, DynamicScatter
from mmdet3d.models import builder

from projects.mmdet3d_plugin.models.enhancers.retinex_bev import (
    IlluminationEstimator,
    MVBRetinex,
    RetinexBEVFusion,
    MapElementAwareIllumination,
    QueryGuidedIllumination,
    QueryGuidedIlluminationV2,
    RetinexMapTREnhancement
)


@DETECTORS.register_module()
class RetinexMapTR(MVXTwoStageDetector):
    """
    MapTR with Retinex illumination enhancement.
    
    The illumination information serves as an informational gain,
    enabling the BEV detector to learn illumination features without
    requiring any extra brightness map ground truth for supervision.
    """
    
    def __init__(self,
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 video_test_mode=False,
                 modality='vision',
                 lidar_encoder=None,
                 # Retinex specific parameters
                 retinex_cfg=None,
                 # 【关键】图像归一化配置 - 用于反归一化
                 img_norm_cfg=None,
                 ):
        
        super(RetinexMapTR, self).__init__(
            pts_voxel_layer, pts_voxel_encoder,
            pts_middle_encoder, pts_fusion_layer,
            img_backbone, pts_backbone, img_neck, pts_neck,
            pts_bbox_head, img_roi_head, img_rpn_head,
            train_cfg, test_cfg, pretrained
        )
        
        self.grid_mask = GridMask(
            True, True, rotate=1, offset=False, ratio=0.5, mode=1, prob=0.7)
        self.use_grid_mask = use_grid_mask
        self.fp16_enabled = False
        
        # Temporal
        self.video_test_mode = video_test_mode
        self.prev_frame_info = {
            'prev_bev': None,
            'scene_token': None,
            'prev_pos': 0,
            'prev_angle': 0,
        }
        self.modality = modality
        
        # ============ 【关键修复】图像归一化配置 ============
        # Retinex 需要原始图像 [0, 255] 范围，而输入是归一化后的
        # 必须反归一化后才能正确提取 illumination prior
        if img_norm_cfg is None:
            img_norm_cfg = dict(
                mean=[123.675, 116.28, 103.53],
                std=[58.395, 57.12, 57.375],
                to_rgb=True
            )
        self.img_norm_cfg = img_norm_cfg
        
        # 注册为 buffer，用于反归一化（自动处理 GPU/CPU）
        self.register_buffer('img_mean', 
            torch.tensor(img_norm_cfg['mean']).view(1, 3, 1, 1))
        self.register_buffer('img_std', 
            torch.tensor(img_norm_cfg['std']).view(1, 3, 1, 1))
        
        # Lidar encoder (optional)
        if self.modality == 'fusion' and lidar_encoder is not None:
            if lidar_encoder["voxelize"].get("max_num_points", -1) > 0:
                voxelize_module = Voxelization(**lidar_encoder["voxelize"])
            else:
                voxelize_module = DynamicScatter(**lidar_encoder["voxelize"])
            self.lidar_modal_extractor = nn.ModuleDict({
                "voxelize": voxelize_module,
                "backbone": builder.build_middle_encoder(lidar_encoder["backbone"]),
            })
            self.voxelize_reduce = lidar_encoder.get("voxelize_reduce", True)
        
        # ============ Retinex Modules ============
        # Default retinex config
        if retinex_cfg is None:
            retinex_cfg = dict(
                n_fea_middle=40,
                fusion_type='add',
                with_mvb_loss=True,
                overlap_ratio=0.125,
                mvb_loss_weight=0.1,
                # ECCV Innovation switches (for ablation)
                use_map_element_aware=False,
                use_query_guided=False,
                use_query_guided_v2=False,
            )
        
        self.retinex_cfg = retinex_cfg
        
        # Number of views (6 for nuScenes)
        self.num_views = retinex_cfg.get('num_views', 6)
        
        # Loss weights
        self.mvb_loss_weight = retinex_cfg.get('mvb_loss_weight', 0.1)
        self.element_loss_weight = retinex_cfg.get('element_loss_weight', 0.05)
        
        # Ablation switches
        self.use_map_element_aware = retinex_cfg.get('use_map_element_aware', False)
        self.use_query_guided = retinex_cfg.get('use_query_guided', False)
        self.use_query_guided_v2 = retinex_cfg.get('use_query_guided_v2', False)
        self.with_mvb_loss = retinex_cfg.get('with_mvb_loss', True)
        
        # Get neck output channels (typically 256 for FPN)
        neck_out_channels = retinex_cfg.get('neck_out_channels', 256)
        n_fea_middle = retinex_cfg.get('n_fea_middle', 40)
        
        # ============ Build Retinex Enhancement Module ============
        # Use the combined module that supports all innovations
        self.retinex_enhancement = RetinexMapTREnhancement(
            n_fea_middle=n_fea_middle,
            query_channels=neck_out_channels,
            num_map_classes=3,  # divider, ped_crossing, boundary
            num_heads=retinex_cfg.get('num_heads', 4),
            bank_size=retinex_cfg.get('bank_size', 100),
            fusion_type=retinex_cfg.get('fusion_type', 'add'),
            overlap_ratio=retinex_cfg.get('overlap_ratio', 0.125),
            # Ablation switches
            use_map_element_aware=self.use_map_element_aware,
            use_query_guided=self.use_query_guided,
            use_query_guided_v2=self.use_query_guided_v2,
            use_mvb_loss=self.with_mvb_loss,
        )
        
        # 注意：不要创建模块别名引用，会导致参数重复注册！
        # 如果需要访问子模块，直接通过 self.retinex_enhancement.xxx 访问
    
    def denormalize_img(self, img):
        """
        【关键】反归一化图像，恢复到原始 [0, 255] 范围。
        
        Retinex 理论要求：
        - illumination prior Lp = mean(I, channel) 需要原始亮度信息
        - 归一化后的图像 mean 接近 0，无法正确估计光照
        
        Args:
            img: 归一化后的图像 [B, 3, H, W]，值范围约 [-2, 3]
        
        Returns:
            img_denorm: 原始图像 [B, 3, H, W]，值范围 [0, 255]
        """
        # img_normalized = (img_original - mean) / std
        # img_original = img_normalized * std + mean
        img_denorm = img * self.img_std + self.img_mean
        return img_denorm
    
    def normalize_img(self, img):
        """
        归一化图像，用于送入 backbone。
        
        Args:
            img: 原始图像 [B, 3, H, W]，值范围 [0, 255]
        
        Returns:
            img_norm: 归一化图像 [B, 3, H, W]
        """
        img_norm = (img - self.img_mean) / self.img_std
        return img_norm
    
    def extract_illu_feat(self, img):
        """
        Extract illumination features from multi-view images.
        
        【关键】必须先反归一化图像！
        
        Retinex 理论要求原始图像亮度信息：
        - illumination prior Lp = mean(I, channel)
        - 如果输入是归一化的，mean 接近 0，无法正确估计光照
        
        Uses the combined RetinexMapTREnhancement module which supports:
        - Basic illumination estimation
        - Map-Element-Aware enhancement (if enabled)
        
        Args:
            img: [B*N, 3, H, W] 归一化后的图像
        
        Returns:
            illu_fea: Illumination features [B*N, C, H, W]
            illu_map: Illumination map [B*N, 3, H, W]
            element_feas: Element-specific features (if use_map_element_aware)
        """
        # 【关键修复】反归一化图像，恢复原始亮度信息
        img_denorm = self.denormalize_img(img)
        
        # 将值范围从 [0, 255] 归一化到 [0, 1]，这是 Retinex 标准输入
        img_for_retinex = img_denorm / 255.0
        
        # 使用原始亮度图像提取光照特征
        illu_fea, illu_map, element_feas = self.retinex_enhancement.extract_illumination(img_for_retinex)
        return illu_fea, illu_map, element_feas
    
    def compute_mvb_loss(self, illu_fea, batch_size):
        """
        Compute multi-view balanced Retinex consistency loss.
        
        Args:
            illu_fea: [B*N, C, H, W] illumination features
            batch_size: Batch size B
        
        Returns:
            mvb_loss: Consistency loss
        """
        if not self.with_mvb_loss:
            return torch.tensor(0.0, device=illu_fea.device)
        
        return self.retinex_enhancement.compute_mvb_loss(illu_fea, num_views=self.num_views)
    
    def extract_img_feat(self, img, img_metas, len_queue=None):
        """
        Extract features of images with illumination enhancement.
        
        Flow:
        1. Extract illumination features from raw images
           - Basic illumination estimation
           - Map-Element-Aware enhancement (if enabled)
        2. Run backbone to get image features
        3. Run neck to get multi-scale features
        4. Fuse illumination features with neck output
        """
        B = img.size(0)
        if img is not None:
            if img.dim() == 5 and img.size(0) == 1:
                img.squeeze_()
            elif img.dim() == 5 and img.size(0) > 1:
                B, N, C, H, W = img.size()
                img = img.reshape(B * N, C, H, W)
            
            # ============ Step 1: Extract illumination features ============
            # Before grid mask, extract illumination from original images
            # This now supports Map-Element-Aware enhancement
            illu_fea, illu_map, element_feas = self.extract_illu_feat(img)
            
            # Store for MVB loss and element loss computation later
            self._current_illu_fea = illu_fea
            self._current_illu_map = illu_map
            self._current_element_feas = element_feas
            self._current_batch_size = B
            
            # ============ Step 2: Apply grid mask (optional) ============
            if self.use_grid_mask:
                img = self.grid_mask(img)
            
            # ============ Step 3: Backbone ============
            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None
        
        # ============ Step 4: Neck ============
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        
        # ============ Step 5: Fuse illumination with features ============
        # Fuse with the finest scale feature (first one in FPN output)
        img_feats_fused = []
        for i, img_feat in enumerate(img_feats):
            if i == 0:  # Only fuse with finest scale
                fused = self.retinex_enhancement.fuse_features(img_feat, illu_fea)
                img_feats_fused.append(fused)
            else:
                img_feats_fused.append(img_feat)
        img_feats = img_feats_fused
        
        # ============ Step 6: Reshape ============
        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            if len_queue is not None:
                img_feats_reshaped.append(
                    img_feat.view(int(B / len_queue), len_queue, int(BN / B), C, H, W)
                )
            else:
                img_feats_reshaped.append(
                    img_feat.view(B, int(BN / B), C, H, W)
                )
        
        return img_feats_reshaped
    
    @auto_fp16(apply_to=('img'), out_fp32=True)
    def extract_feat(self, img, img_metas=None, len_queue=None):
        """Extract features from images and points."""
        img_feats = self.extract_img_feat(img, img_metas, len_queue=len_queue)
        return img_feats
    
    def forward_pts_train(self,
                          pts_feats,
                          lidar_feat,
                          gt_bboxes_3d,
                          gt_labels_3d,
                          img_metas,
                          gt_bboxes_ignore=None,
                          prev_bev=None,
                          illu_fea=None):
        """
        Forward function for point cloud branch.
        
        If use_query_guided is enabled, this will enhance the queries
        with illumination information before detection.
        """
        # Standard forward through pts_bbox_head
        # Note: Query-Guided enhancement happens inside the head if needed
        # We pass illu_fea for potential query enhancement
        outs = self.pts_bbox_head(pts_feats, lidar_feat, img_metas, prev_bev)
        
        # If query-guided is enabled and we have access to queries,
        # we can enhance them. However, this requires modifying the head.
        # For now, the enhancement happens at the feature fusion level.
        # A more advanced version would modify MapTRHead to accept illu_fea.
        
        loss_inputs = [gt_bboxes_3d, gt_labels_3d, outs]
        losses = self.pts_bbox_head.loss(*loss_inputs, img_metas=img_metas)
        return losses, outs
    
    def forward_dummy(self, img):
        dummy_metas = None
        return self.forward_test(img=img, img_metas=[[dummy_metas]])
    
    def forward(self, return_loss=True, **kwargs):
        if return_loss:
            return self.forward_train(**kwargs)
        else:
            return self.forward_test(**kwargs)
    
    def obtain_history_bev(self, imgs_queue, img_metas_list):
        """Obtain history BEV features iteratively."""
        self.eval()
        with torch.no_grad():
            prev_bev = None
            bs, len_queue, num_cams, C, H, W = imgs_queue.shape
            imgs_queue = imgs_queue.reshape(bs * len_queue, num_cams, C, H, W)
            img_feats_list = self.extract_feat(img=imgs_queue, len_queue=len_queue)
            for i in range(len_queue):
                img_metas = [each[i] for each in img_metas_list]
                if not img_metas[0]['prev_bev_exists']:
                    prev_bev = None
                img_feats = [each_scale[:, i] for each_scale in img_feats_list]
                prev_bev = self.pts_bbox_head(
                    img_feats, None, img_metas, prev_bev, only_bev=True)
            self.train()
            return prev_bev
    
    @torch.no_grad()
    @force_fp32()
    def voxelize(self, points):
        feats, coords, sizes = [], [], []
        for k, res in enumerate(points):
            ret = self.lidar_modal_extractor["voxelize"](res)
            if len(ret) == 3:
                f, c, n = ret
            else:
                assert len(ret) == 2
                f, c = ret
                n = None
            feats.append(f)
            coords.append(F.pad(c, (1, 0), mode="constant", value=k))
            if n is not None:
                sizes.append(n)
        
        feats = torch.cat(feats, dim=0)
        coords = torch.cat(coords, dim=0)
        if len(sizes) > 0:
            sizes = torch.cat(sizes, dim=0)
            if self.voxelize_reduce:
                feats = feats.sum(dim=1, keepdim=False) / sizes.type_as(feats).view(-1, 1)
                feats = feats.contiguous()
        
        return feats, coords, sizes
    
    @auto_fp16(apply_to=('points'), out_fp32=True)
    def extract_lidar_feat(self, points):
        feats, coords, sizes = self.voxelize(points)
        batch_size = coords[-1, 0] + 1
        lidar_feat = self.lidar_modal_extractor["backbone"](
            feats, coords, batch_size, sizes=sizes)
        return lidar_feat
    
    @force_fp32(apply_to=('img', 'points', 'prev_bev'))
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      ):
        """
        Forward training function with illumination enhancement losses.
        
        Losses:
        - Detection losses (from MapTR head)
        - MVB consistency loss (multi-view illumination consistency)
        - Element diversity loss (encourage different element branches to specialize)
        """
        lidar_feat = None
        if self.modality == 'fusion':
            lidar_feat = self.extract_lidar_feat(points)
        
        len_queue = img.size(1)
        prev_img = img[:, :-1, ...]
        img = img[:, -1, ...]
        
        prev_img_metas = copy.deepcopy(img_metas)
        prev_bev = self.obtain_history_bev(prev_img, prev_img_metas) if len_queue > 1 else None
        
        img_metas = [each[len_queue - 1] for each in img_metas]
        if not img_metas[0]['prev_bev_exists']:
            prev_bev = None
        
        # Extract features (illumination features stored in self._current_illu_fea)
        img_feats = self.extract_feat(img=img, img_metas=img_metas)
        
        losses = dict()
        
        # ============ MVB Consistency Loss ============
        if self.with_mvb_loss and hasattr(self, '_current_illu_fea'):
            mvb_loss = self.compute_mvb_loss(
                self._current_illu_fea, 
                self._current_batch_size
            )
            losses['loss_mvb_consistency'] = mvb_loss * self.mvb_loss_weight
        
        # ============ Element Diversity Loss (for Map-Element-Aware) ============
        if self.use_map_element_aware and hasattr(self, '_current_element_feas'):
            element_feas = self._current_element_feas
            if element_feas is not None:
                # Encourage element branches to produce diverse features
                # Use negative cosine similarity between branch outputs
                lane_fea = element_feas['lane']
                crossing_fea = element_feas['crossing']
                boundary_fea = element_feas['boundary']
                
                # Global average pool
                lane_global = F.adaptive_avg_pool2d(lane_fea, 1).flatten(1)
                crossing_global = F.adaptive_avg_pool2d(crossing_fea, 1).flatten(1)
                boundary_global = F.adaptive_avg_pool2d(boundary_fea, 1).flatten(1)
                
                # Cosine similarity (we want them to be different, so minimize similarity)
                cos_lc = F.cosine_similarity(lane_global, crossing_global, dim=1).mean()
                cos_lb = F.cosine_similarity(lane_global, boundary_global, dim=1).mean()
                cos_cb = F.cosine_similarity(crossing_global, boundary_global, dim=1).mean()
                
                # Diversity loss: encourage negative correlation
                diversity_loss = (cos_lc + cos_lb + cos_cb) / 3.0
                losses['loss_element_diversity'] = diversity_loss * self.element_loss_weight
        
        # ============ Detection Losses ============
        losses_pts, outs = self.forward_pts_train(
            img_feats, lidar_feat, gt_bboxes_3d,
            gt_labels_3d, img_metas,
            gt_bboxes_ignore, prev_bev,
            illu_fea=self._current_illu_fea if hasattr(self, '_current_illu_fea') else None
        )
        losses.update(losses_pts)
        
        # ============ Query-Guided Loss (optional) ============
        # If query-guided is enabled and we have query outputs,
        # we can add additional supervision
        if self.use_query_guided and 'query_embed' in outs:
            # This would require more complex integration with the head
            # For now, the query-guided enhancement is done at feature level
            pass
        
        return losses
    
    def forward_test(self, img_metas, img=None, points=None, **kwargs):
        for var, name in [(img_metas, 'img_metas')]:
            if not isinstance(var, list):
                raise TypeError('{} must be a list, but got {}'.format(name, type(var)))
        
        img = [img] if img is None else img
        points = [points] if points is None else points
        
        if img_metas[0][0]['scene_token'] != self.prev_frame_info['scene_token']:
            self.prev_frame_info['prev_bev'] = None
        self.prev_frame_info['scene_token'] = img_metas[0][0]['scene_token']
        
        if not self.video_test_mode:
            self.prev_frame_info['prev_bev'] = None
        
        tmp_pos = copy.deepcopy(img_metas[0][0]['can_bus'][:3])
        tmp_angle = copy.deepcopy(img_metas[0][0]['can_bus'][-1])
        if self.prev_frame_info['prev_bev'] is not None:
            img_metas[0][0]['can_bus'][:3] -= self.prev_frame_info['prev_pos']
            img_metas[0][0]['can_bus'][-1] -= self.prev_frame_info['prev_angle']
        else:
            img_metas[0][0]['can_bus'][-1] = 0
            img_metas[0][0]['can_bus'][:3] = 0
        
        new_prev_bev, bbox_results = self.simple_test(
            img_metas[0], img[0], points[0], 
            prev_bev=self.prev_frame_info['prev_bev'], **kwargs
        )
        
        self.prev_frame_info['prev_pos'] = tmp_pos
        self.prev_frame_info['prev_angle'] = tmp_angle
        self.prev_frame_info['prev_bev'] = new_prev_bev
        
        return bbox_results
    
    def pred2result(self, bboxes, scores, labels, pts, attrs=None):
        result_dict = dict(
            boxes_3d=bboxes.to('cpu'),
            scores_3d=scores.cpu(),
            labels_3d=labels.cpu(),
            pts_3d=pts.to('cpu')
        )
        if attrs is not None:
            result_dict['attrs_3d'] = attrs.cpu()
        return result_dict
    
    def simple_test_pts(self, x, lidar_feat, img_metas, prev_bev=None, rescale=False):
        outs = self.pts_bbox_head(x, lidar_feat, img_metas, prev_bev=prev_bev)
        bbox_list = self.pts_bbox_head.get_bboxes(outs, img_metas, rescale=rescale)
        bbox_results = [
            self.pred2result(bboxes, scores, labels, pts)
            for bboxes, scores, labels, pts in bbox_list
        ]
        return outs['bev_embed'], bbox_results
    
    def simple_test(self, img_metas, img=None, points=None, prev_bev=None, rescale=False, **kwargs):
        lidar_feat = None
        if self.modality == 'fusion':
            lidar_feat = self.extract_lidar_feat(points)
        
        img_feats = self.extract_feat(img=img, img_metas=img_metas)
        
        bbox_list = [dict() for i in range(len(img_metas))]
        new_prev_bev, bbox_pts = self.simple_test_pts(
            img_feats, lidar_feat, img_metas, prev_bev, rescale=rescale
        )
        for result_dict, pts_bbox in zip(bbox_list, bbox_pts):
            result_dict['pts_bbox'] = pts_bbox
        
        return new_prev_bev, bbox_list
