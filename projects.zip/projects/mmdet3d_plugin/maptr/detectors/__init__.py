from .maptr import MapTR
from .light_enhance_maptr import LightEnhanceMapTR
from .msala_maptr import MSALAMapTR
from .mpgid_maptr import MPGIDMapTR, MPGIDMapTR_Pretrain
from .map_aware_maptr import MapAwareMapTR, MapAwareMapTR_Pretrain
# MS-IIFL: Map-Structure-Guided Illumination-Invariant Feature Learning (ECCV 级别创新)
from .ms_iifl_maptr import MSIIFLMapTR, MSIIFLMapTR_Pretrain
# Enhanced MapTR: 带光照增强插件的正确架构
from .enhanced_maptr import EnhancedMapTR, EnhancedMapTR_Pretrain
# NIME: Neural-Inspired Map Element Enhancement (新框架 - ECCV 级别)
from .nime_maptr import NIMEMapTR, NIMEPretrainer, NIMEMapTR_Joint
# Retinex-MapTR: 基于 Retinex 理论的光照感知 HD Map 构建
from .retinex_maptr import RetinexMapTR

__all__ = [
    'MapTR', 
    'LightEnhanceMapTR', 
    'MSALAMapTR',
    # MPGID - Map-Prior Guided Intrinsic Decomposition
    'MPGIDMapTR',
    'MPGIDMapTR_Pretrain',
    # Map-Aware Feature Alignment
    'MapAwareMapTR',
    'MapAwareMapTR_Pretrain',
    # MS-IIFL - Map-Structure-Guided Illumination-Invariant Feature Learning (ECCV 级别创新)
    'MSIIFLMapTR',
    'MSIIFLMapTR_Pretrain',
    # Enhanced MapTR - 带光照增强插件（正确的架构）
    'EnhancedMapTR',
    'EnhancedMapTR_Pretrain',
    # NIME - Neural-Inspired Map Element Enhancement (新框架)
    'NIMEMapTR',
    'NIMEPretrainer',
    'NIMEMapTR_Joint',  # 联合训练版本（推荐）
    # Retinex-MapTR - 基于 Retinex 理论的光照感知 HD Map 构建
    'RetinexMapTR',
]