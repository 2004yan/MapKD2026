"""
MSALA-MapTR: Map Structure-Aware Light Adaptation for HD Map Construction

核心创新：
1. BEV-to-Image Structure Projection: 首次将 BEV Map 元素反投影到图像空间
2. Element-Specific Enhancement: 不同 Map 元素用不同增强策略
3. Detection-Enhancement Co-learning: 检测和增强联合优化

训练流程：
    原图 → 光照扰动 → Zero-DCE 增强 → MapTR 检测 → 检测损失
                │                         │
                │              BEV Map 元素 ↓
                │              反投影到图像空间
                │                    ↓
                │            Element Attention Maps
                │                    ↓
                └─────> Element-Specific Enhancement Loss

推理流程：
    任意光照图像 → Zero-DCE 自适应调整 → MapTR 检测 → 输出

参考文献：
- MapTR (ICLR 2023): HD Map Construction
- Zero-DCE (CVPR 2020): 光照增强
- FDA (CVPR 2020): 频域分解
- CLRNet (CVPR 2022): 车道线几何约束
"""

import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet.models import DETECTORS
from mmdet3d.models import builder
from mmcv.runner import force_fp32, auto_fp16

from .maptr import MapTR
from projects.mmdet3d_plugin.models.projections import (
    BEVToImageProjection, 
    MapElementAttentionGenerator,
    FastMapElementAttention
)
from projects.mmdet3d_plugin.models.losses.element_specific_loss import (
    ElementSpecificEnhancementLoss
)


class GPULightPerturbation(nn.Module):
    """GPU 上的光照扰动模块"""
    
    def __init__(self,
                 perturb_prob=0.8,
                 identity_prob=0.2,
                 darken_range=(0.3, 0.7),
                 brighten_range=(1.2, 1.8),
                 gamma_range=(0.5, 2.0),
                 noise_std_range=(0.02, 0.08)):
        super().__init__()
        self.perturb_prob = perturb_prob
        self.identity_prob = identity_prob
        self.darken_range = darken_range
        self.brighten_range = brighten_range
        self.gamma_range = gamma_range
        self.noise_std_range = noise_std_range
        self.perturb_types = ['darken', 'brighten', 'gamma', 'noise']
    
    def forward(self, img):
        """对图像进行光照扰动"""
        if not self.training or torch.rand(1).item() > self.perturb_prob:
            return img, 'identity'
        
        perturb_type = self.perturb_types[torch.randint(len(self.perturb_types), (1,)).item()]
        
        if perturb_type == 'darken':
            factor = torch.empty(1).uniform_(*self.darken_range).item()
            perturbed = img * factor
        elif perturb_type == 'brighten':
            factor = torch.empty(1).uniform_(*self.brighten_range).item()
            perturbed = img * factor
        elif perturb_type == 'gamma':
            gamma = torch.empty(1).uniform_(*self.gamma_range).item()
            perturbed = torch.pow(img.clamp(min=1e-6), gamma)
        else:  # noise
            std = torch.empty(1).uniform_(*self.noise_std_range).item()
            noise = torch.randn_like(img) * std
            perturbed = img + noise
        
        perturbed = perturbed.clamp(0, 1)
        return perturbed, perturb_type


@DETECTORS.register_module()
class MSALAMapTR(MapTR):
    """
    MSALA-MapTR: Map Structure-Aware Light Adaptation
    
    核心设计：
    1. 光照自适应增强器 (Zero-DCE)
    2. BEV-to-Image 投影模块
    3. Element-Specific Enhancement Loss
    """
    
    def __init__(self,
                 # 增强器配置
                 enhancer=None,
                 img_norm_cfg=None,
                 
                 # Element-Specific 配置
                 use_element_specific_loss=True,
                 element_specific_weight=1.0,
                 num_map_classes=3,  # divider, crossing, boundary
                 use_gt_attention=True,  # 训练时用 GT 生成 attention
                 use_fast_attention=False,  # 推理时用快速方法
                 
                 # 基础结构保护
                 use_structure_loss=True,
                 structure_loss_weight=0.5,
                 structure_loss_cfg=None,
                 
                 # 训练配置
                 enhance_loss_weight=0.1,
                 identity_weight=0.1,
                 perturb_cfg=None,
                 
                 # 投影配置
                 projection_cfg=None,
                 
                 # pc_range 单独传入，避免从 kwargs 获取不稳定
                 pc_range=None,
                 
                 **kwargs):
        
        # 在调用 super().__init__ 之前，先从 kwargs 中提取 pc_range
        # 因为 super().__init__ 会处理 kwargs，之后就无法获取了
        if pc_range is None:
            pts_bbox_head_cfg = kwargs.get('pts_bbox_head', {})
            if isinstance(pts_bbox_head_cfg, dict):
                pc_range = pts_bbox_head_cfg.get('pc_range', [-15.0, -30.0, -2.0, 15.0, 30.0, 2.0])
            else:
                pc_range = [-15.0, -30.0, -2.0, 15.0, 30.0, 2.0]
        
        super().__init__(**kwargs)
        
        # 保存配置
        self.img_norm_cfg = img_norm_cfg
        self.use_element_specific_loss = use_element_specific_loss
        self.element_specific_weight = element_specific_weight
        self.use_gt_attention = use_gt_attention
        self.use_fast_attention = use_fast_attention
        self.use_structure_loss = use_structure_loss
        self.structure_loss_weight = structure_loss_weight
        self.enhance_loss_weight = enhance_loss_weight
        self.identity_weight = identity_weight
        self.pc_range = pc_range  # 保存 pc_range
        self.num_map_classes = num_map_classes
        
        # 构建增强器
        if enhancer is not None:
            from projects.mmdet3d_plugin.models.enhancers import LightEnhancer
            self.enhancer = LightEnhancer(**enhancer)
        else:
            self.enhancer = None
        
        # 光照扰动模块
        if perturb_cfg is not None:
            self.light_perturb = GPULightPerturbation(**perturb_cfg)
        else:
            self.light_perturb = GPULightPerturbation()
        
        # BEV-to-Image 投影模块
        proj_cfg = projection_cfg or {}
        self.bev_projection = BEVToImageProjection(
            pc_range=pc_range,
            num_classes=num_map_classes,
            **proj_cfg
        )
        
        # Map Element Attention Generator (基于 GT)
        self.gt_attention_generator = MapElementAttentionGenerator(
            pc_range=pc_range,
            num_classes=num_map_classes
        )
        
        # Fast Attention (用于推理或无 GT 情况)
        if use_fast_attention:
            self.fast_attention = FastMapElementAttention(
                in_channels=3,
                num_classes=num_map_classes,
                use_learned=True
            )
        else:
            self.fast_attention = None
        
        # Element-Specific Enhancement Loss
        self.element_loss = ElementSpecificEnhancementLoss(
            num_classes=num_map_classes,
            lane_weight=1.0,
            crossing_weight=1.0,
            boundary_weight=1.0
        )
        
        # 基础结构保护损失
        if use_structure_loss:
            from projects.mmdet3d_plugin.models.losses.map_structure_loss import MapStructureLoss
            structure_cfg = structure_loss_cfg or {}
            self.structure_loss_fn = MapStructureLoss(**structure_cfg)
        else:
            self.structure_loss_fn = None
        
        # 增强器损失
        from projects.mmdet3d_plugin.models.enhancers.zero_dce import ZeroDCELoss
        self.enhance_loss_fn = ZeroDCELoss()
        
        # 注册归一化参数
        if img_norm_cfg is not None:
            mean = torch.tensor(img_norm_cfg['mean']).view(1, 3, 1, 1)
            std = torch.tensor(img_norm_cfg['std']).view(1, 3, 1, 1)
            self.register_buffer('img_mean', mean)
            self.register_buffer('img_std', std)
        else:
            # 默认 ImageNet 归一化参数
            mean = torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1)
            std = torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1)
            self.register_buffer('img_mean', mean)
            self.register_buffer('img_std', std)
    
    def denormalize(self, img):
        """反归一化到 [0, 1]"""
        img = img * self.img_std.to(img.device) + self.img_mean.to(img.device)
        return img / 255.0
    
    def normalize(self, img_01):
        """归一化 [0, 1] 图像"""
        img_255 = img_01 * 255.0
        return (img_255 - self.img_mean.to(img_255.device)) / self.img_std.to(img_255.device)
    
    def enhance_images(self, img):
        """增强图像"""
        if self.enhancer is None:
            return img
        
        original_shape = img.shape
        
        if len(original_shape) == 5:
            B, N, C, H, W = original_shape
            img = img.reshape(B * N, C, H, W)
        
        # 反归一化
        img_01 = self.denormalize(img)
        
        # 增强
        enhanced_01 = self.enhancer(img_01)
        
        # 重新归一化
        enhanced = self.normalize(enhanced_01)
        
        if len(original_shape) == 5:
            enhanced = enhanced.reshape(B, N, C, H, W)
        
        return enhanced
    
    def generate_perturbed_images(self, img):
        """生成扰动图像"""
        original_shape = img.shape
        
        if len(original_shape) == 5:
            B, N, C, H, W = original_shape
            img = img.reshape(B * N, C, H, W)
            need_reshape = True
        else:
            need_reshape = False
        
        # 反归一化
        img_01 = self.denormalize(img)
        
        # 扰动
        perturbed_01, perturb_type = self.light_perturb(img_01)
        
        # 重新归一化
        perturbed = self.normalize(perturbed_01)
        
        if need_reshape:
            perturbed = perturbed.reshape(B, N, C, H, W)
        
        return perturbed, perturb_type
    
    def get_attention_maps(self, gt_bboxes_3d, gt_labels_3d, img_metas, img_tensor):
        """
        获取 Map Element Attention Maps
        
        训练时使用 GT，推理时可用 Fast Attention 或预测结果
        
        Args:
            gt_bboxes_3d: list of GT Map 元素
            gt_labels_3d: list of GT 类别标签
            img_metas: list of img meta dict
            img_tensor: [B*N, C, H, W] 用于获取设备和形状
        
        Returns:
            attention_maps: [B, N_cams, num_classes, H, W] 或 None
        """
        # 从 img_tensor 获取设备和形状
        device = img_tensor.device
        H, W = img_tensor.shape[2], img_tensor.shape[3]
        
        # 获取 lidar2img
        lidar2img_list = []
        for meta in img_metas:
            lidar2img_list.append(torch.tensor(meta['lidar2img'], device=device, dtype=torch.float32))
        lidar2img = torch.stack(lidar2img_list, dim=0)  # [B, N_cams, 4, 4]
        
        if self.training and self.use_gt_attention:
            # 使用 GT 生成 Attention
            B = len(gt_bboxes_3d)
            attention_maps_list = []
            
            for b in range(B):
                # 检查 GT 是否有效
                if gt_bboxes_3d[b] is None or len(gt_bboxes_3d[b]) == 0:
                    # 无 GT，返回均匀 attention
                    num_cams = lidar2img.shape[1]
                    attention = torch.ones(
                        1, num_cams, self.num_map_classes, H, W, device=device
                    ) / self.num_map_classes
                else:
                    attention = self.gt_attention_generator(
                        gt_bboxes_3d[b],
                        gt_labels_3d[b],
                        lidar2img[b:b+1],
                        (H, W)
                    )
                attention_maps_list.append(attention)
            
            attention_maps = torch.cat(attention_maps_list, dim=0)
        elif self.fast_attention is not None:
            # 使用 Fast Attention（需要图像输入）
            attention_maps = None  # 将在 forward_train 中计算
        else:
            # 返回均匀 attention
            B = len(img_metas)
            num_cams = lidar2img.shape[1]
            attention_maps = torch.ones(
                B, num_cams, self.num_map_classes, H, W, device=device
            ) / self.num_map_classes
        
        return attention_maps
    
    @force_fp32(apply_to=('img', 'points', 'prev_bev'))
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      ):
        """
        MSALA 训练前向传播
        
        核心流程：
        1. 生成扰动图像
        2. 增强扰动图像
        3. 检测（得到 BEV Map 元素）
        4. 投影生成 Attention Maps（或用 GT）
        5. 计算 Element-Specific Loss
        """
        losses = dict()
        
        # ================== LiDAR 特征 ==================
        lidar_feat = None
        if self.modality == 'fusion':
            lidar_feat = self.extract_lidar_feat(points)
        
        # ================== 时序处理 ==================
        len_queue = img.size(1)
        prev_img = img[:, :-1, ...]
        img_current = img[:, -1, ...]  # [B, N, C, H, W]
        
        prev_img_metas = copy.deepcopy(img_metas)
        prev_bev = self.obtain_history_bev(prev_img, prev_img_metas) if len_queue > 1 else None
        
        img_metas_current = [each[len_queue-1] for each in img_metas]
        if not img_metas_current[0]['prev_bev_exists']:
            prev_bev = None
        
        # ================== 核心训练流程 ==================
        # 1. 生成扰动图像
        img_perturbed, perturb_type = self.generate_perturbed_images(img_current)
        
        # 2. 增强扰动图像
        img_enhanced = self.enhance_images(img_perturbed)
        
        # 3. 提取特征并检测
        img_feats = self.extract_feat(img=img_enhanced, img_metas=img_metas_current)
        
        # 4. 检测损失（反向传播到增强器）
        losses_pts = self.forward_pts_train(
            img_feats, lidar_feat, gt_bboxes_3d, gt_labels_3d,
            img_metas_current, gt_bboxes_ignore, prev_bev
        )
        for k, v in losses_pts.items():
            losses[k] = v
        
        # ================== Element-Specific Enhancement Loss ==================
        # 准备 [0, 1] 范围的图像
        B, N, C, H, W = img_enhanced.shape
        img_enhanced_flat = img_enhanced.reshape(B * N, C, H, W)
        img_perturbed_flat = img_perturbed.reshape(B * N, C, H, W)
        
        img_enhanced_01 = self.denormalize(img_enhanced_flat)
        img_perturbed_01 = self.denormalize(img_perturbed_flat)
        
        # 获取 Attention Maps
        if self.use_element_specific_loss:
            # 传入 img_enhanced_01 tensor 用于获取设备和形状
            attention_maps = self.get_attention_maps(
                gt_bboxes_3d, gt_labels_3d, img_metas_current, img_enhanced_01
            )
            
            if attention_maps is not None:
                # 调整形状 [B, N_cams, num_classes, H, W] -> [B*N, num_classes, H, W]
                if attention_maps.dim() == 5:
                    B_att, N_cams, num_cls, H_att, W_att = attention_maps.shape
                    attention_maps = attention_maps.reshape(B_att * N_cams, num_cls, H_att, W_att)
                    
                    # 如果 attention map 尺寸与图像不同，需要插值
                    if H_att != H or W_att != W:
                        attention_maps = F.interpolate(
                            attention_maps, size=(H, W), mode='bilinear', align_corners=False
                        )
                
                # 计算 Element-Specific Loss
                element_losses, _ = self.element_loss(
                    img_perturbed_01, img_enhanced_01, attention_maps
                )
                
                for k, v in element_losses.items():
                    losses[k] = v * self.element_specific_weight
        
        # ================== 基础结构保护损失 ==================
        if self.use_structure_loss and self.structure_loss_fn is not None:
            structure_losses, _ = self.structure_loss_fn(
                img_perturbed_01, img_enhanced_01
            )
            for k, v in structure_losses.items():
                losses[k] = v * self.structure_loss_weight
        
        # ================== 增强器自身损失 ==================
        loss_enhance, _ = self.enhance_loss_fn(img_enhanced_01, img_perturbed_01)
        losses['loss_enhance'] = loss_enhance * self.enhance_loss_weight
        
        # ================== 身份保持损失 ==================
        img_original_enhanced = self.enhance_images(img_current)
        loss_identity = F.l1_loss(img_original_enhanced, img_current)
        losses['loss_identity'] = loss_identity * self.identity_weight
        
        return losses
    
    def simple_test(self, img_metas, img=None, points=None, prev_bev=None, 
                    rescale=False, already_enhanced=False, **kwargs):
        """推理"""
        if img is not None and not already_enhanced:
            img = self.enhance_images(img)
        
        return super().simple_test(img_metas, img, points, prev_bev, rescale, **kwargs)
    
    def forward_test(self, img_metas, img=None, points=None, **kwargs):
        """测试前向"""
        for var, name in [(img_metas, 'img_metas')]:
            if not isinstance(var, list):
                raise TypeError('{} must be a list'.format(name))
        
        img = [img] if img is None else img
        points = [points] if points is None else points
        
        # 增强
        if img[0] is not None:
            img = [self.enhance_images(img[0])]
            already_enhanced = True
        else:
            already_enhanced = False
        
        if img_metas[0][0]['scene_token'] != self.prev_frame_info['scene_token']:
            self.prev_frame_info['prev_bev'] = None
        self.prev_frame_info['scene_token'] = img_metas[0][0]['scene_token']
        
        if not self.video_test_mode:
            self.prev_frame_info['prev_bev'] = None
        
        tmp_pos = copy.deepcopy(img_metas[0][0]['can_bus'][:3])
        tmp_angle = copy.deepcopy(img_metas[0][0]['can_bus'][-1])
        
        if self.prev_frame_info['prev_bev'] is not None:
            img_metas[0][0]['can_bus'][:3] -= self.prev_frame_info['prev_pos']
            img_metas[0][0]['can_bus'][-1] -= self.prev_frame_info['prev_angle']
        else:
            img_metas[0][0]['can_bus'][-1] = 0
            img_metas[0][0]['can_bus'][:3] = 0
        
        new_prev_bev, bbox_results = self.simple_test(
            img_metas[0], img[0], points[0], 
            prev_bev=self.prev_frame_info['prev_bev'],
            already_enhanced=already_enhanced, **kwargs
        )
        
        self.prev_frame_info['prev_pos'] = tmp_pos
        self.prev_frame_info['prev_angle'] = tmp_angle
        self.prev_frame_info['prev_bev'] = new_prev_bev
        
        return bbox_results
