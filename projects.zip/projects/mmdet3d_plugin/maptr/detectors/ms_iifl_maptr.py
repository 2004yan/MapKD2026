"""
MS-IIFL MapTR: Map-Structure-Guided Illumination-Invariant Feature Learning for HD Map Construction

ECCV 级别创新框架

核心创新点：
1. 多模态光照扰动：不仅夜间，还包括雨雾等多种退化
2. 地图元素特质对齐：利用车道线方向、人行横道频域特性
3. BEV 拓扑蒸馏：借鉴 SafeMap，在 BEV 空间进行特征蒸馏
4. 地图元素重建：借鉴 SafeMap G-PVR，从退化特征恢复地图信息

训练流程：
1. 输入白天图像 → 多模态光照扰动 → 合成退化图像
2. 分别提取特征（共享编码器）
3. 施加三大地图感知一致性约束
4. 同时做检测任务

与通用方法的区别：
- 不是在像素空间做增强
- 而是在特征空间做对齐
- 所有约束都针对地图元素的特质设计
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import warnings
from typing import Dict, List, Optional, Tuple
from mmcv.runner import force_fp32, auto_fp16
from mmdet.models import DETECTORS
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector

from ..detectors.maptr import MapTR
from ...models.enhancers.multi_modal_light_perturbation import (
    MultiModalLightPerturbation, 
    MapAwareLightPerturbation,
    DayNightPairGeneratorV2
)
from ...models.losses.ms_iifl_losses import (
    MSIIFLLoss,
    MapElementTraitAlignmentLoss,
    BEVTopologicalDistillationLoss,
    MapElementReconstructionLoss
)
from ...models.modules.map_element_reconstruction import (
    MapElementReconstructor,
    LightInvariantFeatureExtractor
)


@DETECTORS.register_module()
class MSIIFLMapTR(MapTR):
    """
    MS-IIFL MapTR: Map-Structure-Guided Illumination-Invariant Feature Learning
    
    ECCV 级别创新框架
    
    在训练时：
    1. 用多模态光照扰动生成退化图像
    2. 分别提取特征
    3. 施加地图感知一致性损失
    4. 可选：使用地图元素重建模块
    5. 同时做检测任务
    
    在推理时：
    与普通 MapTR 完全相同（零额外开销）
    """
    
    def __init__(self,
                 # 继承 MapTR 的所有参数
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 video_test_mode=False,
                 # MapTR 额外参数
                 modality='vision',
                 lidar_encoder=None,
                 # ========== MS-IIFL 专属参数 ==========
                 # 总开关
                 use_ms_iifl_training=True,
                 # 光照扰动配置
                 perturbation_cfg=None,
                 # 损失配置
                 ms_iifl_loss_cfg=None,
                 # 重建模块配置
                 use_reconstruction=False,
                 reconstruction_cfg=None,
                 # 特征对齐层级
                 align_pv_feat=True,      # PV（透视图）特征层
                 align_bev_feat=True,     # BEV 特征层
                 # 总权重
                 ms_iifl_loss_weight=1.0,
                 init_cfg=None):
        
        super().__init__(
            use_grid_mask=use_grid_mask,
            pts_voxel_layer=pts_voxel_layer,
            pts_voxel_encoder=pts_voxel_encoder,
            pts_middle_encoder=pts_middle_encoder,
            pts_fusion_layer=pts_fusion_layer,
            img_backbone=img_backbone,
            pts_backbone=pts_backbone,
            img_neck=img_neck,
            pts_neck=pts_neck,
            pts_bbox_head=pts_bbox_head,
            img_roi_head=img_roi_head,
            img_rpn_head=img_rpn_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            video_test_mode=video_test_mode,
            modality=modality,
            lidar_encoder=lidar_encoder
        )
        
        self.use_ms_iifl_training = use_ms_iifl_training
        self.align_pv_feat = align_pv_feat
        self.align_bev_feat = align_bev_feat
        self.ms_iifl_loss_weight = ms_iifl_loss_weight
        self.use_reconstruction = use_reconstruction
        
        # ========== 多模态光照扰动生成器 ==========
        if perturbation_cfg is None:
            perturbation_cfg = dict(
                degradation_type='multi_modal',
                enable_night=True,
                enable_rain=True,
                enable_fog=True,
                enable_overexpose=False,
                enable_local_light=True,
                night_darkness_range=(0.1, 0.4),
                night_gamma_range=(1.5, 3.0),
                night_noise_range=(0.01, 0.04)
            )
        self.pair_generator = DayNightPairGeneratorV2(**perturbation_cfg)
        
        # ========== MS-IIFL 综合损失 ==========
        if ms_iifl_loss_cfg is None:
            ms_iifl_loss_cfg = dict(
                use_trait_alignment=True,
                use_bev_distillation=True,
                use_map_reconstruction=False,
                trait_alignment_cfg=dict(
                    direction_weight=1.0,
                    frequency_weight=0.5
                ),
                bev_distillation_cfg=dict(
                    distill_weight=1.0,
                    topo_weight=0.5,
                    use_cosine_distill=True
                )
            )
        self.ms_iifl_loss = MSIIFLLoss(**ms_iifl_loss_cfg)
        
        # ========== 地图元素重建模块（可选）==========
        if use_reconstruction:
            if reconstruction_cfg is None:
                reconstruction_cfg = dict(
                    embed_dim=256,
                    num_queries=100,
                    use_reconstructor=True,
                    use_adapter=True
                )
            self.reconstructor = LightInvariantFeatureExtractor(**reconstruction_cfg)
        
        # ImageNet 归一化参数
        self.register_buffer('img_mean', 
                            torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1))
        self.register_buffer('img_std', 
                            torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1))
    
    @force_fp32(apply_to=('img', 'points', 'prev_bev'))
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None):
        """
        训练前向传播
        
        MS-IIFL 核心训练逻辑
        
        重要：需要与基类 MapTR 保持一致的时序处理逻辑
        """
        import copy
        
        # ========== 0. 处理 LiDAR 特征（如果有） ==========
        lidar_feat = None
        if self.modality == 'fusion':
            lidar_feat = self.extract_lidar_feat(points)
        
        # ========== 1. 处理时序队列 ==========
        # img 的形状是 [B, T, N, C, H, W]，T 是时序长度
        len_queue = img.size(1)
        prev_img = img[:, :-1, ...]  # 历史帧
        img_current = img[:, -1, ...]  # 当前帧
        
        # 获取历史 BEV 特征
        prev_img_metas = copy.deepcopy(img_metas)
        prev_bev = self.obtain_history_bev(prev_img, prev_img_metas) if len_queue > 1 else None
        
        # 更新 img_metas 为当前帧
        img_metas_current = [each[len_queue - 1] for each in img_metas]
        if not img_metas_current[0]['prev_bev_exists']:
            prev_bev = None
        
        # ========== 2. 提取当前帧图像特征 ==========
        img_feats_day = self.extract_feat(img=img_current, img_metas=img_metas_current)
        
        # ========== 3. 计算检测 Loss ==========
        losses = dict()
        losses_pts = self.forward_pts_train(
            img_feats_day, lidar_feat, gt_bboxes_3d, gt_labels_3d,
            img_metas_current, gt_bboxes_ignore, prev_bev
        )
        losses.update(losses_pts)
        
        # ========== 4. MS-IIFL 特征对齐（在当前帧上） ==========
        if self.use_ms_iifl_training and self.training:
            ms_iifl_losses = self._compute_ms_iifl_losses(
                img_current, img_metas_current, img_feats_day, prev_bev
            )
            losses.update(ms_iifl_losses)
        
        return losses
    
    def _compute_ms_iifl_losses(self, 
                                 img: torch.Tensor,
                                 img_metas: List[Dict],
                                 img_feats_day: Tuple[torch.Tensor],
                                 prev_bev: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        计算 MS-IIFL 特征对齐损失
        
        核心创新：
        1. 生成多模态退化图像
        2. 在 PV 和 BEV 空间施加地图感知一致性约束
        """
        losses = {}
        
        # ========== Step 1: 生成退化图像 ==========
        B, N, C, H, W = img.shape
        img_flat = img.view(B * N, C, H, W)
        
        # 反归一化到 [0, 1]
        img_normalized = self._denormalize_img(img_flat)
        
        # 多模态光照扰动
        _, img_degraded_normalized, degrade_params = self.pair_generator(img_normalized)
        
        # 归一化回网络输入格式
        img_degraded_flat = self._normalize_img(img_degraded_normalized)
        img_degraded = img_degraded_flat.view(B, N, C, H, W)
        
        # ========== Step 2: 提取退化图像特征 ==========
        img_feats_degraded = self.extract_img_feat(img=img_degraded, img_metas=img_metas)
        
        # ========== Step 3: PV 特征对齐 ==========
        if self.align_pv_feat:
            # 取最高分辨率特征（通常是第一个）
            feat_day = img_feats_day[0] if isinstance(img_feats_day, (list, tuple)) else img_feats_day
            feat_degraded = img_feats_degraded[0] if isinstance(img_feats_degraded, (list, tuple)) else img_feats_degraded
            
            # 如果特征维度是 5D (B, N, C, H, W)，展平为 4D
            if feat_day.dim() == 5:
                B, N, C, H, W = feat_day.shape
                feat_day = feat_day.view(B * N, C, H, W)
                feat_degraded = feat_degraded.view(B * N, C, H, W)
            
            # 🔑 关键修复：feat_day.detach() 阻止梯度流回
            # 这样一致性损失只会让 feat_degraded 学习靠近 feat_day
            # 而不会拉低 feat_day 的检测质量
            # MS-IIFL 损失（PV 级别）
            pv_losses = self.ms_iifl_loss(
                feat_day=feat_day.detach(),  # 🔑 教师特征，不参与梯度更新
                feat_night=feat_degraded,     # 学生特征，学习靠近教师
                bev_day=None,  # BEV 级别单独处理
                bev_night=None
            )
            
            for k, v in pv_losses.items():
                if 'bev' not in k:  # 排除 BEV 损失
                    losses[f'pv_{k}'] = v * self.ms_iifl_loss_weight
        
        # ========== Step 4: BEV 特征对齐 ==========
        if self.align_bev_feat and hasattr(self, 'pts_bbox_head'):
            # 获取 BEV 特征
            # 注意：需要调用 pts_bbox_head 的内部方法获取 BEV 特征
            # 这里假设可以通过 transformer 获取
            try:
                # 尝试获取 BEV 特征
                bev_day = self._get_bev_feat(img_feats_day, img_metas, prev_bev)
                bev_degraded = self._get_bev_feat(img_feats_degraded, img_metas, prev_bev)
                
                if bev_day is not None and bev_degraded is not None:
                    # 🔑 关键修复：bev_day.detach() 阻止梯度流回
                    # MS-IIFL 损失（BEV 级别）
                    bev_losses = self.ms_iifl_loss(
                        feat_day=bev_day.detach(),    # 🔑 教师特征
                        feat_night=bev_degraded,       # 学生特征
                        bev_day=bev_day.detach(),     # 🔑 教师特征
                        bev_night=bev_degraded
                    )
                    
                    for k, v in bev_losses.items():
                        if 'bev' in k:  # 只取 BEV 损失
                            losses[f'{k}'] = v * self.ms_iifl_loss_weight
            except Exception as e:
                # 如果无法获取 BEV 特征，跳过
                warnings.warn(f"Failed to get BEV features for MS-IIFL: {e}")
        
        # ========== Step 5: 地图元素重建（可选）==========
        if self.use_reconstruction:
            feat_day = img_feats_day[0] if isinstance(img_feats_day, (list, tuple)) else img_feats_day
            feat_degraded = img_feats_degraded[0] if isinstance(img_feats_degraded, (list, tuple)) else img_feats_degraded
            
            if feat_day.dim() == 5:
                B, N, C, H, W = feat_day.shape
                feat_day = feat_day.view(B * N, C, H, W)
                feat_degraded = feat_degraded.view(B * N, C, H, W)
            
            # 🔑 feat_day.detach() 作为重建目标，不参与梯度更新
            recon_outputs = self.reconstructor(feat_degraded, feat_day.detach())
            
            if 'loss_reconstruction' in recon_outputs:
                losses['loss_map_recon'] = recon_outputs['loss_reconstruction'] * self.ms_iifl_loss_weight
        
        return losses
    
    def _get_bev_feat(self, img_feats: Tuple[torch.Tensor],
                      img_metas: List[Dict],
                      prev_bev: Optional[torch.Tensor] = None) -> Optional[torch.Tensor]:
        """
        从 pts_bbox_head 获取 BEV 特征
        
        这需要访问 transformer 的内部状态
        """
        # 尝试通过 transformer 的 get_bev_features 方法获取
        if hasattr(self.pts_bbox_head, 'transformer') and \
           hasattr(self.pts_bbox_head.transformer, 'get_bev_features'):
            try:
                # 这里的实现取决于具体的 transformer 架构
                # MapTR 使用的是 BEVFormer 风格的 transformer
                bev_feat = self.pts_bbox_head.transformer.get_bev_features(
                    img_feats, img_metas, prev_bev
                )
                return bev_feat
            except:
                pass
        
        # 如果无法直接获取，返回 None
        return None
    
    def _denormalize_img(self, img: torch.Tensor) -> torch.Tensor:
        """将网络输入的归一化图像转回 [0, 1] 范围"""
        img_denorm = img * self.img_std + self.img_mean
        img_denorm = img_denorm / 255.0
        return img_denorm.clamp(0, 1)
    
    def _normalize_img(self, img: torch.Tensor) -> torch.Tensor:
        """将 [0, 1] 范围的图像转为网络输入格式"""
        img_norm = img * 255.0
        img_norm = (img_norm - self.img_mean) / self.img_std
        return img_norm
    
    def simple_test(self, img_metas, img=None, points=None, prev_bev=None, rescale=False, **kwargs):
        """
        推理时与普通 MapTR 完全相同
        
        MS-IIFL 的优势：训练时学到的光照不变性，在推理时零额外开销
        """
        return super().simple_test(img_metas, img, points, prev_bev, rescale, **kwargs)


@DETECTORS.register_module()
class MSIIFLMapTR_Pretrain(nn.Module):
    """
    MS-IIFL 预训练模型
    
    纯粹的特征对齐预训练，不做检测任务
    用于先训练一个光照不变的特征提取器
    
    使用场景：
    1. 在大量无标注数据上预训练
    2. 然后在有标注数据上微调检测任务
    """
    
    def __init__(self,
                 img_backbone,
                 img_neck=None,
                 # MS-IIFL 参数
                 perturbation_cfg=None,
                 ms_iifl_loss_cfg=None,
                 use_reconstruction=False,
                 reconstruction_cfg=None,
                 init_cfg=None):
        super().__init__()
        
        from mmdet.models import build_backbone, build_neck
        
        # 构建 backbone 和 neck
        self.img_backbone = build_backbone(img_backbone)
        if img_neck is not None:
            self.img_neck = build_neck(img_neck)
        else:
            self.img_neck = None
        
        self.use_reconstruction = use_reconstruction
        
        # 多模态光照扰动生成器
        if perturbation_cfg is None:
            perturbation_cfg = dict(
                degradation_type='multi_modal',
                enable_night=True,
                enable_rain=True,
                enable_fog=True
            )
        self.pair_generator = DayNightPairGeneratorV2(**perturbation_cfg)
        
        # MS-IIFL 损失
        if ms_iifl_loss_cfg is None:
            ms_iifl_loss_cfg = dict(
                use_trait_alignment=True,
                use_bev_distillation=False,  # 预训练时不用 BEV
                use_map_reconstruction=use_reconstruction
            )
        self.ms_iifl_loss = MSIIFLLoss(**ms_iifl_loss_cfg)
        
        # 重建模块
        if use_reconstruction:
            if reconstruction_cfg is None:
                reconstruction_cfg = dict(embed_dim=256, num_queries=100)
            self.reconstructor = LightInvariantFeatureExtractor(**reconstruction_cfg)
        
        # ImageNet 归一化参数
        self.register_buffer('img_mean', 
                            torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1))
        self.register_buffer('img_std', 
                            torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1))
    
    def extract_feat(self, img):
        """提取图像特征"""
        x = self.img_backbone(img)
        if self.img_neck is not None:
            x = self.img_neck(x)
        return x
    
    def forward(self, img, img_metas=None, return_loss=True, **kwargs):
        """前向传播"""
        if return_loss:
            return self.forward_train(img)
        else:
            return self.forward_test(img)
    
    def forward_train(self, img):
        """训练前向传播"""
        # 处理维度
        if img.dim() == 5:  # [B, N, C, H, W]
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
        
        # 1. 反归一化到 [0, 1]
        img_denorm = (img * self.img_std + self.img_mean) / 255.0
        img_denorm = img_denorm.clamp(0, 1)
        
        # 2. 生成多模态退化图像
        _, img_degraded_denorm, params = self.pair_generator(img_denorm)
        
        # 3. 归一化回网络输入
        img_day = img
        img_degraded = (img_degraded_denorm * 255.0 - self.img_mean) / self.img_std
        
        # 4. 提取特征
        feat_day = self.extract_feat(img_day)
        feat_degraded = self.extract_feat(img_degraded)
        
        # 取最高分辨率特征
        if isinstance(feat_day, (list, tuple)):
            feat_day = feat_day[0]
            feat_degraded = feat_degraded[0]
        
        # 5. 计算 MS-IIFL 损失
        losses = self.ms_iifl_loss(feat_day, feat_degraded)
        
        # 6. 重建损失（可选）
        if self.use_reconstruction:
            # 🔑 feat_day.detach() 作为重建目标，不参与梯度更新
            recon_outputs = self.reconstructor(feat_degraded, feat_day.detach())
            if 'loss_reconstruction' in recon_outputs:
                losses['loss_reconstruction'] = recon_outputs['loss_reconstruction']
        
        return losses
    
    def forward_test(self, img):
        """测试前向传播（只提取特征）"""
        if img.dim() == 5:
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
        
        feat = self.extract_feat(img)
        return feat
