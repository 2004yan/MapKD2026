"""
Zero-DCE (Zero-Reference Deep Curve Estimation) 光照增强网络

核心思想：
- 不直接预测增强后的图像，而是预测一组"光照调整曲线"参数
- 通过迭代应用曲线来增强图像
- 极轻量（参数量 < 100K），推理速度快

参考论文: Zero-Reference Deep Curve Estimation for Low-Light Image Enhancement (CVPR 2020)

特点：
- 无需配对训练数据（Zero-Reference）
- 使用非参考损失函数（曝光控制、色彩恒常性等）
- 完全可微，支持端到端训练
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import BaseModule
from mmdet.models.builder import BACKBONES


class DepthwiseSeparableConv(nn.Module):
    """深度可分离卷积，进一步减少参数量"""
    
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1):
        super().__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size, 
                                   padding=padding, groups=in_channels)
        self.pointwise = nn.Conv2d(in_channels, out_channels, 1)
    
    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x


@BACKBONES.register_module()
class ZeroDCE(BaseModule):
    """
    Zero-DCE 光照增强网络
    
    网络结构：
    - 7层卷积提取特征
    - 输出 n_iter * 3 通道的曲线参数
    - 迭代应用曲线增强图像
    
    Args:
        in_channels: 输入通道数，默认 3（RGB）
        hidden_channels: 隐藏层通道数，默认 32
        n_iter: 曲线迭代次数，默认 8
        use_depthwise: 是否使用深度可分离卷积，默认 False
    """
    
    def __init__(self, 
                 in_channels=3,
                 hidden_channels=32,
                 n_iter=8,
                 use_depthwise=False,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.n_iter = n_iter
        self.in_channels = in_channels
        
        # 特征提取网络
        # 注意：所有卷积都需要 padding=1 来保持空间尺寸一致
        self.conv1 = nn.Conv2d(in_channels, hidden_channels, 3, 1, 1)
        
        if use_depthwise:
            self.conv2 = DepthwiseSeparableConv(hidden_channels, hidden_channels, 3, 1)
            self.conv3 = DepthwiseSeparableConv(hidden_channels, hidden_channels, 3, 1)
            self.conv4 = DepthwiseSeparableConv(hidden_channels, hidden_channels, 3, 1)
            self.conv5 = DepthwiseSeparableConv(hidden_channels * 2, hidden_channels, 3, 1)
            self.conv6 = DepthwiseSeparableConv(hidden_channels * 2, hidden_channels, 3, 1)
        else:
            # nn.Conv2d 参数顺序: (in, out, kernel, stride, padding)
            self.conv2 = nn.Conv2d(hidden_channels, hidden_channels, 3, 1, 1)
            self.conv3 = nn.Conv2d(hidden_channels, hidden_channels, 3, 1, 1)
            self.conv4 = nn.Conv2d(hidden_channels, hidden_channels, 3, 1, 1)
            self.conv5 = nn.Conv2d(hidden_channels * 2, hidden_channels, 3, 1, 1)
            self.conv6 = nn.Conv2d(hidden_channels * 2, hidden_channels, 3, 1, 1)
        
        # 输出层：预测曲线参数
        self.conv7 = nn.Conv2d(hidden_channels * 2, n_iter * in_channels, 3, 1, 1)
        
        self.relu = nn.ReLU(inplace=True)
        self.tanh = nn.Tanh()
        
        # 初始化
        self._init_weights()
    
    def _init_weights(self):
        """权重初始化"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
    
    def forward(self, x):
        """
        前向传播
        
        Args:
            x: 输入图像 [B, C, H, W]，范围 [0, 1]
        
        Returns:
            enhanced: 增强后的图像 [B, C, H, W]，范围 [0, 1]
        """
        # 特征提取（带跳跃连接的 U-Net 结构简化版）
        x1 = self.relu(self.conv1(x))
        x2 = self.relu(self.conv2(x1))
        x3 = self.relu(self.conv3(x2))
        x4 = self.relu(self.conv4(x3))
        
        x5 = self.relu(self.conv5(torch.cat([x3, x4], dim=1)))
        x6 = self.relu(self.conv6(torch.cat([x2, x5], dim=1)))
        
        # 输出曲线参数 [B, n_iter*3, H, W]
        curves = self.tanh(self.conv7(torch.cat([x1, x6], dim=1)))
        
        # 将曲线参数分组 [B, n_iter, 3, H, W]
        B, _, H, W = curves.shape
        curves = curves.view(B, self.n_iter, self.in_channels, H, W)
        
        # 迭代应用曲线增强
        enhanced = x
        for i in range(self.n_iter):
            # 曲线方程: LE(x) = x + A * x * (1 - x)
            # 其中 A 是学习到的曲线参数
            curve = curves[:, i, :, :, :]
            enhanced = enhanced + curve * enhanced * (1 - enhanced)
        
        return torch.clamp(enhanced, 0, 1)
    
    def get_curves(self, x):
        """获取曲线参数（用于可视化和分析）"""
        x1 = self.relu(self.conv1(x))
        x2 = self.relu(self.conv2(x1))
        x3 = self.relu(self.conv3(x2))
        x4 = self.relu(self.conv4(x3))
        
        x5 = self.relu(self.conv5(torch.cat([x3, x4], dim=1)))
        x6 = self.relu(self.conv6(torch.cat([x2, x5], dim=1)))
        
        curves = self.tanh(self.conv7(torch.cat([x1, x6], dim=1)))
        return curves


@BACKBONES.register_module()
class ZeroDCEPP(BaseModule):
    """
    Zero-DCE++ 改进版
    
    相比 Zero-DCE 的改进：
    - 更轻量的网络结构
    - 使用深度可分离卷积
    - 支持任意分辨率
    
    Args:
        in_channels: 输入通道数
        scale_factor: 下采样因子，用于加速大分辨率图像
        n_iter: 曲线迭代次数
    """
    
    def __init__(self,
                 in_channels=3,
                 scale_factor=1,
                 n_iter=8,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.n_iter = n_iter
        self.scale_factor = scale_factor
        self.in_channels = in_channels
        
        # 更轻量的网络
        self.dw_conv1 = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, 1, 1),
            nn.ReLU(inplace=True)
        )
        self.dw_conv2 = nn.Sequential(
            DepthwiseSeparableConv(32, 32),
            nn.ReLU(inplace=True)
        )
        self.dw_conv3 = nn.Sequential(
            DepthwiseSeparableConv(32, 32),
            nn.ReLU(inplace=True)
        )
        self.dw_conv4 = nn.Sequential(
            DepthwiseSeparableConv(32, 32),
            nn.ReLU(inplace=True)
        )
        
        # 输出层
        self.out_conv = nn.Conv2d(32, n_iter * in_channels, 3, 1, 1)
        self.tanh = nn.Tanh()
    
    def forward(self, x):
        """前向传播"""
        # 可选下采样以加速
        if self.scale_factor > 1:
            x_down = F.interpolate(x, scale_factor=1/self.scale_factor, 
                                   mode='bilinear', align_corners=False)
        else:
            x_down = x
        
        # 特征提取
        f1 = self.dw_conv1(x_down)
        f2 = self.dw_conv2(f1)
        f3 = self.dw_conv3(f2)
        f4 = self.dw_conv4(f3)
        
        # 输出曲线参数
        curves = self.tanh(self.out_conv(f4))
        
        # 上采样回原始分辨率
        if self.scale_factor > 1:
            curves = F.interpolate(curves, size=x.shape[2:], 
                                   mode='bilinear', align_corners=False)
        
        # 应用曲线
        B, _, H, W = curves.shape
        curves = curves.view(B, self.n_iter, self.in_channels, H, W)
        
        enhanced = x
        for i in range(self.n_iter):
            curve = curves[:, i, :, :, :]
            enhanced = enhanced + curve * enhanced * (1 - enhanced)
        
        return torch.clamp(enhanced, 0, 1)


# ================== 损失函数 ==================

class ZeroDCELoss(nn.Module):
    """
    Zero-DCE 的无参考损失函数
    
    包含四种损失：
    1. 空间一致性损失 (Spatial Consistency Loss)
    2. 曝光控制损失 (Exposure Control Loss)
    3. 色彩恒常性损失 (Color Constancy Loss)
    4. 光照平滑损失 (Illumination Smoothness Loss)
    """
    
    def __init__(self,
                 spa_weight=1.0,
                 exp_weight=10.0,
                 col_weight=5.0,
                 tv_weight=200.0,
                 exp_mean=0.6):
        super().__init__()
        self.spa_weight = spa_weight
        self.exp_weight = exp_weight
        self.col_weight = col_weight
        self.tv_weight = tv_weight
        self.exp_mean = exp_mean  # 目标曝光值
        
        # 空间一致性损失的池化核
        self.spa_pool = nn.AvgPool2d(4)
    
    def spatial_consistency_loss(self, enhanced, original):
        """空间一致性损失：保持局部区域的相对亮度关系"""
        enhanced_mean = self.spa_pool(enhanced)
        original_mean = self.spa_pool(original)
        
        # 计算四个方向的梯度差异
        d_org_left = original_mean[:, :, :, :-1] - original_mean[:, :, :, 1:]
        d_org_right = original_mean[:, :, :, 1:] - original_mean[:, :, :, :-1]
        d_org_up = original_mean[:, :, :-1, :] - original_mean[:, :, 1:, :]
        d_org_down = original_mean[:, :, 1:, :] - original_mean[:, :, :-1, :]
        
        d_enh_left = enhanced_mean[:, :, :, :-1] - enhanced_mean[:, :, :, 1:]
        d_enh_right = enhanced_mean[:, :, :, 1:] - enhanced_mean[:, :, :, :-1]
        d_enh_up = enhanced_mean[:, :, :-1, :] - enhanced_mean[:, :, 1:, :]
        d_enh_down = enhanced_mean[:, :, 1:, :] - enhanced_mean[:, :, :-1, :]
        
        loss = (torch.pow(d_org_left - d_enh_left, 2).mean() +
                torch.pow(d_org_right - d_enh_right, 2).mean() +
                torch.pow(d_org_up - d_enh_up, 2).mean() +
                torch.pow(d_org_down - d_enh_down, 2).mean())
        
        return loss
    
    def exposure_control_loss(self, enhanced, patch_size=16):
        """曝光控制损失：保证增强后的图像亮度在合理范围"""
        mean = F.avg_pool2d(enhanced, patch_size)
        loss = torch.pow(mean - self.exp_mean, 2).mean()
        return loss
    
    def color_constancy_loss(self, enhanced):
        """色彩恒常性损失：保持颜色通道间的平衡"""
        mean_rgb = enhanced.mean(dim=[2, 3], keepdim=True)
        mr, mg, mb = mean_rgb[:, 0], mean_rgb[:, 1], mean_rgb[:, 2]
        
        loss = (torch.pow(mr - mg, 2).mean() +
                torch.pow(mr - mb, 2).mean() +
                torch.pow(mb - mg, 2).mean())
        
        return loss
    
    def illumination_smoothness_loss(self, curves):
        """光照平滑损失：保证曲线参数的空间平滑性"""
        # Total Variation Loss
        tv_x = torch.pow(curves[:, :, :, :-1] - curves[:, :, :, 1:], 2).mean()
        tv_y = torch.pow(curves[:, :, :-1, :] - curves[:, :, 1:, :], 2).mean()
        return tv_x + tv_y
    
    def forward(self, enhanced, original, curves=None):
        """
        计算总损失
        
        Args:
            enhanced: 增强后的图像
            original: 原始输入图像
            curves: 曲线参数（可选，用于计算平滑损失）
        """
        loss_spa = self.spatial_consistency_loss(enhanced, original) * self.spa_weight
        loss_exp = self.exposure_control_loss(enhanced) * self.exp_weight
        loss_col = self.color_constancy_loss(enhanced) * self.col_weight
        
        total_loss = loss_spa + loss_exp + loss_col
        
        if curves is not None:
            loss_tv = self.illumination_smoothness_loss(curves) * self.tv_weight
            total_loss = total_loss + loss_tv
        
        return total_loss, {
            'loss_spa': loss_spa,
            'loss_exp': loss_exp,
            'loss_col': loss_col,
        }


class IdentityPreservationLoss(nn.Module):
    """
    身份保持损失
    
    当输入是"高质量"图像时，增强器应该输出接近原图的结果
    """
    
    def __init__(self, brightness_threshold=0.4):
        super().__init__()
        self.brightness_threshold = brightness_threshold
    
    def is_good_lighting(self, img):
        """判断图像是否光照良好"""
        mean_brightness = img.mean()
        return mean_brightness > self.brightness_threshold
    
    def forward(self, enhanced, original):
        """
        如果原图光照良好，则惩罚增强器对其的修改
        """
        # 计算 L1 损失
        loss = F.l1_loss(enhanced, original)
        return loss
