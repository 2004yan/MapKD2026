"""
Light Degradation Module - 光照退化模块

将白天图像合成为夜间图像，用于自监督训练

关键：合成的 (Day, Night) 对的 Ground Truth 是完全一样的！
这样我们可以用特征一致性来做自监督

参考：
- LightDiff (CVPR 2024): Low_Illumination_Degrading
- MAET (ICCV 2021): 低光照退化模型
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Tuple, Optional
import random


class LightDegradation(nn.Module):
    """
    光照退化模块
    
    将白天图像模拟成夜间图像
    
    退化步骤：
    1. 全局暗化（Global Darkening）
    2. 伽马畸变（Gamma Distortion）
    3. 噪声注入（Noise Injection）
    4. 局部光照（Local Illumination）- 模拟路灯
    
    设计原则：
    - 退化是可逆的（理论上），模型需要学会"还原"
    - 退化不改变地图元素的几何位置
    """
    
    def __init__(self,
                 darkness_range: Tuple[float, float] = (0.1, 0.5),
                 gamma_range: Tuple[float, float] = (1.5, 3.0),
                 noise_level: float = 0.02,
                 add_local_light: bool = True,
                 local_light_prob: float = 0.5):
        super().__init__()
        self.darkness_range = darkness_range
        self.gamma_range = gamma_range
        self.noise_level = noise_level
        self.add_local_light = add_local_light
        self.local_light_prob = local_light_prob
    
    def forward(self, img: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        """
        Args:
            img: [B, C, H, W] 白天图像，范围 [0, 1]
        Returns:
            degraded: [B, C, H, W] 退化后的夜间图像
            params: 退化参数（用于可视化/调试）
        """
        B, C, H, W = img.shape
        device = img.device
        
        params = {}
        
        # 1. 全局暗化
        darkness = random.uniform(*self.darkness_range)
        degraded = img * darkness
        params['darkness'] = darkness
        
        # 2. 伽马畸变（非线性亮度压缩）
        gamma = random.uniform(*self.gamma_range)
        degraded = torch.pow(degraded + 1e-8, gamma)
        params['gamma'] = gamma
        
        # 3. 添加噪声（shot noise + read noise）
        if self.noise_level > 0:
            # Shot noise（与信号强度相关）
            shot_noise = torch.randn_like(degraded) * torch.sqrt(degraded + 1e-8) * self.noise_level
            # Read noise（固定噪声）
            read_noise = torch.randn_like(degraded) * self.noise_level * 0.5
            degraded = degraded + shot_noise + read_noise
            params['noise_level'] = self.noise_level
        
        # 4. 添加局部光照（模拟路灯）
        if self.add_local_light and random.random() < self.local_light_prob:
            degraded, light_mask = self._add_local_lights(degraded)
            params['local_light'] = True
        else:
            params['local_light'] = False
        
        # 确保范围在 [0, 1]
        degraded = degraded.clamp(0, 1)
        
        return degraded, params
    
    def _add_local_lights(self, img: torch.Tensor, 
                          num_lights: int = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        添加局部光源（模拟路灯、车灯）
        
        Args:
            img: [B, C, H, W]
            num_lights: 光源数量
        Returns:
            img_with_lights: 添加光源后的图像
            light_mask: 光源位置掩码
        """
        B, C, H, W = img.shape
        device = img.device
        
        if num_lights is None:
            num_lights = random.randint(1, 4)
        
        light_mask = torch.zeros(B, 1, H, W, device=device)
        
        for _ in range(num_lights):
            # 随机光源位置（倾向于图像上半部分，模拟路灯）
            cx = random.randint(W // 4, W * 3 // 4)
            cy = random.randint(0, H // 2)
            
            # 随机光源大小
            radius = random.randint(50, 150)
            
            # 随机光源强度
            intensity = random.uniform(0.3, 0.8)
            
            # 创建高斯光晕
            y_coords = torch.arange(H, device=device).view(1, 1, H, 1).expand(B, 1, H, W).float()
            x_coords = torch.arange(W, device=device).view(1, 1, 1, W).expand(B, 1, H, W).float()
            
            dist_sq = (x_coords - cx) ** 2 + (y_coords - cy) ** 2
            gaussian = torch.exp(-dist_sq / (2 * radius ** 2)) * intensity
            
            light_mask = light_mask + gaussian
        
        # 限制最大亮度
        light_mask = light_mask.clamp(0, 1)
        
        # 添加光照效果
        img_with_lights = img + light_mask * (1 - img) * 0.5
        
        return img_with_lights.clamp(0, 1), light_mask


class AdvancedLightDegradation(nn.Module):
    """
    高级光照退化模块（更真实的物理模型）
    
    参考 LightDiff 的 Low_Illumination_Degrading 实现
    包含完整的 ISP（Image Signal Processing）逆过程
    """
    
    def __init__(self,
                 darkness_range: Tuple[float, float] = (0.05, 0.3),
                 gamma_range: Tuple[float, float] = (2.0, 3.5),
                 color_shift: bool = True):
        super().__init__()
        self.darkness_range = darkness_range
        self.gamma_range = gamma_range
        self.color_shift = color_shift
        
        # 相机颜色矩阵（模拟不同相机的颜色响应）
        self.xyz2cams = [
            [[1.0234, -0.2969, -0.2266],
             [-0.5625, 1.6328, -0.0469],
             [-0.0703, 0.2188, 0.6406]],
            [[0.4913, -0.0541, -0.0202],
             [-0.613, 1.3513, 0.2906],
             [-0.1564, 0.2151, 0.7183]]
        ]
        
        self.rgb2xyz = [[0.4124564, 0.3575761, 0.1804375],
                        [0.2126729, 0.7151522, 0.0721750],
                        [0.0193339, 0.1191920, 0.9503041]]
    
    def forward(self, img: torch.Tensor) -> Tuple[torch.Tensor, dict]:
        """
        完整的低光照退化流程
        
        Args:
            img: [B, C, H, W] 白天图像，范围 [0, 1]
        Returns:
            degraded: [B, C, H, W] 退化后的图像
            params: 退化参数
        """
        B, C, H, W = img.shape
        device = img.device
        params = {}
        
        # 转换维度：[B, C, H, W] -> [B, H, W, C]
        img_hwc = img.permute(0, 2, 3, 1)
        
        # 1. 逆 Tone Mapping
        img1 = 0.5 - torch.sin(torch.asin(1.0 - 2.0 * img_hwc.clamp(0.001, 0.999)) / 3.0)
        
        # 2. 逆 Gamma
        gamma = random.uniform(*self.gamma_range)
        img2 = torch.pow(img1.clamp(1e-8, 1), gamma)
        params['gamma'] = gamma
        
        # 3. 颜色矩阵变换（可选）
        if self.color_shift:
            xyz2cam = random.choice(self.xyz2cams)
            rgb2cam = np.matmul(xyz2cam, self.rgb2xyz)
            rgb2cam = torch.from_numpy(rgb2cam / np.sum(rgb2cam, axis=-1, keepdims=True)).float().to(device)
            img3 = torch.tensordot(img2, rgb2cam, dims=[[-1], [-1]])
            img3 = img3.clamp(0, 1)
        else:
            img3 = img2
        
        # 4. 暗化
        darkness = random.uniform(*self.darkness_range)
        img4 = img3 * darkness
        params['darkness'] = darkness
        
        # 5. 添加噪声
        shot_noise = 0.001 + random.random() * 0.01
        read_noise = 0.001 + random.random() * 0.005
        
        var = img4 * shot_noise + read_noise
        noise = torch.randn_like(img4) * torch.sqrt(var.clamp(1e-8))
        img5 = img4 + noise
        params['shot_noise'] = shot_noise
        params['read_noise'] = read_noise
        
        # 6. 逆变换回来（部分恢复，模拟相机 ISP）
        if self.color_shift:
            cam2rgb = torch.inverse(rgb2cam)
            img6 = torch.tensordot(img5, cam2rgb, dims=[[-1], [-1]])
        else:
            img6 = img5
        
        # 7. Gamma 校正（部分恢复）
        img7 = torch.pow(img6.clamp(1e-8), 1.0 / gamma * 0.7)  # 只恢复一部分
        
        # 转回 [B, C, H, W]
        degraded = img7.permute(0, 3, 1, 2).clamp(0, 1)
        
        return degraded, params


class DayNightPairGenerator(nn.Module):
    """
    白天-夜间图像对生成器
    
    用于自监督训练：同一张白天图像生成对应的夜间版本
    Ground Truth 完全相同，可以用来训练特征一致性
    """
    
    def __init__(self, 
                 degradation_type: str = 'simple',
                 **kwargs):
        super().__init__()
        
        if degradation_type == 'simple':
            self.degradation = LightDegradation(**kwargs)
        elif degradation_type == 'advanced':
            self.degradation = AdvancedLightDegradation(**kwargs)
        else:
            raise ValueError(f"Unknown degradation type: {degradation_type}")
    
    def forward(self, img_day: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, dict]:
        """
        Args:
            img_day: [B, C, H, W] 白天图像
        Returns:
            img_day: 原始白天图像（不变）
            img_night: 合成的夜间图像
            params: 退化参数
        """
        img_night, params = self.degradation(img_day)
        return img_day, img_night, params
