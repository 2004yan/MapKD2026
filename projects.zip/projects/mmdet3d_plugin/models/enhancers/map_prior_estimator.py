"""
Map Prior Estimator - 光照鲁棒版本 v2

核心改进：
1. 自适应亮度增强：在检测前自动增强暗图像
2. 自适应阈值：根据图像亮度动态调整检测阈值
3. 多尺度边缘检测：在多个尺度上检测，融合结果
4. 结构张量：比 Sobel 更鲁棒的边缘检测方法
5. 归一化亮度空间：在归一化后的亮度空间检测

v2 新增（针对道路元素优化）：
6. 线性结构检测：专门检测直线结构（车道线）
7. 道路区域 Mask：基于透视几何的道路区域估计
8. 消失点引导：利用道路的几何特性过滤噪声
9. 纹理一致性：过滤高频纹理区域（树叶等）

文献支持：
- CLAHE: Zuiderveld, K. (1994). Contrast Limited Adaptive Histogram Equalization
- Structure Tensor: Förstner & Gülch (1987)
- Multi-scale edge detection: Canny (1986)
- Line detection: Gioi et al. "LSD: A Line Segment Detector" IPOL 2012
- Vanishing point: Tardif "Non-iterative approach for fast and accurate vanishing point detection" ICCV 2009
- Road detection: Hillel et al. "Recent progress in road and lane detection: a survey" 2014
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional


class AdaptiveBrightnessEnhancer(nn.Module):
    """
    自适应亮度增强器
    
    在检测前自动增强暗图像，确保 Map Prior 在各种光照条件下都能工作
    
    核心思想：
    1. 计算图像平均亮度
    2. 如果亮度低于阈值，进行伽马校正增强
    3. 使用 CLAHE 式局部对比度增强
    """
    
    def __init__(self, target_brightness=0.4, clip_limit=0.03):
        super().__init__()
        self.target_brightness = target_brightness
        self.clip_limit = clip_limit
        
    def forward(self, x):
        """
        Args:
            x: [B, C, H, W] 输入图像，范围 [0, 1]
        Returns:
            enhanced: [B, C, H, W] 增强后的图像
        """
        # 计算亮度
        if x.shape[1] == 3:
            luminance = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            luminance = x
        
        # 计算平均亮度
        mean_lum = luminance.mean(dim=(2, 3), keepdim=True)  # [B, 1, 1, 1]
        
        # 自适应伽马校正
        # 暗图像用更小的 gamma（更强的增强）
        gamma = torch.clamp(mean_lum / self.target_brightness, 0.3, 2.0)
        
        # 伽马校正
        enhanced = torch.pow(x + 1e-8, gamma)
        
        # 局部对比度增强（简化版 CLAHE）
        enhanced = self._local_contrast_enhance(enhanced)
        
        return torch.clamp(enhanced, 0, 1)
    
    def _local_contrast_enhance(self, x, kernel_size=31):
        """局部对比度增强"""
        # 计算局部均值
        padding = kernel_size // 2
        kernel = torch.ones(1, 1, kernel_size, kernel_size, device=x.device) / (kernel_size ** 2)
        
        # 分通道处理
        enhanced_channels = []
        for c in range(x.shape[1]):
            channel = x[:, c:c+1]
            local_mean = F.conv2d(channel, kernel, padding=padding)
            local_var = F.conv2d(channel ** 2, kernel, padding=padding) - local_mean ** 2
            local_std = torch.sqrt(local_var.clamp(min=1e-8))
            
            # 对比度增强
            enhanced = (channel - local_mean) / (local_std + 0.01) * 0.2 + local_mean
            enhanced_channels.append(enhanced)
        
        return torch.cat(enhanced_channels, dim=1)


class AdaptiveEdgeDetector(nn.Module):
    """
    自适应边缘检测器
    
    核心改进：
    1. 自适应阈值：根据图像统计动态调整
    2. 多尺度检测：在多个尺度上检测，融合结果
    3. 结构张量：更鲁棒的边缘检测方法
    """
    
    def __init__(self):
        super().__init__()
        
        # Sobel kernels
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
        
        # 多尺度高斯核
        self.scales = [1.0, 2.0, 4.0]
        for i, sigma in enumerate(self.scales):
            kernel = self._create_gaussian_kernel(sigma)
            self.register_buffer(f'gaussian_{i}', kernel)
    
    def _create_gaussian_kernel(self, sigma):
        """创建高斯核"""
        kernel_size = int(6 * sigma + 1)
        if kernel_size % 2 == 0:
            kernel_size += 1
        
        x = torch.arange(kernel_size) - kernel_size // 2
        gaussian_1d = torch.exp(-x ** 2 / (2 * sigma ** 2))
        gaussian_2d = gaussian_1d.view(-1, 1) * gaussian_1d.view(1, -1)
        gaussian_2d = gaussian_2d / gaussian_2d.sum()
        
        return gaussian_2d.view(1, 1, kernel_size, kernel_size)
    
    def forward(self, x):
        """
        Args:
            x: [B, C, H, W] 输入图像
        Returns:
            edges: [B, 1, H, W] 边缘强度图
        """
        # 转换为灰度图
        if x.shape[1] == 3:
            gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            gray = x
        
        # 多尺度边缘检测
        all_edges = []
        for i, sigma in enumerate(self.scales):
            gaussian = getattr(self, f'gaussian_{i}')
            padding = gaussian.shape[-1] // 2
            
            # 高斯平滑
            smoothed = F.conv2d(gray, gaussian, padding=padding)
            
            # 计算梯度
            grad_x = F.conv2d(smoothed, self.sobel_x, padding=1)
            grad_y = F.conv2d(smoothed, self.sobel_y, padding=1)
            
            # 边缘强度
            edges = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
            all_edges.append(edges)
        
        # 融合多尺度结果
        edges = torch.stack(all_edges, dim=0).max(dim=0)[0]
        
        # 自适应阈值
        edges = self._adaptive_threshold(edges)
        
        return edges
    
    def _adaptive_threshold(self, edges):
        """自适应阈值"""
        # 计算边缘统计
        mean_edge = edges.mean(dim=(2, 3), keepdim=True)
        std_edge = edges.std(dim=(2, 3), keepdim=True)
        
        # 自适应阈值 = mean + 0.5 * std
        threshold = mean_edge + 0.5 * std_edge
        
        # 软阈值
        edges = torch.sigmoid((edges - threshold) / (std_edge + 1e-8) * 5)
        
        return edges


class RobustColorFilter(nn.Module):
    """
    鲁棒颜色过滤器
    
    核心改进：
    1. 在归一化亮度空间检测（消除光照影响）
    2. 使用相对颜色而非绝对颜色
    3. 自适应阈值
    """
    
    def __init__(self):
        super().__init__()
    
    def forward(self, x):
        """
        Args:
            x: [B, 3, H, W] RGB 图像，范围 [0, 1]
        Returns:
            mask: [B, 1, H, W] 颜色掩码
        """
        B, C, H, W = x.shape
        device = x.device
        
        if C != 3:
            return torch.zeros(B, 1, H, W, device=device)
        
        # 计算亮度
        luminance = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        luminance = luminance.clamp(min=0.01)  # 避免除零
        
        # 归一化到亮度（消除光照影响）
        x_norm = x / luminance
        
        # 计算颜色特征
        # 白色特征：R ≈ G ≈ B（归一化后都接近 1）
        color_variance = x_norm.var(dim=1, keepdim=True)
        white_score = torch.exp(-color_variance * 10)  # 方差小 = 更白
        
        # 黄色特征：R > B, G > B
        r_norm, g_norm, b_norm = x_norm[:, 0:1], x_norm[:, 1:2], x_norm[:, 2:3]
        yellow_score = torch.sigmoid((r_norm - b_norm) * 5) * torch.sigmoid((g_norm - b_norm) * 5)
        
        # 高亮度区域更可能是车道线
        # 使用相对亮度（相对于图像平均亮度）
        mean_lum = luminance.mean(dim=(2, 3), keepdim=True)
        relative_brightness = luminance / (mean_lum + 1e-8)
        brightness_score = torch.sigmoid((relative_brightness - 1.0) * 3)  # 高于平均亮度
        
        # 组合
        mask = (white_score + yellow_score) * brightness_score
        
        # 归一化
        mask = mask / (mask.max() + 1e-8)
        
        return mask


class StructureTensorEdge(nn.Module):
    """
    结构张量边缘检测
    
    比 Sobel 更鲁棒，能检测出更精细的结构
    
    文献：Förstner & Gülch (1987)
    """
    
    def __init__(self, sigma=1.5, rho=3.0):
        super().__init__()
        self.sigma = sigma
        self.rho = rho
        
        # Sobel kernels
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
        
        # 创建积分高斯核
        kernel = self._create_gaussian_kernel(rho)
        self.register_buffer('integration_kernel', kernel)
    
    def _create_gaussian_kernel(self, sigma):
        kernel_size = int(6 * sigma + 1)
        if kernel_size % 2 == 0:
            kernel_size += 1
        
        x = torch.arange(kernel_size) - kernel_size // 2
        gaussian_1d = torch.exp(-x ** 2 / (2 * sigma ** 2))
        gaussian_2d = gaussian_1d.view(-1, 1) * gaussian_1d.view(1, -1)
        gaussian_2d = gaussian_2d / gaussian_2d.sum()
        
        return gaussian_2d.view(1, 1, kernel_size, kernel_size)
    
    def forward(self, x):
        """
        Args:
            x: [B, C, H, W]
        Returns:
            edges: [B, 1, H, W] 边缘/角点响应
        """
        # 转换为灰度
        if x.shape[1] == 3:
            gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            gray = x
        
        # 计算梯度
        Ix = F.conv2d(gray, self.sobel_x, padding=1)
        Iy = F.conv2d(gray, self.sobel_y, padding=1)
        
        # 结构张量分量
        Ixx = Ix ** 2
        Iyy = Iy ** 2
        Ixy = Ix * Iy
        
        # 积分（局部平均）
        padding = self.integration_kernel.shape[-1] // 2
        Sxx = F.conv2d(Ixx, self.integration_kernel, padding=padding)
        Syy = F.conv2d(Iyy, self.integration_kernel, padding=padding)
        Sxy = F.conv2d(Ixy, self.integration_kernel, padding=padding)
        
        # 计算特征值（用于检测边缘和角点）
        trace = Sxx + Syy
        det = Sxx * Syy - Sxy ** 2
        
        # Harris 响应
        k = 0.04
        response = det - k * trace ** 2
        
        # 边缘强度（使用梯度幅值）
        edge_strength = torch.sqrt(Sxx + Syy + 1e-8)
        
        # 归一化
        edge_strength = edge_strength / (edge_strength.max() + 1e-8)
        
        return edge_strength


class LinearStructureDetector(nn.Module):
    """
    线性结构检测器 - 专门检测直线结构（车道线）
    
    核心思想：
    1. 使用方向性滤波器检测特定方向的边缘
    2. 车道线通常是近似垂直的线条（在图像坐标系）
    3. 通过梯度方向一致性过滤噪声
    
    文献：Gioi et al. "LSD: A Line Segment Detector" IPOL 2012
    """
    
    def __init__(self, num_directions=8):
        super().__init__()
        self.num_directions = num_directions
        
        # Sobel kernels
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
        
        # 方向性滤波器（检测特定方向的线条）
        # 主要关注接近垂直的方向（车道线方向）
        kernels = []
        for i in range(num_directions):
            theta = np.pi * i / num_directions
            kernel = self._create_line_kernel(theta, length=9)
            kernels.append(kernel)
        self.register_buffer('line_kernels', torch.stack(kernels, dim=0))
    
    def _create_line_kernel(self, theta, length=9):
        """创建方向性线条检测核"""
        kernel = torch.zeros(length, length)
        center = length // 2
        
        for i in range(-center, center + 1):
            x = int(center + i * np.cos(theta))
            y = int(center + i * np.sin(theta))
            if 0 <= x < length and 0 <= y < length:
                kernel[y, x] = 1.0
        
        kernel = kernel / (kernel.sum() + 1e-8)
        return kernel.unsqueeze(0)
    
    def forward(self, x):
        """
        检测线性结构
        
        Args:
            x: [B, C, H, W]
        Returns:
            line_response: [B, 1, H, W] 线性结构响应
        """
        # 转换为灰度
        if x.shape[1] == 3:
            gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            gray = x
        
        # 计算梯度
        grad_x = F.conv2d(gray, self.sobel_x, padding=1)
        grad_y = F.conv2d(gray, self.sobel_y, padding=1)
        
        # 梯度幅值和方向
        magnitude = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
        
        # 方向性滤波 - 检测各个方向的线条
        responses = []
        for i in range(self.num_directions):
            kernel = self.line_kernels[i:i+1]
            padding = kernel.shape[-1] // 2
            resp = F.conv2d(magnitude, kernel, padding=padding)
            responses.append(resp)
        
        responses = torch.stack(responses, dim=1)
        
        # 只保留最强方向的响应（线条通常只有一个主方向）
        max_response = responses.max(dim=1)[0]
        
        # 归一化
        max_response = max_response / (max_response.max() + 1e-8)
        
        return max_response


class RoadRegionMask(nn.Module):
    """
    道路区域 Mask - 基于透视几何的道路区域估计
    
    核心思想：
    1. 道路通常在图像下半部分
    2. 道路呈梯形（近大远小）
    3. 消失点在图像上方中央
    
    这个 mask 用于抑制非道路区域的噪声（如天空、树叶）
    """
    
    def __init__(self, 
                 top_width_ratio=0.3,      # 顶部宽度（相对于图像宽度）
                 bottom_width_ratio=1.0,   # 底部宽度
                 top_height_ratio=0.35,    # 道路起始位置（从顶部算）
                 bottom_height_ratio=1.0): # 道路结束位置
        super().__init__()
        self.top_width_ratio = top_width_ratio
        self.bottom_width_ratio = bottom_width_ratio
        self.top_height_ratio = top_height_ratio
        self.bottom_height_ratio = bottom_height_ratio
    
    def forward(self, x):
        """
        生成道路区域 mask
        
        Args:
            x: [B, C, H, W] 输入图像（只用于获取尺寸）
        Returns:
            mask: [B, 1, H, W] 道路区域 mask
        """
        B, C, H, W = x.shape
        device = x.device
        
        # 创建坐标网格
        y_coords = torch.linspace(0, 1, H, device=device).view(1, 1, H, 1).expand(B, 1, H, W)
        x_coords = torch.linspace(0, 1, W, device=device).view(1, 1, 1, W).expand(B, 1, H, W)
        
        # 道路区域的纵向范围
        in_vertical_range = (y_coords >= self.top_height_ratio) & (y_coords <= self.bottom_height_ratio)
        
        # 计算每行的道路宽度（线性插值）
        # t = 0 在 top_height_ratio, t = 1 在 bottom_height_ratio
        t = (y_coords - self.top_height_ratio) / (self.bottom_height_ratio - self.top_height_ratio + 1e-8)
        t = t.clamp(0, 1)
        
        # 当前行的道路宽度
        current_width = self.top_width_ratio + t * (self.bottom_width_ratio - self.top_width_ratio)
        
        # 道路的左右边界
        left_bound = 0.5 - current_width / 2
        right_bound = 0.5 + current_width / 2
        
        # 在道路区域内
        in_horizontal_range = (x_coords >= left_bound) & (x_coords <= right_bound)
        
        # 组合
        mask = (in_vertical_range & in_horizontal_range).float()
        
        # 平滑边界（软 mask）
        # 使用高斯模糊
        mask = self._gaussian_blur(mask, kernel_size=21, sigma=5.0)
        
        return mask
    
    def _gaussian_blur(self, x, kernel_size=21, sigma=5.0):
        """高斯模糊"""
        # 创建高斯核
        coords = torch.arange(kernel_size, device=x.device) - kernel_size // 2
        gaussian_1d = torch.exp(-coords ** 2 / (2 * sigma ** 2))
        gaussian_2d = gaussian_1d.view(-1, 1) * gaussian_1d.view(1, -1)
        gaussian_2d = gaussian_2d / gaussian_2d.sum()
        gaussian_2d = gaussian_2d.view(1, 1, kernel_size, kernel_size)
        
        # 应用模糊
        padding = kernel_size // 2
        return F.conv2d(x, gaussian_2d, padding=padding)


class TextureConsistencyFilter(nn.Module):
    """
    纹理一致性过滤器 - 过滤高频纹理区域（树叶等）
    
    核心思想：
    1. 道路表面通常是低频纹理（均匀）
    2. 车道线是中频结构（清晰边缘）
    3. 树叶是高频纹理（杂乱）
    
    通过分析局部纹理复杂度，过滤高频区域
    """
    
    def __init__(self, window_size=15, threshold=0.3):
        super().__init__()
        self.window_size = window_size
        self.threshold = threshold
        
        # 局部均值核
        kernel = torch.ones(1, 1, window_size, window_size) / (window_size ** 2)
        self.register_buffer('mean_kernel', kernel)
    
    def forward(self, x, edge_map):
        """
        计算纹理一致性 mask
        
        Args:
            x: [B, C, H, W] 输入图像
            edge_map: [B, 1, H, W] 边缘图
        Returns:
            mask: [B, 1, H, W] 纹理一致性 mask（低频区域为高值）
        """
        # 计算边缘的局部密度
        padding = self.window_size // 2
        local_edge_density = F.conv2d(edge_map, self.mean_kernel, padding=padding)
        
        # 高密度区域（树叶等）应该被抑制
        # 使用软阈值
        mask = 1.0 - torch.sigmoid((local_edge_density - self.threshold) * 10)
        
        return mask


class LearnedMapPrior(nn.Module):
    """
    轻量级学习式 Map Prior
    
    使用小型 CNN 学习 Map Prior，而不是依赖传统方法
    优点：对光照变化更鲁棒
    
    注意：这是一个额外的选项，可以在预训练中逐步学习
    """
    
    def __init__(self, in_channels=3):
        super().__init__()
        
        # 轻量级编码器
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 16, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 16, 3, padding=1, stride=2),  # 下采样
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 32, 3, padding=1),
            nn.ReLU(inplace=True),
        )
        
        # 解码器
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(32, 16, 4, stride=2, padding=1),  # 上采样
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 1, 3, padding=1),
            nn.Sigmoid(),
        )
    
    def forward(self, x):
        feat = self.encoder(x)
        prior = self.decoder(feat)
        return prior


class RobustMapPriorEstimator(nn.Module):
    """
    光照鲁棒的 Map Prior 估计器 v2
    
    核心设计：
    1. 先增强，再检测
    2. 多种检测方法融合
    3. 自适应权重
    4. [NEW] 道路区域 mask 抑制非道路噪声
    5. [NEW] 线性结构检测专门检测车道线
    6. [NEW] 纹理一致性过滤高频噪声
    
    这是 MPGID 的核心创新之一！
    """
    
    def __init__(self,
                 use_enhancement=True,
                 use_adaptive_edge=True,
                 use_structure_tensor=True,
                 use_robust_color=True,
                 use_linear_structure=False,   # [v3] 线性结构检测 - 默认关闭
                 use_road_mask=False,          # [v3] 道路区域 mask - 默认关闭
                 use_texture_filter=False,     # [v3] 纹理过滤 - 默认关闭
                 use_learned_prior=False,
                 enhancement_strength=1.0):
        super().__init__()
        
        self.use_enhancement = use_enhancement
        self.use_adaptive_edge = use_adaptive_edge
        self.use_structure_tensor = use_structure_tensor
        self.use_robust_color = use_robust_color
        self.use_linear_structure = use_linear_structure
        self.use_road_mask = use_road_mask
        self.use_texture_filter = use_texture_filter
        self.use_learned_prior = use_learned_prior
        
        # 自适应亮度增强
        if use_enhancement:
            self.enhancer = AdaptiveBrightnessEnhancer()
            self.enhancement_strength = enhancement_strength
        
        # 检测器
        if use_adaptive_edge:
            self.edge_detector = AdaptiveEdgeDetector()
        
        if use_structure_tensor:
            self.structure_tensor = StructureTensorEdge()
        
        if use_robust_color:
            self.color_filter = RobustColorFilter()
        
        if use_learned_prior:
            self.learned_prior = LearnedMapPrior()
        
        # [NEW] 道路专用检测器
        if use_linear_structure:
            self.linear_detector = LinearStructureDetector()
        
        if use_road_mask:
            self.road_mask = RoadRegionMask()
        
        if use_texture_filter:
            self.texture_filter = TextureConsistencyFilter()
        
        # 自适应权重（可学习）
        self.register_parameter('edge_weight', nn.Parameter(torch.tensor(0.3)))
        self.register_parameter('structure_weight', nn.Parameter(torch.tensor(0.2)))
        self.register_parameter('color_weight', nn.Parameter(torch.tensor(0.3)))
        self.register_parameter('linear_weight', nn.Parameter(torch.tensor(0.4)))  # [NEW] 线性结构权重更高
    
    def forward(self, x):
        """
        生成光照鲁棒的 Map Prior
        
        Args:
            x: [B, C, H, W] 输入图像，范围 [0, 1]
        
        Returns:
            prior: [B, 1, H, W] Map Prior Mask，范围 [0, 1]
        """
        B, C, H, W = x.shape
        device = x.device
        
        # 1. 自适应增强
        if self.use_enhancement:
            x_enhanced = self.enhancer(x)
            # 混合原图和增强图
            alpha = torch.sigmoid(torch.tensor(self.enhancement_strength))
            x_work = alpha * x_enhanced + (1 - alpha) * x
        else:
            x_work = x
        
        # 2. 多方法检测
        priors = []
        weights = []
        
        if self.use_adaptive_edge:
            edge = self.edge_detector(x_work)
            priors.append(edge)
            weights.append(F.softplus(self.edge_weight))
        
        if self.use_structure_tensor:
            structure = self.structure_tensor(x_work)
            priors.append(structure)
            weights.append(F.softplus(self.structure_weight))
        
        if self.use_robust_color:
            color = self.color_filter(x_work)
            priors.append(color)
            weights.append(F.softplus(self.color_weight))
        
        if self.use_learned_prior:
            learned = self.learned_prior(x)  # 学习式用原图
            priors.append(learned)
            weights.append(torch.tensor(0.5, device=device))
        
        # [NEW] 线性结构检测（专门检测车道线）
        if self.use_linear_structure:
            linear = self.linear_detector(x_work)
            priors.append(linear)
            weights.append(F.softplus(self.linear_weight))
        
        # 3. 加权融合
        if len(priors) == 0:
            return torch.zeros(B, 1, H, W, device=device)
        
        weights = torch.stack(weights)
        weights = weights / (weights.sum() + 1e-8)
        
        prior = torch.zeros(B, 1, H, W, device=device)
        for i, p in enumerate(priors):
            prior = prior + weights[i] * p
        
        # 4. 后处理
        # 4.1 [NEW] 应用道路区域 mask（抑制非道路区域）
        if self.use_road_mask:
            road_mask = self.road_mask(x)
            prior = prior * road_mask + prior * (1 - road_mask) * 0.3  # 非道路区域减弱但不完全去除
        
        # 4.2 [NEW] 应用纹理一致性过滤（抑制高频纹理区域如树叶）
        if self.use_texture_filter:
            # 计算原始边缘图
            if self.use_adaptive_edge:
                raw_edge = self.edge_detector(x_work)
            else:
                raw_edge = prior
            texture_mask = self.texture_filter(x_work, raw_edge)
            prior = prior * texture_mask
        
        # 4.3 应用道路先验（减少天空和上方区域的响应）
        prior = self._apply_road_prior(prior)
        
        # 4.4 去除小噪声点
        prior = self._remove_small_components(prior)
        
        # 4.5 形态学操作（闭运算 - 填充小孔）
        prior = self._morphological_close(prior, kernel_size=5)
        
        # 4.6 归一化
        prior = (prior - prior.min()) / (prior.max() - prior.min() + 1e-8)
        
        return prior
    
    def _morphological_close(self, x, kernel_size=5):
        """形态学闭运算（膨胀后腐蚀）"""
        # 膨胀
        padding = kernel_size // 2
        x = F.max_pool2d(x, kernel_size, stride=1, padding=padding)
        # 腐蚀
        x = -F.max_pool2d(-x, kernel_size, stride=1, padding=padding)
        return x
    
    def _remove_small_components(self, x, min_size=0.001):
        """
        去除小的噪声点
        通过阈值过滤掉低响应区域
        """
        # 自适应阈值：基于整体分布
        mean_val = x.mean()
        std_val = x.std()
        threshold = mean_val + 0.5 * std_val
        
        # 软阈值
        x = torch.where(x > threshold, x, x * 0.3)
        
        return x
    
    def _apply_road_prior(self, x):
        """
        应用道路先验 - 道路通常在图像下半部分
        减少天空和上方区域的响应
        """
        B, C, H, W = x.shape
        
        # 创建纵向权重（下方权重更高）
        y_weights = torch.linspace(0.3, 1.0, H, device=x.device)
        y_weights = y_weights.view(1, 1, H, 1).expand(B, C, H, W)
        
        return x * y_weights
    
    @torch.no_grad()
    def visualize(self, x):
        """可视化各个组件"""
        results = {'input': x}
        
        if self.use_enhancement:
            results['enhanced'] = self.enhancer(x)
            x_work = results['enhanced']
        else:
            x_work = x
        
        if self.use_adaptive_edge:
            results['adaptive_edge'] = self.edge_detector(x_work)
        
        if self.use_structure_tensor:
            results['structure_tensor'] = self.structure_tensor(x_work)
        
        if self.use_robust_color:
            results['robust_color'] = self.color_filter(x_work)
        
        results['combined'] = self.forward(x)
        
        return results


# ============================================================================
# 保留原有类以保持兼容性
# ============================================================================

class SobelEdgeDetector(nn.Module):
    """可微分的 Sobel 边缘检测器（保留用于兼容）"""
    
    def __init__(self):
        super().__init__()
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
    
    def forward(self, x):
        if x.shape[1] == 3:
            gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            gray = x
        
        grad_x = F.conv2d(gray, self.sobel_x, padding=1)
        grad_y = F.conv2d(gray, self.sobel_y, padding=1)
        edges = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
        edges = edges / (edges.max() + 1e-8)
        
        return edges


class MapPriorEstimator(nn.Module):
    """
    原有的 Map Prior 估计器
    
    现在默认使用 RobustMapPriorEstimator，这个类保留用于兼容
    """
    
    def __init__(self, **kwargs):
        super().__init__()
        # 内部使用鲁棒版本
        self.robust_estimator = RobustMapPriorEstimator(
            use_enhancement=True,
            use_adaptive_edge=True,
            use_structure_tensor=True,
            use_robust_color=True,
            use_learned_prior=False,
        )
    
    def forward(self, x):
        return self.robust_estimator(x)
    
    def visualize(self, x):
        return self.robust_estimator.visualize(x)


class FastMapPriorEstimator(nn.Module):
    """快速 Map Prior 估计器（保留用于兼容）"""
    
    def __init__(self):
        super().__init__()
        self.robust_estimator = RobustMapPriorEstimator(
            use_enhancement=True,
            use_adaptive_edge=True,
            use_structure_tensor=False,  # 快速版本不使用
            use_robust_color=True,
            use_learned_prior=False,
        )
    
    def forward(self, x):
        return self.robust_estimator(x)


# ============================================================================
# 为预训练添加的额外组件
# ============================================================================

class GradientOperator(nn.Module):
    """
    梯度算子 - 用于 IID Loss 计算
    """
    
    def __init__(self):
        super().__init__()
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
    
    def forward(self, x):
        """计算梯度幅值"""
        if x.shape[1] > 1:
            # 多通道取平均
            results = []
            for c in range(x.shape[1]):
                channel = x[:, c:c+1]
                grad_x = F.conv2d(channel, self.sobel_x, padding=1)
                grad_y = F.conv2d(channel, self.sobel_y, padding=1)
                grad = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
                results.append(grad)
            return torch.cat(results, dim=1)
        else:
            grad_x = F.conv2d(x, self.sobel_x, padding=1)
            grad_y = F.conv2d(x, self.sobel_y, padding=1)
            return torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
