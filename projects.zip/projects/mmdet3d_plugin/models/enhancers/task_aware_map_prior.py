"""
Task-Aware Map Prior Estimator

核心思想：借鉴传统 Lane Detection 的成功经验，针对三类地图元素设计专门的检测器

为什么传统 Lane Detection 有效？
1. 它们知道自己在找什么（车道线）
2. 使用相对特征（梯度）而不是绝对亮度
3. 利用几何约束（方向、消失点）
4. 使用颜色比例而不是绝对颜色

三类地图元素：
1. 车道线 (Lane Lines): 白色/黄色，细长，指向消失点
2. 道路边界 (Road Boundaries): 长边缘，位于图像两侧
3. 人行横道 (Crosswalks): 规则条纹，周期性

文献支持：
- Lane Detection: "Robust Lane Detection from Continuous Driving Scenes Using Deep Neural Networks" (2017)
- Color-based: "Real Time Detection of Lane Markers in Urban Streets" (2009)
- Gradient-based: "A Tutorial on Lane Detection using OpenCV" - 经典 Sobel + 方向滤波
- Crosswalk: "Zebra-crossing detection based on blob analysis and local features" (2015)
- IPM: "Inverse Perspective Mapping Simplifies Optical Flow Computation" (1990)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Tuple, Optional


class LaneLinePrior(nn.Module):
    """
    车道线先验检测器（白天+夜间自适应）
    
    白天策略：颜色 + 方向 + 对比度
    夜间策略：局部对比度为主（车道线反光）+ 更强的几何约束
    
    文献：
    - "Real Time Detection of Lane Markers in Urban Streets" ICIP 2009
    - "Robust Lane Detection at Night" IV 2014
    """
    
    def __init__(self,
                 white_threshold=0.6,
                 yellow_h_range=(15, 35),
                 direction_tolerance=45,
                 min_contrast=0.05,
                 night_brightness_threshold=0.25):  # 夜间判断阈值
        super().__init__()
        self.white_threshold = white_threshold
        self.yellow_h_range = yellow_h_range
        self.direction_tolerance = np.deg2rad(direction_tolerance)
        self.min_contrast = min_contrast
        self.night_threshold = night_brightness_threshold
        
        # Sobel 算子
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
    
    def forward(self, img: torch.Tensor, force_day_mode: bool = False) -> torch.Tensor:
        """
        Args:
            img: [B, 3, H, W] RGB 图像，范围 [0, 1]
            force_day_mode: 是否强制使用白天模式（用于增强后的夜间图像）
        Returns:
            prior: [B, 1, H, W] 车道线先验概率
        """
        B, C, H, W = img.shape[0], img.shape[1], img.shape[2], img.shape[3]
        device = img.device
        
        # 计算图像亮度，判断是否为夜间
        gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        mean_brightness = gray.mean()
        
        # 如果 force_day_mode，强制使用白天策略
        is_night = (mean_brightness < self.night_threshold) and (not force_day_mode)
        
        # 空间约束：只关注道路区域（图像下半部分）
        road_mask = torch.zeros(1, 1, H, W, device=device)
        road_start = int(H * 0.4)  # 上 40% 完全忽略
        road_mask[:, :, road_start:, :] = 1.0
        # 渐变过渡
        for y in range(int(H * 0.35), road_start):
            road_mask[:, :, y, :] = (y - int(H * 0.35)) / (road_start - int(H * 0.35)) * 0.3
        
        if is_night:
            # ========== 夜间策略 ==========
            # 夜间主要依赖局部对比度（车道线反光）
            
            # 1. 强力亮度增强
            enhanced = self._night_enhance(gray)
            
            # 2. 局部对比度检测（夜间核心）
            contrast_mask = self._detect_local_contrast_night(enhanced)
            
            # 3. 方向约束（更严格）
            direction_mask = self._detect_lane_direction(img)
            
            # 4. 过滤大面积反光区域
            reflection_mask = self._filter_reflections(gray)
            
            # 夜间融合：对比度 * 方向 * 空间 * 非反光
            prior = contrast_mask * direction_mask * road_mask * reflection_mask
            
            # 5. 【新增】纵向连续性约束 - 车道线必须纵向连续
            prior = self._enforce_vertical_continuity(prior, min_length=40)
            
        else:
            # ========== 白天策略 ==========
            # 1. 颜色检测
            color_mask = self._detect_lane_colors(img)
            
            # 2. 局部对比度检测
            contrast_mask = self._detect_local_contrast(img)
            
            # 3. 方向约束
            direction_mask = self._detect_lane_direction(img)
            
            # 4. 过滤高亮点
            highlight_mask = (gray < 0.85).float()
            
            # 白天融合
            prior = color_mask * (contrast_mask + direction_mask).clamp(0, 1) * road_mask * highlight_mask
        
        return prior
    
    def _night_enhance(self, gray: torch.Tensor) -> torch.Tensor:
        """夜间图像增强"""
        # 强力伽马校正
        enhanced = torch.pow(gray + 1e-8, 0.4)
        
        # CLAHE 式局部对比度增强
        local_mean = F.avg_pool2d(enhanced, 31, stride=1, padding=15)
        local_var = F.avg_pool2d(enhanced ** 2, 31, stride=1, padding=15) - local_mean ** 2
        local_std = torch.sqrt(local_var.clamp(min=1e-8))
        enhanced = (enhanced - local_mean) / (local_std + 0.01) * 0.3 + 0.5
        
        return enhanced.clamp(0, 1)
    
    def _detect_local_contrast_night(self, gray: torch.Tensor) -> torch.Tensor:
        """夜间局部对比度检测（更敏感）"""
        # 使用更小的窗口，检测细节
        local_mean = F.avg_pool2d(gray, 21, stride=1, padding=10)
        local_var = F.avg_pool2d(gray ** 2, 21, stride=1, padding=10) - local_mean ** 2
        local_std = torch.sqrt(local_var.clamp(min=1e-8))
        
        # 归一化对比度
        contrast = (gray - local_mean) / (local_std + 1e-8)
        
        # 夜间阈值更低
        contrast_mask = (contrast > 1.0).float()
        
        return contrast_mask
    
    def _filter_reflections(self, gray: torch.Tensor) -> torch.Tensor:
        """过滤大面积反光区域"""
        # 检测高亮区域
        bright = (gray > 0.5).float()
        
        # 膨胀后腐蚀，保留大面积区域
        dilated = F.max_pool2d(bright, 15, stride=1, padding=7)
        # 这些大面积高亮区域是反光，需要过滤
        reflection_area = F.avg_pool2d(dilated, 31, stride=1, padding=15) > 0.3
        
        # 返回非反光区域
        return (~reflection_area).float()
    
    def _enforce_vertical_continuity(self, prior: torch.Tensor, min_length: int = 50) -> torch.Tensor:
        """
        强制纵向连续性约束
        
        车道线应该是纵向连续的，断断续续的噪点要过滤掉
        """
        B, C, H, W = prior.shape
        
        # 1. 纵向膨胀（连接接近的点）
        vertical_dilate = F.max_pool2d(prior, kernel_size=(15, 3), stride=1, padding=(7, 1))
        
        # 2. 纵向连续性检测（使用平均池化）
        vertical_avg = F.avg_pool2d(vertical_dilate, kernel_size=(min_length, 1), 
                                     stride=1, padding=(min_length//2, 0))
        
        # 截断到原始尺寸
        if vertical_avg.shape[2] > H:
            vertical_avg = vertical_avg[:, :, :H, :]
        elif vertical_avg.shape[2] < H:
            vertical_avg = F.pad(vertical_avg, (0, 0, 0, H - vertical_avg.shape[2]))
        
        # 如果平均值 > 0.25，说明这一列是连续的
        continuity_mask = (vertical_avg > 0.25).float()
        
        # 3. 膨胀这个 mask
        continuity_mask = F.max_pool2d(continuity_mask, kernel_size=(31, 1), stride=1, padding=(15, 0))
        
        # 再次截断
        if continuity_mask.shape[2] > H:
            continuity_mask = continuity_mask[:, :, :H, :]
        
        # 4. 与原 prior 相交
        result = prior * continuity_mask
        
        # 5. 去除小的孤立点
        result = self._remove_small_regions(result, min_size=15)
        
        return result
    
    def _remove_small_regions(self, mask: torch.Tensor, min_size: int = 20) -> torch.Tensor:
        """去除小的孤立区域"""
        # 先腐蚀去除小点
        eroded = -F.max_pool2d(-mask, min_size // 2, stride=1, padding=min_size // 4)
        # 再膨胀恢复
        dilated = F.max_pool2d(eroded, min_size // 2, stride=1, padding=min_size // 4)
        # 与原 mask 相交
        return mask * (dilated > 0).float()
    
    def _detect_lane_colors(self, img: torch.Tensor) -> torch.Tensor:
        """
        检测白色和黄色（使用颜色比例，对光照鲁棒）
        
        白色：R ≈ G ≈ B，且亮度较高
        黄色：R > G >> B，Hue 在特定范围
        """
        R, G, B = img[:, 0:1], img[:, 1:2], img[:, 2:3]
        
        # 亮度
        luminance = 0.299 * R + 0.587 * G + 0.114 * B
        
        # 白色检测：RGB 差异小 + 亮度高
        # 使用相对差异（归一化），对光照变化鲁棒
        max_rgb = torch.max(torch.max(R, G), B) + 1e-8
        min_rgb = torch.min(torch.min(R, G), B)
        rgb_range = (max_rgb - min_rgb) / max_rgb  # 饱和度
        
        # 白色：低饱和度 + 相对较高的亮度
        # 使用局部亮度比较而不是绝对阈值
        local_mean = F.avg_pool2d(luminance, 31, stride=1, padding=15)
        relative_brightness = luminance / (local_mean + 1e-8)
        
        white_mask = (rgb_range < 0.3) * (relative_brightness > 1.2)
        
        # 黄色检测：R > G > B 且比例符合
        yellow_ratio1 = R / (G + 1e-8)  # R/G 应该 > 1
        yellow_ratio2 = G / (B + 1e-8)  # G/B 应该 > 1.5
        yellow_mask = (yellow_ratio1 > 1.0) * (yellow_ratio1 < 1.5) * (yellow_ratio2 > 1.5)
        
        # 合并
        color_mask = (white_mask | yellow_mask).float()
        
        return color_mask
    
    def _detect_local_contrast(self, img: torch.Tensor) -> torch.Tensor:
        """
        检测局部对比度
        
        车道线比周围道路更亮（白天）或更亮（夜间反光）
        使用 局部像素 - 局部均值，对全局光照变化鲁棒
        """
        # 灰度
        gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        
        # 局部均值（使用大窗口）
        local_mean = F.avg_pool2d(gray, 51, stride=1, padding=25)
        
        # 局部标准差
        local_var = F.avg_pool2d(gray ** 2, 51, stride=1, padding=25) - local_mean ** 2
        local_std = torch.sqrt(local_var.clamp(min=1e-8))
        
        # 归一化的局部对比度
        contrast = (gray - local_mean) / (local_std + 1e-8)
        
        # 车道线应该是正对比度（比周围亮）
        contrast_mask = (contrast > 1.5).float()
        
        return contrast_mask
    
    def _detect_lane_direction(self, img: torch.Tensor) -> torch.Tensor:
        """
        检测指向消失点方向的边缘
        
        车道线在图像中应该近似指向图像顶部中心（消失点）
        """
        B, C, H, W = img.shape[0], img.shape[1], img.shape[2], img.shape[3]
        device = img.device
        
        # 灰度
        gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        
        # 计算梯度
        grad_x = F.conv2d(gray, self.sobel_x, padding=1)
        grad_y = F.conv2d(gray, self.sobel_y, padding=1)
        
        # 梯度幅值
        grad_mag = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
        
        # 边缘方向（垂直于梯度方向）
        edge_angle = torch.atan2(-grad_x, grad_y + 1e-8)  # 边缘方向
        
        # 消失点在图像顶部中心
        # 计算每个像素到消失点的方向（使用简化的坐标生成）
        y_coords = torch.linspace(0, 1, H, device=device).view(1, 1, H, 1).repeat(B, 1, 1, W)
        x_coords = torch.linspace(-0.5, 0.5, W, device=device).view(1, 1, 1, W).repeat(B, 1, H, 1)
        
        # 理想方向：从当前位置指向消失点 (0.5, 0)
        ideal_angle = torch.atan2(x_coords, -y_coords + 1e-8)
        
        # 方向差异
        angle_diff = torch.abs(edge_angle - ideal_angle)
        # 处理角度回绕
        angle_diff = torch.min(angle_diff, 2 * np.pi - angle_diff)
        
        # 只保留方向匹配的强边缘
        direction_mask = (angle_diff < self.direction_tolerance) * (grad_mag > 0.05)
        
        return direction_mask.float()


class RoadBoundaryPrior(nn.Module):
    """
    道路边界先验检测器
    
    基于道路边界的特点：
    1. 位置约束：道路边界通常在图像两侧
    2. 连续性：道路边界是长而连续的边缘
    3. 方向：边界线近似垂直（指向消失点）
    
    文献：
    - "Road boundary detection for autonomous vehicle" (2015)
    """
    
    def __init__(self, edge_threshold=0.1):
        super().__init__()
        self.edge_threshold = edge_threshold
        
        # Sobel 算子
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
    
    def forward(self, img: torch.Tensor, force_day_mode: bool = False) -> torch.Tensor:
        """
        Args:
            img: [B, 3, H, W] RGB 图像
            force_day_mode: 是否强制使用白天模式
        Returns:
            prior: [B, 1, H, W] 道路边界先验
        """
        B = img.shape[0]
        H = img.shape[2]
        W = img.shape[3]
        device = img.device
        
        # 灰度
        gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        
        # 判断是否夜间
        mean_brightness = gray.mean()
        is_night = (mean_brightness < 0.25) and (not force_day_mode)
        
        if is_night:
            # ========== 夜间策略 ==========
            # 增强
            enhanced = torch.pow(gray + 1e-8, 0.4)
            
            # 边缘检测
            grad_x = F.conv2d(enhanced, self.sobel_x, padding=1)
            grad_y = F.conv2d(enhanced, self.sobel_y, padding=1)
            grad_mag = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
        else:
            # 白天直接用原图
            grad_x = F.conv2d(gray, self.sobel_x, padding=1)
            grad_y = F.conv2d(gray, self.sobel_y, padding=1)
            grad_mag = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
        
        # 位置先验：道路边界在图像两侧
        side_weight = torch.zeros_like(gray)
        left_bound = int(W * 0.12)  # 左侧 12%
        side_weight[:, :, :, :left_bound] = 1.0
        right_bound = int(W * 0.88)  # 右侧 12%
        side_weight[:, :, :, right_bound:] = 1.0
        
        # 方向约束：边界应该近似垂直
        edge_angle = torch.atan2(grad_y, grad_x + 1e-8)
        vertical_weight = torch.cos(edge_angle) ** 2
        
        # 道路区域约束（下 35%）
        road_region = torch.zeros_like(gray)
        y_start = int(H * 0.65)
        for y in range(y_start, H):
            weight = (y - y_start) / (H - y_start)
            road_region[:, :, y, :] = weight
        
        if is_night:
            # 夜间过滤大面积反光
            bright = (gray > 0.3).float()
            large_area = F.avg_pool2d(bright, 31, stride=1, padding=15) > 0.4
            reflection_filter = (~large_area).float()
            
            prior = grad_mag * side_weight * vertical_weight * road_region * reflection_filter
        else:
            highlight_mask = (gray < 0.85).float()
            prior = grad_mag * side_weight * vertical_weight * road_region * highlight_mask
        
        # 阈值化
        if prior.max() > 0:
            threshold = prior.max() * 0.25
            prior = (prior > threshold).float()
        
        return prior


class CrosswalkPrior(nn.Module):
    """
    人行横道先验检测器
    
    基于人行横道（斑马线）的特点：
    1. 周期性条纹：白色条纹有规则间隔
    2. 方向：条纹接近水平
    3. 颜色：白色
    
    检测方法：
    1. 水平方向梯度检测条纹边缘
    2. 周期性分析（简化版 FFT）
    
    文献：
    - "Zebra crossing detection based on blob analysis and local features" (2015)
    - "Pedestrian crosswalk detection using Gabor filtering" (2012)
    """
    
    def __init__(self, stripe_period_range=(10, 50)):
        super().__init__()
        self.stripe_period_range = stripe_period_range
        
        # 水平 Sobel（检测垂直边缘，即水平条纹的边界）
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
        
        # Gabor 滤波器（检测周期性条纹）
        self._create_gabor_filters()
    
    def _create_gabor_filters(self):
        """创建 Gabor 滤波器组（用于检测不同周期的条纹）"""
        filters = []
        for period in [15, 25, 40]:  # 不同条纹周期
            gabor = self._make_gabor(kernel_size=31, sigma=5, theta=0, lambd=period)
            filters.append(gabor.squeeze(0))  # [1, kernel_size, kernel_size]
        self.register_buffer('gabor_filters', torch.stack(filters))  # [3, 1, 31, 31]
    
    def _make_gabor(self, kernel_size, sigma, theta, lambd):
        """生成 Gabor 滤波器"""
        x = torch.linspace(-kernel_size//2, kernel_size//2, kernel_size)
        y = torch.linspace(-kernel_size//2, kernel_size//2, kernel_size)
        # 兼容旧版本 PyTorch（不支持 indexing 参数）
        X, Y = torch.meshgrid(x, y)
        
        # 旋转
        x_theta = X * np.cos(theta) + Y * np.sin(theta)
        y_theta = -X * np.sin(theta) + Y * np.cos(theta)
        
        # Gabor 公式
        gabor = torch.exp(-0.5 * (x_theta**2 + y_theta**2) / sigma**2) * torch.cos(2 * np.pi * x_theta / lambd)
        
        return gabor.view(1, 1, kernel_size, kernel_size).float()
    
    def forward(self, img: torch.Tensor, force_day_mode: bool = False) -> torch.Tensor:
        """
        Args:
            img: [B, 3, H, W] RGB 图像
            force_day_mode: 是否强制使用白天模式
        Returns:
            prior: [B, 1, H, W] 人行横道先验
        """
        B, C, H, W = img.shape[0], img.shape[1], img.shape[2], img.shape[3]
        device = img.device
        
        # 灰度
        gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        
        # 判断是否夜间
        mean_brightness = gray.mean()
        is_night = (mean_brightness < 0.25) and (not force_day_mode)
        
        # 空间约束：斑马线在道路中央下半部分
        road_mask = torch.zeros_like(gray)
        y_start = int(H * 0.55)  # 下 45%
        x_margin = int(W * 0.2)  # 左右各留 20% 边距
        road_mask[:, :, y_start:, x_margin:W-x_margin] = 1.0
        
        if is_night:
            # ========== 夜间策略 ==========
            # 夜间斑马线检测主要靠反光的周期性
            
            # 1. 增强
            enhanced = torch.pow(gray + 1e-8, 0.4)
            
            # 2. 周期性检测（Gabor）
            gabor_responses = []
            for i in range(self.gabor_filters.shape[0]):
                gabor = self.gabor_filters[i:i+1].to(device)
                response = F.conv2d(enhanced, gabor, padding=gabor.shape[-1]//2)
                gabor_responses.append(torch.abs(response))
            
            gabor_max = torch.cat(gabor_responses, dim=1).max(dim=1, keepdim=True)[0]
            gabor_threshold = gabor_max.mean() + gabor_max.std() * 1.5
            gabor_mask = (gabor_max > gabor_threshold).float()
            
            # 3. 过滤大面积反光（车灯等）
            # 斑马线是条纹状，不是大面积的
            bright = (gray > 0.3).float()
            large_area = F.avg_pool2d(bright, 51, stride=1, padding=25) > 0.5
            reflection_filter = (~large_area).float()
            
            # 4. 检测条纹的规则间隔
            # 水平方向应该有周期性变化
            grad_y = F.conv2d(enhanced, self.sobel_y, padding=1)
            stripe_pattern = torch.abs(grad_y)
            stripe_threshold = stripe_pattern.mean() + stripe_pattern.std()
            stripe_mask = (stripe_pattern > stripe_threshold).float()
            
            prior = gabor_mask * road_mask * reflection_filter * stripe_mask
            
            # 5. 【新增】横向连续性约束 - 每条白线应该横向连续
            prior = self._enforce_horizontal_continuity(prior, min_length=80)
            
        else:
            # ========== 白天策略 ==========
            # 1. 颜色检测：白色区域
            R, G_ch, B_ch = img[:, 0:1], img[:, 1:2], img[:, 2:3]
            max_rgb = torch.max(torch.max(R, G_ch), B_ch) + 1e-8
            min_rgb = torch.min(torch.min(R, G_ch), B_ch)
            saturation = (max_rgb - min_rgb) / max_rgb
            white_mask = ((saturation < 0.2) & (gray > 0.3) & (gray < 0.9)).float()
            
            # 2. Gabor 周期性检测
            gabor_responses = []
            for i in range(self.gabor_filters.shape[0]):
                gabor = self.gabor_filters[i:i+1].to(device)
                response = F.conv2d(gray, gabor, padding=gabor.shape[-1]//2)
                gabor_responses.append(torch.abs(response))
            
            gabor_max = torch.cat(gabor_responses, dim=1).max(dim=1, keepdim=True)[0]
            gabor_threshold = gabor_max.mean() + gabor_max.std()
            gabor_mask = (gabor_max > gabor_threshold).float()
            
            # 3. 过滤高亮点
            highlight_mask = (gray < 0.85).float()
            
            prior = white_mask * gabor_mask * road_mask * highlight_mask
            
            # 4. 【新增】横向连续性约束
            prior = self._enforce_horizontal_continuity(prior, min_length=100)
        
        # 形态学操作
        prior = F.max_pool2d(prior, 5, stride=1, padding=2)
        prior = F.avg_pool2d(prior, 5, stride=1, padding=2)
        
        return prior
    
    def _enforce_horizontal_continuity(self, prior: torch.Tensor, min_length: int = 80) -> torch.Tensor:
        """
        强制横向连续性约束
        
        斑马线的每条白线应该是横向连续的
        断断续续的噪点要过滤掉
        """
        B, C, H, W = prior.shape
        
        # 1. 横向膨胀（连接接近的点）
        horizontal_dilate = F.max_pool2d(prior, kernel_size=(3, 15), stride=1, padding=(1, 7))
        
        # 2. 横向连续性检测（使用平均池化代替累积和）
        # 在水平方向做平均池化，如果平均值够高说明这一行是连续的
        horizontal_avg = F.avg_pool2d(horizontal_dilate, kernel_size=(1, min_length), 
                                       stride=1, padding=(0, min_length//2))
        
        # 截断到原始尺寸
        if horizontal_avg.shape[3] > W:
            horizontal_avg = horizontal_avg[:, :, :, :W]
        elif horizontal_avg.shape[3] < W:
            horizontal_avg = F.pad(horizontal_avg, (0, W - horizontal_avg.shape[3]))
        
        # 如果平均值 > 0.2，说明这一段是连续的
        continuity_mask = (horizontal_avg > 0.2).float()
        
        # 3. 膨胀这个 mask
        continuity_mask = F.max_pool2d(continuity_mask, kernel_size=(1, 31), stride=1, padding=(0, 15))
        
        # 再次截断
        if continuity_mask.shape[3] > W:
            continuity_mask = continuity_mask[:, :, :, :W]
        
        # 4. 与原 prior 相交
        result = prior * continuity_mask
        
        return result


class TaskAwareMapPrior(nn.Module):
    """
    任务感知的 Map Prior 估计器
    
    核心思想：针对三类地图元素分别设计检测器，而不是使用通用的边缘检测
    
    三类元素：
    1. 车道线 (Lane Lines): 使用颜色+方向+对比度
    2. 道路边界 (Road Boundaries): 使用位置+连续性+方向
    3. 人行横道 (Crosswalks): 使用颜色+周期性
    
    文献支持：
    - 这三类检测器各自基于传统计算机视觉中经过验证的方法
    - 详见各子模块的文档字符串
    """
    
    def __init__(self,
                 use_lane_prior=True,
                 use_boundary_prior=True,
                 use_crosswalk_prior=True,
                 lane_weight=1.0,
                 boundary_weight=0.5,
                 crosswalk_weight=0.8,
                 use_adaptive_enhancement=True):
        super().__init__()
        
        self.use_lane_prior = use_lane_prior
        self.use_boundary_prior = use_boundary_prior
        self.use_crosswalk_prior = use_crosswalk_prior
        
        # 可学习的权重
        self.lane_weight = nn.Parameter(torch.tensor(lane_weight))
        self.boundary_weight = nn.Parameter(torch.tensor(boundary_weight))
        self.crosswalk_weight = nn.Parameter(torch.tensor(crosswalk_weight))
        
        # 子检测器
        if use_lane_prior:
            self.lane_detector = LaneLinePrior()
        if use_boundary_prior:
            self.boundary_detector = RoadBoundaryPrior()
        if use_crosswalk_prior:
            self.crosswalk_detector = CrosswalkPrior()
        
        # 可选的自适应增强（用于极暗图像）
        self.use_adaptive_enhancement = use_adaptive_enhancement
        if use_adaptive_enhancement:
            self.enhancer = AdaptiveBrightnessEnhancer()
    
    def forward(self, img: torch.Tensor) -> torch.Tensor:
        """
        Args:
            img: [B, 3, H, W] RGB 图像，范围 [0, 1]
        Returns:
            prior: [B, 1, H, W] Map Prior
        """
        B, C, H, W = img.shape
        device = img.device
        
        # ===== 关键改动：先判断原始图像是否为夜间 =====
        gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        original_brightness = gray.mean()
        is_night = original_brightness < 0.25
        
        # 如果是夜间，增强后用白天策略检测
        if is_night and self.use_adaptive_enhancement:
            img_enhanced = self.enhancer(img)
            force_day_mode = True  # 告诉子检测器用白天策略
        else:
            img_enhanced = img
            force_day_mode = False
        
        # 收集各元素的 prior
        priors = []
        weights = []
        
        if self.use_lane_prior:
            lane_prior = self.lane_detector(img_enhanced, force_day_mode=force_day_mode)
            priors.append(lane_prior)
            weights.append(F.softplus(self.lane_weight))
        
        if self.use_boundary_prior:
            boundary_prior = self.boundary_detector(img_enhanced, force_day_mode=force_day_mode)
            priors.append(boundary_prior)
            weights.append(F.softplus(self.boundary_weight))
        
        if self.use_crosswalk_prior:
            crosswalk_prior = self.crosswalk_detector(img_enhanced, force_day_mode=force_day_mode)
            priors.append(crosswalk_prior)
            weights.append(F.softplus(self.crosswalk_weight))
        
        if len(priors) == 0:
            return torch.zeros(B, 1, H, W, device=device)
        
        # 加权融合（使用 max 而不是 sum，避免重叠区域过高）
        prior = torch.zeros(B, 1, H, W, device=device)
        total_weight = sum(weights)
        
        for p, w in zip(priors, weights):
            prior = torch.max(prior, p * (w / total_weight))
        
        # 后处理：形态学操作（填充小孔，去除噪声）
        prior = self._morphological_clean(prior)
        
        return prior
    
    def _morphological_clean(self, prior: torch.Tensor, 
                             close_kernel=5, open_kernel=3) -> torch.Tensor:
        """形态学清理：闭运算（填充小孔）+ 开运算（去除噪点）"""
        # 闭运算
        prior = F.max_pool2d(prior, close_kernel, stride=1, padding=close_kernel//2)
        prior = -F.max_pool2d(-prior, close_kernel, stride=1, padding=close_kernel//2)
        
        # 开运算
        prior = -F.max_pool2d(-prior, open_kernel, stride=1, padding=open_kernel//2)
        prior = F.max_pool2d(prior, open_kernel, stride=1, padding=open_kernel//2)
        
        return prior
    
    def get_individual_priors(self, img: torch.Tensor) -> dict:
        """获取各元素的单独 prior（用于调试和可视化）"""
        # 先判断原始图像是否为夜间
        gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        original_brightness = gray.mean()
        is_night = original_brightness < 0.25
        
        # 如果是夜间，增强后用白天策略
        if is_night and self.use_adaptive_enhancement:
            img_enhanced = self.enhancer(img)
            force_day_mode = True
        else:
            img_enhanced = img
            force_day_mode = False
        
        results = {'enhanced': img_enhanced}
        
        if self.use_lane_prior:
            results['lane'] = self.lane_detector(img_enhanced, force_day_mode=force_day_mode)
        if self.use_boundary_prior:
            results['boundary'] = self.boundary_detector(img_enhanced, force_day_mode=force_day_mode)
        if self.use_crosswalk_prior:
            results['crosswalk'] = self.crosswalk_detector(img_enhanced, force_day_mode=force_day_mode)
        
        return results


class AdaptiveBrightnessEnhancer(nn.Module):
    """
    强力自适应亮度增强器
    
    针对夜间图像的问题：
    1. 整体很暗
    2. 但有局部极亮区域（路灯、车灯）
    
    方法：分区域处理
    1. 先用强力 Gamma 校正提升整体亮度
    2. 用局部对比度增强（CLAHE-style）提升细节
    3. 抑制过亮区域，避免影响检测
    """
    
    def __init__(self, target_brightness=0.45):
        super().__init__()
        self.target_brightness = target_brightness
        
    def forward(self, x):
        """
        Args:
            x: [B, C, H, W] 输入图像，范围 [0, 1]
        Returns:
            enhanced: [B, C, H, W] 增强后的图像
        """
        B, C, H, W = x.shape
        device = x.device
        
        # 计算亮度
        luminance = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        mean_lum = luminance.mean()
        
        # 白天图像：轻度增强
        if mean_lum > 0.35:
            gamma = (mean_lum / self.target_brightness).clamp(0.6, 1.5)
            return torch.clamp(torch.pow(x + 1e-8, gamma), 0, 1)
        
        # ========== 夜间图像：强力增强 ==========
        
        # 1. 先识别并标记过亮区域（路灯、车灯）
        bright_mask = (luminance > 0.5).float()
        bright_mask = F.max_pool2d(bright_mask, 21, stride=1, padding=10)  # 膨胀
        
        # 2. 强力 Gamma 校正（针对暗区域）
        # 根据亮度自适应调整 gamma
        gamma = 0.3 + 0.4 * (mean_lum / 0.35).clamp(0, 1)  # gamma 在 0.3-0.7 之间
        enhanced = torch.pow(x + 1e-8, gamma)
        
        # 3. 局部对比度增强（简化 CLAHE）
        # 计算局部均值
        kernel_size = 31
        padding = kernel_size // 2
        kernel = torch.ones(1, 1, kernel_size, kernel_size, device=device) / (kernel_size ** 2)
        
        enhanced_channels = []
        for c in range(C):
            channel = enhanced[:, c:c+1]
            local_mean = F.conv2d(channel, kernel, padding=padding)
            
            # 增强对比度
            contrast = (channel - local_mean) * 2.0 + local_mean
            enhanced_channels.append(contrast)
        
        enhanced = torch.cat(enhanced_channels, dim=1)
        
        # 4. 抑制过亮区域（防止路灯影响检测）
        # 在过亮区域使用原始图像
        enhanced = enhanced * (1 - bright_mask) + x * bright_mask
        
        # 5. 最终归一化
        enhanced = enhanced.clamp(0, 1)
        
        # 6. 确保足够亮
        final_mean = enhanced.mean()
        if final_mean < 0.3:
            boost = 0.3 / (final_mean + 1e-8)
            enhanced = (enhanced * boost).clamp(0, 1)
        
        return enhanced
