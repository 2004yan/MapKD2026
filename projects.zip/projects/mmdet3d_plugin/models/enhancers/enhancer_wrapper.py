"""
光照增强器包装模块

提供统一的接口，方便在检测器中使用
"""

import torch
import torch.nn as nn
from mmcv.runner import BaseModule
from mmdet.models.builder import BACKBONES, build_backbone


@BACKBONES.register_module()
class LightEnhancer(BaseModule):
    """
    光照增强器包装类
    
    统一封装不同的增强器实现，提供：
    - 多视角图像批量处理
    - 可选的增强开关
    - 增强强度控制
    
    Args:
        enhancer_type: 增强器类型 ('zero_dce', 'zero_dce_pp')
        enhancer_cfg: 增强器配置
        enable: 是否启用增强（用于消融实验）
        intensity: 增强强度 [0, 1]，0表示不增强，1表示完全增强
    """
    
    ENHANCER_TYPES = {
        'zero_dce': dict(type='ZeroDCE'),
        'zero_dce_pp': dict(type='ZeroDCEPP'),
    }
    
    def __init__(self,
                 enhancer_type='zero_dce',
                 enhancer_cfg=None,
                 enable=True,
                 intensity=1.0,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.enable = enable
        self.intensity = intensity
        
        # 构建增强器
        if enhancer_cfg is None:
            enhancer_cfg = self.ENHANCER_TYPES.get(enhancer_type, {})
        
        self.enhancer = build_backbone(enhancer_cfg)
    
    def forward(self, img):
        """
        对输入图像进行增强
        
        Args:
            img: [B, N, C, H, W] 或 [B, C, H, W] 或 [B*N, C, H, W]
                 多视角图像张量
        
        Returns:
            enhanced: 增强后的图像，形状与输入相同
        """
        if not self.enable:
            return img
        
        original_shape = img.shape
        
        # 处理不同的输入形状
        if len(original_shape) == 5:
            # [B, N, C, H, W] -> [B*N, C, H, W]
            B, N, C, H, W = original_shape
            img = img.reshape(B * N, C, H, W)
            need_reshape = True
        else:
            need_reshape = False
        
        # 归一化到 [0, 1]（如果需要）
        if img.max() > 1.0:
            img_normalized = img / 255.0
            need_denormalize = True
        else:
            img_normalized = img
            need_denormalize = False
        
        # 增强
        enhanced = self.enhancer(img_normalized)
        
        # 强度混合：enhanced = original * (1 - intensity) + enhanced * intensity
        if self.intensity < 1.0:
            enhanced = img_normalized * (1 - self.intensity) + enhanced * self.intensity
        
        # 反归一化
        if need_denormalize:
            enhanced = enhanced * 255.0
        
        # 恢复形状
        if need_reshape:
            enhanced = enhanced.reshape(B, N, C, H, W)
        
        return enhanced
    
    def enhance_numpy_images(self, imgs, device='cuda'):
        """
        增强 numpy 格式的图像列表（用于数据管道）
        
        Args:
            imgs: list of numpy arrays, (H, W, C), uint8
            device: 计算设备
        
        Returns:
            enhanced_imgs: list of numpy arrays
        """
        import numpy as np
        
        if not self.enable:
            return imgs
        
        # 转换为 tensor
        tensors = []
        for img in imgs:
            t = torch.from_numpy(img.astype(np.float32) / 255.0)
            t = t.permute(2, 0, 1)  # HWC -> CHW
            tensors.append(t)
        
        batch = torch.stack(tensors, dim=0).to(device)
        
        # 增强
        with torch.no_grad():
            enhanced = self.enhancer(batch)
        
        # 转回 numpy
        enhanced_imgs = []
        for i in range(enhanced.shape[0]):
            e = enhanced[i].permute(1, 2, 0).cpu().numpy()  # CHW -> HWC
            e = (e * 255).clip(0, 255).astype(np.uint8)
            enhanced_imgs.append(e)
        
        return enhanced_imgs


class EnhancerWithLoss(nn.Module):
    """
    带损失计算的增强器
    
    用于端到端训练
    """
    
    def __init__(self, enhancer, loss_cfg=None):
        super().__init__()
        self.enhancer = enhancer
        
        # 默认损失配置
        if loss_cfg is None:
            loss_cfg = dict(
                spa_weight=1.0,
                exp_weight=10.0,
                col_weight=5.0,
                tv_weight=200.0,
                exp_mean=0.6
            )
        
        from .zero_dce import ZeroDCELoss, IdentityPreservationLoss
        self.enhancement_loss = ZeroDCELoss(**loss_cfg)
        self.identity_loss = IdentityPreservationLoss()
    
    def forward(self, img, compute_loss=False):
        """前向传播"""
        enhanced = self.enhancer(img)
        
        if compute_loss:
            loss_enhance, loss_dict = self.enhancement_loss(enhanced, img)
            return enhanced, loss_enhance, loss_dict
        
        return enhanced
