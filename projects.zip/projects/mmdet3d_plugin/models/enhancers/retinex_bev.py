"""
Retinex-BEV: Illumination-aware enhancement for BEV-based HD Map construction.

Reference:
- RetinexFormer (ICCV 2023)
- Retinex-BEVFormer paper for multi-view illumination consistency

Key components:
1. Illumination Estimator: Extract illumination prior and light-up features
2. MVB-Retinex: Multi-View Balanced Retinex for cross-view consistency
3. Feature Fusion: Combine illumination features with image features

ECCV-level Innovations:
4. Map-Element-Aware Illumination: Different illumination processing for different map elements
5. Query-Guided Illumination: Use MapTR queries to guide illumination feature retrieval
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from mmcv.runner import BaseModule
from mmdet.models import BACKBONES


class IlluminationEstimator(nn.Module):
    """
    Illumination Estimator based on Retinex theory.
    
    Input: Image I ∈ R^{H×W×3}
    Output: 
        - illu_fea: Illumination feature for downstream processing
        - illu_map: Illumination map for image enhancement
    
    Process:
        1. Compute illumination prior: Lp = mean(I, dim=channel)
        2. Concatenate [I, Lp] and process through convolutions
    """
    
    def __init__(self, n_fea_middle=40, n_fea_in=4, n_fea_out=3):
        """
        Args:
            n_fea_middle: Number of middle features
            n_fea_in: Input channels (3 RGB + 1 prior = 4)
            n_fea_out: Output illumination map channels
        """
        super().__init__()
        
        # 1x1 conv to fuse concatenation of I and Lp
        self.conv1 = nn.Conv2d(n_fea_in, n_fea_middle, kernel_size=1, bias=True)
        
        # 5x5 depth-wise separable conv for illumination estimation
        # Models interactions between regions under varying illumination
        self.depth_conv = nn.Conv2d(
            n_fea_middle, n_fea_middle, 
            kernel_size=5, padding=2, bias=True, 
            groups=n_fea_middle
        )
        
        # Output projection for illumination map
        self.conv2 = nn.Conv2d(n_fea_middle, n_fea_out, kernel_size=1, bias=True)
        
        # LeakyReLU activation
        self.lrelu = nn.LeakyReLU(0.1, inplace=True)
    
    def forward(self, img):
        """
        Args:
            img: Input image [B, 3, H, W]
        
        Returns:
            illu_fea: Illumination feature [B, n_fea_middle, H, W]
            illu_map: Illumination map [B, 3, H, W]
        """
        # Compute illumination prior: channel-wise mean
        # Lp = Mc(I) - average pixel values along channel dimension
        illu_prior = img.mean(dim=1, keepdim=True)  # [B, 1, H, W]
        
        # Concatenate image and prior
        x = torch.cat([img, illu_prior], dim=1)  # [B, 4, H, W]
        
        # Process through convolutions
        x = self.conv1(x)
        x = self.lrelu(x)
        illu_fea = self.depth_conv(x)  # [B, n_fea_middle, H, W]
        illu_map = self.conv2(illu_fea)  # [B, 3, H, W]
        
        return illu_fea, illu_map


class MVBRetinex(nn.Module):
    """
    Multi-View Balanced Retinex module.
    
    Constrains illumination features across overlapping regions of adjacent views
    to achieve multi-view consistency and smoothness.
    
    For nuScenes: O = 0.125 * W (overlap region width)
    """
    
    def __init__(self, overlap_ratio=0.125, epsilon=1e-6):
        """
        Args:
            overlap_ratio: Ratio of overlap region width to image width
            epsilon: Small value to avoid log(0)
        """
        super().__init__()
        self.overlap_ratio = overlap_ratio
        self.epsilon = epsilon
    
    def compute_overlap_weight(self, width, is_current=True):
        """
        Compute logarithmic weights for overlap region.
        Higher weight near center of overlap for stronger consistency.
        
        Args:
            width: Width of overlap region
            is_current: True for current image, False for adjacent image
        """
        # Normalized positions within overlap region
        x_norm = torch.linspace(0, 1, width)
        
        if is_current:
            # For current image overlap (right side): |log(1 - x + ε)|
            weights = torch.abs(torch.log(1 - x_norm + self.epsilon))
        else:
            # For adjacent image overlap (left side): |log(x + ε)|
            weights = torch.abs(torch.log(x_norm + self.epsilon))
        
        return weights
    
    def compute_consistency_loss(self, illu_fea_list):
        """
        Compute weighted MSE loss for illumination consistency across views.
        
        Args:
            illu_fea_list: List of illumination features for each view
                           [N_view, B, C, H, W]
        
        Returns:
            consistency_loss: Weighted MSE loss across all adjacent view pairs
        """
        if len(illu_fea_list) < 2:
            return torch.tensor(0.0, device=illu_fea_list[0].device)
        
        total_loss = 0.0
        num_views = len(illu_fea_list)
        
        # nuScenes camera order: FRONT, FRONT_RIGHT, FRONT_LEFT, BACK, BACK_LEFT, BACK_RIGHT
        # Adjacent pairs for overlap: (0,1), (0,2), (3,4), (3,5), (4,5), (1,5)
        # Simplified: consider circular adjacency
        adjacent_pairs = [
            (0, 1),  # FRONT - FRONT_RIGHT
            (0, 2),  # FRONT - FRONT_LEFT
            (1, 5),  # FRONT_RIGHT - BACK_RIGHT
            (2, 4),  # FRONT_LEFT - BACK_LEFT
            (3, 4),  # BACK - BACK_LEFT
            (3, 5),  # BACK - BACK_RIGHT
        ]
        
        B, C, H, W = illu_fea_list[0].shape
        overlap_width = int(W * self.overlap_ratio)
        
        if overlap_width < 2:
            return torch.tensor(0.0, device=illu_fea_list[0].device)
        
        # Compute weights
        weight_current = self.compute_overlap_weight(overlap_width, is_current=True)
        weight_adjacent = self.compute_overlap_weight(overlap_width, is_current=False)
        weight_current = weight_current.to(illu_fea_list[0].device)
        weight_adjacent = weight_adjacent.to(illu_fea_list[0].device)
        
        for i, j in adjacent_pairs:
            if i >= num_views or j >= num_views:
                continue
            
            # Get overlap regions
            # Current image: right overlap [W-O, W]
            # Adjacent image: left overlap [0, O]
            fea_i_overlap = illu_fea_list[i][:, :, :, -overlap_width:]  # [B, C, H, O]
            fea_j_overlap = illu_fea_list[j][:, :, :, :overlap_width]   # [B, C, H, O]
            
            # Compute weighted MSE
            diff = fea_i_overlap - fea_j_overlap
            diff_sq = diff ** 2
            
            # Apply weights: broadcast [O] to [B, C, H, O]
            weighted_diff_sq = diff_sq * weight_current.view(1, 1, 1, -1)
            
            # Sum and normalize
            loss = weighted_diff_sq.mean()
            total_loss = total_loss + loss
        
        return total_loss / len(adjacent_pairs)
    
    def forward(self, illu_fea_list):
        """
        Args:
            illu_fea_list: List of illumination features [N_view, B, C, H, W]
        
        Returns:
            loss: Consistency loss for training
        """
        return self.compute_consistency_loss(illu_fea_list)


class RetinexBEVFusion(nn.Module):
    """
    Fuse illumination features with image features before BEV encoding.
    
    Fusion methods:
        - 'add': Element-wise addition (recommended by paper)
        - 'mul': Element-wise multiplication
        - 'concat': Concatenation followed by conv
    """
    
    def __init__(self, illu_channels, img_channels, fusion_type='add'):
        """
        Args:
            illu_channels: Number of illumination feature channels
            img_channels: Number of image feature channels
            fusion_type: 'add', 'mul', or 'concat'
        """
        super().__init__()
        self.fusion_type = fusion_type
        
        # Channel adjustment for illumination features
        # 使用 GroupNorm 代替 BatchNorm2d，对 fp16 混合精度训练更友好
        num_groups = min(32, img_channels // 4) if img_channels >= 32 else 1
        self.illu_adapt = nn.Sequential(
            nn.Conv2d(illu_channels, img_channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups, img_channels),
            nn.ReLU(inplace=True)
        )
        
        if fusion_type == 'concat':
            self.fusion_conv = nn.Sequential(
                nn.Conv2d(img_channels * 2, img_channels, kernel_size=1, bias=False),
                nn.GroupNorm(num_groups, img_channels),
                nn.ReLU(inplace=True)
            )
    
    def forward(self, img_feat, illu_fea):
        """
        Args:
            img_feat: Image features [B, C, H, W]
            illu_fea: Illumination features [B, C_illu, H_illu, W_illu]
        
        Returns:
            fused_feat: Fused features [B, C, H, W]
        """
        # 确保输入是连续内存，避免 cuDNN 错误
        illu_fea = illu_fea.contiguous()
        
        # **重要**：先下采样 illu_fea 到目标尺寸，避免在高分辨率上做通道变换导致内存爆炸
        if illu_fea.shape[2:] != img_feat.shape[2:]:
            illu_fea = F.adaptive_avg_pool2d(illu_fea, img_feat.shape[2:])
        
        # Adapt illumination features to match image feature channels
        illu_adapted = self.illu_adapt(illu_fea)
        
        # Fusion
        if self.fusion_type == 'add':
            fused = img_feat + illu_adapted
        elif self.fusion_type == 'mul':
            fused = img_feat * torch.sigmoid(illu_adapted)
        elif self.fusion_type == 'concat':
            fused = self.fusion_conv(torch.cat([img_feat, illu_adapted], dim=1))
        else:
            raise ValueError(f"Unknown fusion type: {self.fusion_type}")
        
        return fused


@BACKBONES.register_module()
class RetinexEnhancedBackbone(BaseModule):
    """
    Wrapper that adds Retinex illumination enhancement to any backbone.
    
    Flow:
    1. Extract illumination features from input images
    2. Run original backbone
    3. Fuse illumination features with backbone features
    """
    
    def __init__(self,
                 backbone_cfg,
                 illu_channels=40,
                 fusion_type='add',
                 with_mvb_loss=True,
                 overlap_ratio=0.125,
                 init_cfg=None):
        """
        Args:
            backbone_cfg: Config dict for the underlying backbone
            illu_channels: Number of illumination feature channels
            fusion_type: Fusion type ('add', 'mul', 'concat')
            with_mvb_loss: Whether to use MVB consistency loss
            overlap_ratio: Overlap ratio for MVB module
        """
        super().__init__(init_cfg)
        
        # Build underlying backbone
        from mmdet.models import build_backbone
        self.backbone = build_backbone(backbone_cfg)
        
        # Illumination estimator
        self.illu_estimator = IlluminationEstimator(n_fea_middle=illu_channels)
        
        # MVB-Retinex for multi-view consistency
        self.with_mvb_loss = with_mvb_loss
        if with_mvb_loss:
            self.mvb_retinex = MVBRetinex(overlap_ratio=overlap_ratio)
        
        # Get output channels from backbone (assume last stage)
        # This will be set dynamically based on backbone output
        self._out_channels = None
    
    def forward(self, x):
        """
        Args:
            x: Input images [B*N, 3, H, W] where N is number of views
        
        Returns:
            out: List of feature maps with illumination enhancement
            (optional) mvb_loss: Multi-view consistency loss
        """
        # Step 1: Extract illumination features
        illu_fea, illu_map = self.illu_estimator(x)
        
        # Step 2: Apply Retinex light-up (optional enhancement)
        # Ilu = I * L_inverse = R + D
        # For BEV detection, we mainly use illu_fea as gain
        
        # Step 3: Run backbone
        backbone_feats = self.backbone(x)
        
        # Return backbone features and illumination features for later fusion
        return backbone_feats, illu_fea, illu_map


class RetinexModule(nn.Module):
    """
    Standalone Retinex module for integration with MapTR.
    
    Can be inserted between image input and backbone, or after backbone features.
    """
    
    def __init__(self,
                 n_fea_middle=40,
                 fusion_channels=256,
                 fusion_type='add',
                 with_mvb_loss=True,
                 overlap_ratio=0.125):
        super().__init__()
        
        # Illumination estimator
        self.illu_estimator = IlluminationEstimator(n_fea_middle=n_fea_middle)
        
        # Feature fusion module
        self.fusion = RetinexBEVFusion(
            illu_channels=n_fea_middle,
            img_channels=fusion_channels,
            fusion_type=fusion_type
        )
        
        # MVB-Retinex
        self.with_mvb_loss = with_mvb_loss
        if with_mvb_loss:
            self.mvb_retinex = MVBRetinex(overlap_ratio=overlap_ratio)
        
        self.n_fea_middle = n_fea_middle
    
    def extract_illumination(self, img):
        """
        Extract illumination features from images.
        
        Args:
            img: [B*N, 3, H, W] or [B, N, 3, H, W]
        
        Returns:
            illu_fea: Illumination features
            illu_map: Illumination map
        """
        # Handle different input shapes
        if img.dim() == 5:
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
            reshape_back = True
        else:
            reshape_back = False
            B_N = img.shape[0]
        
        illu_fea, illu_map = self.illu_estimator(img)
        
        if reshape_back:
            illu_fea = illu_fea.view(B, N, -1, illu_fea.shape[2], illu_fea.shape[3])
            illu_map = illu_map.view(B, N, -1, illu_map.shape[2], illu_map.shape[3])
        
        return illu_fea, illu_map
    
    def fuse_features(self, img_feat, illu_fea):
        """
        Fuse backbone features with illumination features.
        
        Args:
            img_feat: Backbone features [B*N, C, H, W]
            illu_fea: Illumination features [B*N, C_illu, H_illu, W_illu]
        
        Returns:
            fused_feat: Fused features
        """
        return self.fusion(img_feat, illu_fea)
    
    def compute_mvb_loss(self, illu_fea, num_views=6):
        """
        Compute multi-view balanced consistency loss.
        
        Args:
            illu_fea: [B*N, C, H, W]
            num_views: Number of camera views
        
        Returns:
            loss: MVB consistency loss
        """
        if not self.with_mvb_loss:
            return torch.tensor(0.0, device=illu_fea.device)
        
        B_N, C, H, W = illu_fea.shape
        B = B_N // num_views
        
        # Reshape to [B, N, C, H, W] then split by view
        illu_fea = illu_fea.view(B, num_views, C, H, W)
        illu_fea_list = [illu_fea[:, i] for i in range(num_views)]
        
        return self.mvb_retinex(illu_fea_list)
    
    def forward(self, img, img_feat=None, return_loss=True):
        """
        Full forward pass.
        
        Args:
            img: Input images [B*N, 3, H, W]
            img_feat: Optional backbone features [B*N, C, H, W]
            return_loss: Whether to return MVB loss
        
        Returns:
            If img_feat is provided: fused features
            If img_feat is None: illumination features
            If return_loss: also return MVB loss
        """
        illu_fea, illu_map = self.illu_estimator(img)
        
        outputs = {'illu_fea': illu_fea, 'illu_map': illu_map}
        
        if img_feat is not None:
            fused_feat = self.fuse_features(img_feat, illu_fea)
            outputs['fused_feat'] = fused_feat
        
        if return_loss and self.with_mvb_loss:
            # Assume 6 views for nuScenes
            mvb_loss = self.compute_mvb_loss(illu_fea, num_views=6)
            outputs['mvb_loss'] = mvb_loss
        
        return outputs


# =============================================================================
# ECCV Innovation 1: Map-Element-Aware Illumination
# =============================================================================

class MapElementAwareIllumination(nn.Module):
    """
    Map-Element-Aware Illumination Enhancement.
    
    Different map elements have different illumination characteristics:
    - Lane dividers: Reflective paint, high contrast under headlights
    - Pedestrian crossings: Periodic texture, zebra patterns
    - Road boundaries: Continuous curves, often near curbs/barriers
    
    This module learns element-specific illumination features.
    
    创新点：
    1. 针对三类地图元素设计独立的光照估计分支
    2. 利用元素先验（方向性、周期性、连续性）指导光照增强
    3. 自适应融合不同元素的光照特征
    """
    
    def __init__(self, 
                 n_fea_middle=40,
                 num_map_classes=3,  # divider, ped_crossing, boundary
                 share_backbone=True):
        """
        Args:
            n_fea_middle: Number of middle features
            num_map_classes: Number of map element classes
            share_backbone: Whether to share early conv layers
        """
        super().__init__()
        
        self.num_map_classes = num_map_classes
        self.share_backbone = share_backbone
        self.n_fea_middle = n_fea_middle
        
        # Shared early layers (optional)
        if share_backbone:
            self.shared_conv = nn.Sequential(
                nn.Conv2d(4, n_fea_middle // 2, kernel_size=1, bias=True),
                nn.LeakyReLU(0.1, inplace=True),
            )
            branch_in_channels = n_fea_middle // 2
        else:
            self.shared_conv = None
            branch_in_channels = 4  # 3 RGB + 1 prior
        
        # Element-specific illumination branches
        # Each branch has different receptive field and orientation sensitivity
        
        # Branch 1: Lane Dividers - Directional, elongated features
        self.lane_branch = nn.Sequential(
            nn.Conv2d(branch_in_channels, n_fea_middle, kernel_size=(1, 7), padding=(0, 3), bias=True),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(n_fea_middle, n_fea_middle, kernel_size=(7, 1), padding=(3, 0), bias=True),
            nn.LeakyReLU(0.1, inplace=True),
        )
        
        # Branch 2: Pedestrian Crossing - Periodic, striped patterns
        self.crossing_branch = nn.Sequential(
            nn.Conv2d(branch_in_channels, n_fea_middle, kernel_size=3, padding=1, dilation=1, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(n_fea_middle, n_fea_middle, kernel_size=3, padding=2, dilation=2, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
        )
        
        # Branch 3: Road Boundary - Continuous, smooth curves
        self.boundary_branch = nn.Sequential(
            nn.Conv2d(branch_in_channels, n_fea_middle, kernel_size=5, padding=2, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(n_fea_middle, n_fea_middle, kernel_size=5, padding=2, groups=n_fea_middle, bias=True),
            nn.LeakyReLU(0.1, inplace=True),
        )
        
        # Adaptive fusion weights
        self.fusion_weights = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(n_fea_middle * 3, n_fea_middle),
            nn.ReLU(inplace=True),
            nn.Linear(n_fea_middle, 3),
            nn.Softmax(dim=1)
        )
        
        # Output projection
        self.output_proj = nn.Conv2d(n_fea_middle, n_fea_middle, kernel_size=1, bias=True)
    
    def forward(self, img):
        """
        Args:
            img: Input image [B, 3, H, W]
        
        Returns:
            illu_fea: Combined element-aware illumination feature [B, n_fea_middle, H, W]
            element_feas: Dict of element-specific features for potential supervision
        """
        # Compute illumination prior
        illu_prior = img.mean(dim=1, keepdim=True)  # [B, 1, H, W]
        x = torch.cat([img, illu_prior], dim=1)  # [B, 4, H, W]
        
        # Shared backbone (optional)
        if self.share_backbone:
            x = self.shared_conv(x)
        
        # Element-specific branches
        lane_fea = self.lane_branch(x)       # [B, C, H, W]
        crossing_fea = self.crossing_branch(x)  # [B, C, H, W]
        boundary_fea = self.boundary_branch(x)  # [B, C, H, W]
        
        # Concatenate for fusion weight computation
        concat_fea = torch.cat([lane_fea, crossing_fea, boundary_fea], dim=1)  # [B, 3C, H, W]
        
        # Compute adaptive fusion weights
        weights = self.fusion_weights(concat_fea)  # [B, 3]
        
        # Weighted fusion
        B, C, H, W = lane_fea.shape
        weights = weights.view(B, 3, 1, 1, 1)  # [B, 3, 1, 1, 1]
        
        stacked_fea = torch.stack([lane_fea, crossing_fea, boundary_fea], dim=1)  # [B, 3, C, H, W]
        fused_fea = (stacked_fea * weights).sum(dim=1)  # [B, C, H, W]
        
        # Output projection
        illu_fea = self.output_proj(fused_fea)
        
        # Return element-specific features for potential supervision
        element_feas = {
            'lane': lane_fea,
            'crossing': crossing_fea,
            'boundary': boundary_fea,
            'weights': weights.squeeze(-1).squeeze(-1).squeeze(-1)  # [B, 3]
        }
        
        return illu_fea, element_feas


# =============================================================================
# ECCV Innovation 2: Query-Guided Illumination
# =============================================================================

class QueryGuidedIllumination(nn.Module):
    """
    Query-Guided Illumination Feature Retrieval.
    
    Instead of global illumination estimation, this module uses MapTR's
    instance queries to selectively retrieve relevant illumination patterns.
    
    Key insight: Each map query corresponds to a specific map element instance.
    By using queries to guide illumination feature retrieval, we achieve:
    1. Instance-level illumination awareness
    2. Sparse attention to relevant illumination patterns
    3. Better generalization to novel lighting conditions
    
    创新点：
    1. 将 MapTR 的 Query 机制引入光照特征检索
    2. 建立光照特征池（Illumination Feature Bank）
    3. Query 通过 cross-attention 从特征池检索相关光照模式
    """
    
    def __init__(self,
                 illu_channels=40,
                 query_channels=256,
                 num_heads=4,
                 bank_size=100,
                 dropout=0.1):
        """
        Args:
            illu_channels: Number of illumination feature channels
            query_channels: Number of query feature channels (from MapTR)
            num_heads: Number of attention heads
            bank_size: Size of illumination feature bank
            dropout: Dropout rate
        """
        super().__init__()
        
        self.illu_channels = illu_channels
        self.query_channels = query_channels
        self.num_heads = num_heads
        self.bank_size = bank_size
        
        # Illumination Feature Bank (learnable)
        # Stores prototypical illumination patterns
        self.illu_bank = nn.Parameter(torch.randn(bank_size, illu_channels))
        nn.init.xavier_uniform_(self.illu_bank)
        
        # Query projection (from MapTR query space to illumination space)
        self.query_proj = nn.Linear(query_channels, illu_channels)
        
        # Key/Value projections for cross-attention
        self.key_proj = nn.Linear(illu_channels, illu_channels)
        self.value_proj = nn.Linear(illu_channels, illu_channels)
        
        # Multi-head attention
        self.attention = nn.MultiheadAttention(
            embed_dim=illu_channels,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        
        # Output projection back to query space
        self.output_proj = nn.Linear(illu_channels, query_channels)
        
        # Layer norm
        self.norm1 = nn.LayerNorm(illu_channels)
        self.norm2 = nn.LayerNorm(query_channels)
        
        # Gating mechanism for residual connection
        self.gate = nn.Sequential(
            nn.Linear(query_channels * 2, query_channels),
            nn.Sigmoid()
        )
    
    def forward(self, queries, illu_fea=None):
        """
        Args:
            queries: MapTR instance queries [B, num_queries, query_channels]
            illu_fea: Optional current illumination features [B, C, H, W]
                      If provided, will be combined with the bank
        
        Returns:
            enhanced_queries: Queries enhanced with illumination information
            attention_weights: Attention weights for visualization
        """
        B, num_queries, _ = queries.shape
        
        # Project queries to illumination space
        q = self.query_proj(queries)  # [B, num_queries, illu_channels]
        q = self.norm1(q)
        
        # Prepare key/value from illumination bank
        # Expand bank for batch processing
        bank = self.illu_bank.unsqueeze(0).expand(B, -1, -1)  # [B, bank_size, illu_channels]
        
        # If current illumination features are provided, add them to the bank
        if illu_fea is not None:
            # Global average pool to get image-level illumination
            illu_global = F.adaptive_avg_pool2d(illu_fea, 1).squeeze(-1).squeeze(-1)  # [B, illu_channels]
            illu_global = illu_global.unsqueeze(1)  # [B, 1, illu_channels]
            
            # Concatenate with bank
            bank = torch.cat([bank, illu_global], dim=1)  # [B, bank_size+1, illu_channels]
        
        k = self.key_proj(bank)    # [B, bank_size(+1), illu_channels]
        v = self.value_proj(bank)  # [B, bank_size(+1), illu_channels]
        
        # Cross-attention: queries attend to illumination bank
        attended_illu, attn_weights = self.attention(q, k, v)  # [B, num_queries, illu_channels]
        
        # Project back to query space
        illu_query = self.output_proj(attended_illu)  # [B, num_queries, query_channels]
        illu_query = self.norm2(illu_query)
        
        # Gated residual connection
        gate = self.gate(torch.cat([queries, illu_query], dim=-1))  # [B, num_queries, query_channels]
        enhanced_queries = queries + gate * illu_query
        
        return enhanced_queries, attn_weights
    
    def get_bank_visualization(self):
        """Get illumination bank for visualization/analysis."""
        return self.illu_bank.detach()


class QueryGuidedIlluminationV2(nn.Module):
    """
    Query-Guided Illumination V2: Spatial-aware version.
    
    Instead of just attending to a global bank, this version allows
    queries to attend to spatial illumination features.
    
    创新点：
    1. 空间感知的光照特征检索
    2. Query 可以关注图像不同区域的光照条件
    3. 更细粒度的光照增强
    """
    
    def __init__(self,
                 illu_channels=40,
                 query_channels=256,
                 num_heads=4,
                 dropout=0.1):
        super().__init__()
        
        self.illu_channels = illu_channels
        self.query_channels = query_channels
        
        # Illumination feature encoder (process raw illumination features)
        # 使用 GroupNorm 代替 BatchNorm2d，对 fp16 混合精度训练更友好
        num_groups_illu = min(32, illu_channels // 4) if illu_channels >= 32 else 1
        self.illu_encoder = nn.Sequential(
            nn.Conv2d(illu_channels, illu_channels, kernel_size=3, padding=1),
            nn.GroupNorm(num_groups_illu, illu_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(illu_channels, illu_channels, kernel_size=3, padding=1),
        )
        
        # Project illumination features to query space for attention
        self.illu_to_query = nn.Linear(illu_channels, query_channels)
        
        # Query projection
        self.query_proj = nn.Linear(query_channels, query_channels)
        
        # Cross-attention
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=query_channels,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        
        # Layer norms
        self.norm_illu = nn.LayerNorm(query_channels)
        self.norm_query = nn.LayerNorm(query_channels)
        self.norm_out = nn.LayerNorm(query_channels)
        
        # FFN for output
        self.ffn = nn.Sequential(
            nn.Linear(query_channels, query_channels * 4),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(query_channels * 4, query_channels),
            nn.Dropout(dropout),
        )
    
    def forward(self, queries, illu_fea, spatial_shapes=None):
        """
        Args:
            queries: MapTR queries [B, num_queries, query_channels]
            illu_fea: Illumination features [B, C, H, W]
            spatial_shapes: Optional spatial info
        
        Returns:
            enhanced_queries: Illumination-aware queries
            attn_weights: Spatial attention weights
        """
        B, num_queries, C = queries.shape
        
        # Encode illumination features
        illu_encoded = self.illu_encoder(illu_fea)  # [B, illu_C, H, W]
        
        # Flatten spatial dimensions
        B, illu_C, H, W = illu_encoded.shape
        illu_flat = illu_encoded.flatten(2).permute(0, 2, 1)  # [B, H*W, illu_C]
        
        # Project to query space
        illu_proj = self.illu_to_query(illu_flat)  # [B, H*W, query_C]
        illu_proj = self.norm_illu(illu_proj)
        
        # Project queries
        q = self.query_proj(queries)  # [B, num_queries, query_C]
        q = self.norm_query(q)
        
        # Cross-attention: queries attend to spatial illumination features
        attended, attn_weights = self.cross_attn(
            query=q,
            key=illu_proj,
            value=illu_proj
        )  # [B, num_queries, query_C], [B, num_queries, H*W]
        
        # Residual + FFN
        queries = queries + attended
        queries = self.norm_out(queries + self.ffn(queries))
        
        # Reshape attention weights for visualization
        attn_weights = attn_weights.view(B, num_queries, H, W)
        
        return queries, attn_weights


# =============================================================================
# Combined Module: Full Innovation Stack
# =============================================================================

class RetinexMapTREnhancement(nn.Module):
    """
    Complete Retinex-based enhancement for MapTR with all innovations.
    
    Supports ablation through config flags:
    - use_map_element_aware: Enable Map-Element-Aware Illumination
    - use_query_guided: Enable Query-Guided Illumination
    - use_mvb_loss: Enable Multi-View Balanced consistency loss
    
    This is the main module to use in RetinexMapTR detector.
    """
    
    def __init__(self,
                 n_fea_middle=40,
                 query_channels=256,
                 num_map_classes=3,
                 num_heads=4,
                 bank_size=100,
                 fusion_type='add',
                 overlap_ratio=0.125,
                 # Ablation switches
                 use_map_element_aware=True,
                 use_query_guided=True,
                 use_query_guided_v2=False,  # Spatial version
                 use_mvb_loss=True):
        """
        Args:
            n_fea_middle: Number of illumination feature channels
            query_channels: Number of MapTR query channels
            num_map_classes: Number of map element classes
            num_heads: Number of attention heads
            bank_size: Size of illumination bank
            fusion_type: Feature fusion type
            overlap_ratio: Overlap ratio for MVB
            
            Ablation switches:
            use_map_element_aware: Whether to use element-aware illumination
            use_query_guided: Whether to use query-guided illumination
            use_query_guided_v2: Whether to use spatial query-guided (v2)
            use_mvb_loss: Whether to use MVB consistency loss
        """
        super().__init__()
        
        self.n_fea_middle = n_fea_middle
        self.query_channels = query_channels
        
        # Ablation flags
        self.use_map_element_aware = use_map_element_aware
        self.use_query_guided = use_query_guided
        self.use_query_guided_v2 = use_query_guided_v2
        self.use_mvb_loss = use_mvb_loss
        
        # Basic illumination estimator (always used as baseline)
        self.illu_estimator = IlluminationEstimator(n_fea_middle=n_fea_middle)
        
        # Innovation 1: Map-Element-Aware Illumination
        if use_map_element_aware:
            self.map_element_illu = MapElementAwareIllumination(
                n_fea_middle=n_fea_middle,
                num_map_classes=num_map_classes
            )
        
        # Innovation 2: Query-Guided Illumination
        if use_query_guided:
            if use_query_guided_v2:
                self.query_guided_illu = QueryGuidedIlluminationV2(
                    illu_channels=n_fea_middle,
                    query_channels=query_channels,
                    num_heads=num_heads
                )
            else:
                self.query_guided_illu = QueryGuidedIllumination(
                    illu_channels=n_fea_middle,
                    query_channels=query_channels,
                    num_heads=num_heads,
                    bank_size=bank_size
                )
        
        # Feature fusion
        self.fusion = RetinexBEVFusion(
            illu_channels=n_fea_middle,
            img_channels=query_channels,  # Assume neck output = query channels
            fusion_type=fusion_type
        )
        
        # MVB-Retinex
        if use_mvb_loss:
            self.mvb_retinex = MVBRetinex(overlap_ratio=overlap_ratio)
    
    def extract_illumination(self, img):
        """
        Extract illumination features from images.
        
        Args:
            img: Input images [B*N, 3, H, W]
        
        Returns:
            illu_fea: Illumination features
            element_feas: Element-specific features (if enabled)
        """
        # Basic illumination estimation
        illu_fea_basic, illu_map = self.illu_estimator(img)
        
        element_feas = None
        
        # Map-Element-Aware enhancement
        if self.use_map_element_aware:
            illu_fea_element, element_feas = self.map_element_illu(img)
            # Combine basic and element-aware features
            illu_fea = illu_fea_basic + illu_fea_element
        else:
            illu_fea = illu_fea_basic
        
        return illu_fea, illu_map, element_feas
    
    def enhance_queries(self, queries, illu_fea):
        """
        Enhance MapTR queries with illumination information.
        
        Args:
            queries: MapTR instance queries [B, num_queries, C]
            illu_fea: Illumination features [B*N, C_illu, H, W] or [B, C_illu, H, W]
        
        Returns:
            enhanced_queries: Illumination-aware queries
            attn_weights: Attention weights (for visualization)
        """
        if not self.use_query_guided:
            return queries, None
        
        if self.use_query_guided_v2:
            # V2 needs spatial features
            return self.query_guided_illu(queries, illu_fea)
        else:
            # V1 uses global features
            return self.query_guided_illu(queries, illu_fea)
    
    def fuse_features(self, img_feat, illu_fea):
        """Fuse backbone features with illumination features."""
        return self.fusion(img_feat, illu_fea)
    
    def compute_mvb_loss(self, illu_fea, num_views=6):
        """Compute multi-view consistency loss."""
        if not self.use_mvb_loss:
            return torch.tensor(0.0, device=illu_fea.device)
        
        B_N, C, H, W = illu_fea.shape
        B = B_N // num_views
        
        illu_fea_reshaped = illu_fea.view(B, num_views, C, H, W)
        illu_fea_list = [illu_fea_reshaped[:, i] for i in range(num_views)]
        
        return self.mvb_retinex(illu_fea_list)
    
    def forward(self, img, img_feat=None, queries=None, return_loss=True):
        """
        Full forward pass with all innovations.
        
        Args:
            img: Input images [B*N, 3, H, W]
            img_feat: Backbone features [B*N, C, H, W]
            queries: MapTR queries [B, num_queries, C]
            return_loss: Whether to compute MVB loss
        
        Returns:
            outputs: Dict containing:
                - illu_fea: Illumination features
                - fused_feat: Fused features (if img_feat provided)
                - enhanced_queries: Enhanced queries (if queries provided)
                - mvb_loss: MVB consistency loss (if return_loss)
                - element_feas: Element-specific features (if enabled)
                - attn_weights: Query attention weights (if enabled)
        """
        outputs = {}
        
        # Step 1: Extract illumination features
        illu_fea, illu_map, element_feas = self.extract_illumination(img)
        outputs['illu_fea'] = illu_fea
        outputs['illu_map'] = illu_map
        if element_feas is not None:
            outputs['element_feas'] = element_feas
        
        # Step 2: Fuse with backbone features
        if img_feat is not None:
            fused_feat = self.fuse_features(img_feat, illu_fea)
            outputs['fused_feat'] = fused_feat
        
        # Step 3: Enhance queries
        if queries is not None and self.use_query_guided:
            # For query-guided, we need to pool illumination features
            if self.use_query_guided_v2:
                # V2 uses spatial features - need to handle multi-view
                # For simplicity, use global pooled features
                enhanced_queries, attn_weights = self.query_guided_illu(queries, illu_fea)
            else:
                enhanced_queries, attn_weights = self.query_guided_illu(queries, illu_fea)
            outputs['enhanced_queries'] = enhanced_queries
            outputs['attn_weights'] = attn_weights
        
        # Step 4: MVB loss
        if return_loss and self.use_mvb_loss:
            mvb_loss = self.compute_mvb_loss(illu_fea, num_views=6)
            outputs['mvb_loss'] = mvb_loss
        
        return outputs
