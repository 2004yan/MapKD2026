"""
MS-IIFL (Map-Structure-Guided Illumination-Invariant Feature Learning) 损失函数

ECCV 级别创新点：
1. 地图元素特质对齐 (Map Element Trait Alignment)
   - 梯度方向一致性 (车道线/边界)
   - 频域一致性 (人行横道周期性纹理)
   
2. BEV 拓扑结构蒸馏 (BEV Topological Structure Distillation)
   - BEV 特征蒸馏 (借鉴 SafeMap D-BEVC)
   - BEV 拓扑一致性 (地图元素连通性)
   
3. 地图元素重建损失 (Map Element Reconstruction Loss)
   - 针对地图区域的特征重建
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Optional, Tuple, List
from mmdet.models.builder import LOSSES


@LOSSES.register_module()
class MapElementTraitAlignmentLoss(nn.Module):
    """
    地图元素特质对齐损失
    
    综合梯度方向和频域一致性，针对不同地图元素
    """
    
    def __init__(self,
                 direction_weight: float = 1.0,
                 frequency_weight: float = 0.5,
                 edge_threshold: float = 0.1,
                 high_freq_ratio: float = 0.5):
        super().__init__()
        self.direction_weight = direction_weight
        self.frequency_weight = frequency_weight
        self.edge_threshold = edge_threshold
        self.high_freq_ratio = high_freq_ratio
        
        # Sobel 算子
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
    
    def forward(self, feat_day: torch.Tensor, 
                feat_night: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            feat_day: [B, C, H, W] 白天特征
            feat_night: [B, C, H, W] 夜间特征
        Returns:
            losses: 包含各子损失的字典
        """
        losses = {}
        
        # 1. 梯度方向一致性（针对车道线/边界）
        loss_dir = self._gradient_direction_loss(feat_day, feat_night)
        losses['loss_gradient_direction'] = loss_dir * self.direction_weight
        
        # 2. 频域一致性（针对人行横道）
        loss_freq = self._frequency_domain_loss(feat_day, feat_night)
        losses['loss_frequency_domain'] = loss_freq * self.frequency_weight
        
        return losses
    
    def _gradient_direction_loss(self, feat_day: torch.Tensor, 
                                  feat_night: torch.Tensor) -> torch.Tensor:
        """梯度方向一致性损失"""
        # 转为灰度
        if feat_day.shape[1] > 1:
            feat_day_gray = feat_day.mean(dim=1, keepdim=True)
            feat_night_gray = feat_night.mean(dim=1, keepdim=True)
        else:
            feat_day_gray = feat_day
            feat_night_gray = feat_night
        
        # 统一数据类型为 float32 以避免 FP16 精度问题
        feat_day_gray = feat_day_gray.float()
        feat_night_gray = feat_night_gray.float()
        sobel_x = self.sobel_x.to(device=feat_day_gray.device)
        sobel_y = self.sobel_y.to(device=feat_day_gray.device)
        
        # 计算梯度
        grad_x_day = F.conv2d(feat_day_gray, sobel_x, padding=1)
        grad_y_day = F.conv2d(feat_day_gray, sobel_y, padding=1)
        grad_x_night = F.conv2d(feat_night_gray, sobel_x, padding=1)
        grad_y_night = F.conv2d(feat_night_gray, sobel_y, padding=1)
        
        # 计算梯度模长
        mag_day = torch.sqrt(grad_x_day ** 2 + grad_y_day ** 2 + 1e-8)
        mag_night = torch.sqrt(grad_x_night ** 2 + grad_y_night ** 2 + 1e-8)
        
        # 边缘掩码
        edge_mask = (mag_day > self.edge_threshold).float()
        
        # 计算单位方向向量
        dir_x_day = grad_x_day / mag_day
        dir_y_day = grad_y_day / mag_day
        dir_x_night = grad_x_night / mag_night
        dir_y_night = grad_y_night / mag_night
        
        # 方向一致性（用点积）
        cos_similarity = dir_x_day * dir_x_night + dir_y_day * dir_y_night
        direction_loss = 1 - torch.abs(cos_similarity)  # 允许 180 度反向
        
        loss = (direction_loss * edge_mask).sum() / (edge_mask.sum() + 1e-8)
        return loss
    
    def _frequency_domain_loss(self, feat_day: torch.Tensor,
                                feat_night: torch.Tensor) -> torch.Tensor:
        """频域一致性损失"""
        # FFT 不支持 FP16，转换为 float32
        feat_day = feat_day.float()
        feat_night = feat_night.float()
        
        B, C, H, W = feat_day.shape
        
        # FFT
        fft_day = torch.fft.fft2(feat_day, norm='ortho')
        fft_night = torch.fft.fft2(feat_night, norm='ortho')
        
        # 幅度谱
        amp_day = torch.abs(fft_day)
        amp_night = torch.abs(fft_night)
        
        # 移到中心
        amp_day_shift = torch.fft.fftshift(amp_day, dim=(-2, -1))
        amp_night_shift = torch.fft.fftshift(amp_night, dim=(-2, -1))
        
        # 高频掩码
        center_h, center_w = H // 2, W // 2
        radius_h = int(H * self.high_freq_ratio / 2)
        radius_w = int(W * self.high_freq_ratio / 2)
        
        y_coords = torch.arange(H, device=feat_day.device).view(1, 1, H, 1).expand(B, C, H, W)
        x_coords = torch.arange(W, device=feat_day.device).view(1, 1, 1, W).expand(B, C, H, W)
        
        dist_y = torch.abs(y_coords - center_h)
        dist_x = torch.abs(x_coords - center_w)
        
        high_freq_mask = ((dist_y > radius_h) | (dist_x > radius_w)).float()
        
        # 高频一致性
        high_freq_diff = torch.abs(amp_day_shift - amp_night_shift) * high_freq_mask
        loss = high_freq_diff.mean()
        
        return loss


@LOSSES.register_module()
class BEVTopologicalDistillationLoss(nn.Module):
    """
    BEV 拓扑结构蒸馏损失
    
    借鉴 SafeMap 的 D-BEVC，但增加拓扑约束
    
    创新点：
    1. BEV 特征蒸馏：强制退化图像的 BEV 特征逼近原始图像
    2. 拓扑一致性：利用自相关矩阵约束地图元素的连通性
    """
    
    def __init__(self,
                 distill_weight: float = 1.0,
                 topo_weight: float = 0.5,
                 downsample_factor: int = 8,
                 num_samples: int = 512,
                 use_cosine_distill: bool = True):
        super().__init__()
        self.distill_weight = distill_weight
        self.topo_weight = topo_weight
        self.downsample_factor = downsample_factor
        self.num_samples = num_samples
        self.use_cosine_distill = use_cosine_distill
    
    def forward(self, bev_day: torch.Tensor,
                bev_night: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            bev_day: [B, C, H, W] 白天 BEV 特征
            bev_night: [B, C, H, W] 夜间 BEV 特征
        Returns:
            losses: 包含蒸馏和拓扑损失的字典
        """
        losses = {}
        
        # 1. BEV 特征蒸馏（借鉴 SafeMap D-BEVC）
        loss_distill = self._bev_distillation_loss(bev_day, bev_night)
        losses['loss_bev_distill'] = loss_distill * self.distill_weight
        
        # 2. BEV 拓扑一致性
        loss_topo = self._bev_topological_loss(bev_day, bev_night)
        losses['loss_bev_topology'] = loss_topo * self.topo_weight
        
        return losses
    
    def _bev_distillation_loss(self, bev_day: torch.Tensor,
                                bev_night: torch.Tensor) -> torch.Tensor:
        """
        BEV 特征蒸馏损失
        
        公式（借鉴 SafeMap）：
        L_distill = MSE(F_day, F_night) 或 1 - cos(F_day, F_night)
        """
        if self.use_cosine_distill:
            # 余弦相似度蒸馏（对特征幅度不敏感）
            bev_day_flat = bev_day.view(bev_day.shape[0], -1)
            bev_night_flat = bev_night.view(bev_night.shape[0], -1)
            
            cos_sim = F.cosine_similarity(bev_day_flat, bev_night_flat, dim=1)
            loss = 1 - cos_sim.mean()
        else:
            # MSE 蒸馏
            loss = F.mse_loss(bev_day, bev_night)
        
        return loss
    
    def _bev_topological_loss(self, bev_day: torch.Tensor,
                               bev_night: torch.Tensor) -> torch.Tensor:
        """
        BEV 拓扑一致性损失
        
        关键洞察：地图元素的拓扑关系（连通性、平行性）应该在不同光照下保持不变
        
        实现：使用自相关矩阵捕捉空间位置之间的关系
        """
        B, C, H, W = bev_day.shape
        
        # 下采样以减少计算量
        if H > self.downsample_factor:
            bev_day = F.adaptive_avg_pool2d(bev_day, (H // self.downsample_factor, 
                                                       W // self.downsample_factor))
            bev_night = F.adaptive_avg_pool2d(bev_night, (H // self.downsample_factor,
                                                          W // self.downsample_factor))
        
        B, C, H_small, W_small = bev_day.shape
        num_positions = H_small * W_small
        
        # 随机采样位置
        if num_positions > self.num_samples:
            indices = torch.randperm(num_positions, device=bev_day.device)[:self.num_samples]
            bev_day_flat = bev_day.view(B, C, -1)[:, :, indices]
            bev_night_flat = bev_night.view(B, C, -1)[:, :, indices]
        else:
            bev_day_flat = bev_day.view(B, C, -1)
            bev_night_flat = bev_night.view(B, C, -1)
        
        # L2 归一化
        bev_day_norm = F.normalize(bev_day_flat, p=2, dim=1)
        bev_night_norm = F.normalize(bev_night_flat, p=2, dim=1)
        
        # 自相关矩阵：[B, N, N]
        corr_day = torch.bmm(bev_day_norm.transpose(1, 2), bev_day_norm)
        corr_night = torch.bmm(bev_night_norm.transpose(1, 2), bev_night_norm)
        
        # 拓扑一致性：两个相关矩阵应该相似
        loss = F.mse_loss(corr_day, corr_night)
        
        return loss


@LOSSES.register_module()
class MapElementReconstructionLoss(nn.Module):
    """
    地图元素重建损失
    
    借鉴 SafeMap 的 G-PVR，但专注于地图元素区域
    
    创新点：不重建整个特征图，而是只重建地图元素相关的区域
    这使得网络学会从上下文中"恢复"丢失的地图信息
    """
    
    def __init__(self,
                 recon_weight: float = 1.0,
                 use_masked_recon: bool = True,
                 mask_ratio: float = 0.3):
        super().__init__()
        self.recon_weight = recon_weight
        self.use_masked_recon = use_masked_recon
        self.mask_ratio = mask_ratio
        
        # 轻量级重建解码器
        self.decoder = nn.Sequential(
            nn.Conv2d(256, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, 1)
        )
    
    def forward(self, feat_night: torch.Tensor,
                feat_day: torch.Tensor,
                map_mask: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        Args:
            feat_night: [B, C, H, W] 夜间特征（输入）
            feat_day: [B, C, H, W] 白天特征（目标）
            map_mask: [B, 1, H, W] 地图元素掩码（可选）
        Returns:
            losses: 重建损失
        """
        losses = {}
        
        # 重建白天特征
        feat_recon = self.decoder(feat_night)
        
        if self.use_masked_recon and map_mask is not None:
            # 只在地图元素区域计算重建损失
            # 调整掩码大小以匹配特征图
            mask = F.interpolate(map_mask.float(), size=feat_day.shape[-2:], mode='nearest')
            
            loss = (torch.abs(feat_recon - feat_day) * mask).sum() / (mask.sum() + 1e-8)
        else:
            # 随机掩码重建（类似 MAE）
            B, C, H, W = feat_day.shape
            mask = torch.rand(B, 1, H, W, device=feat_day.device) > self.mask_ratio
            mask = mask.float()
            
            loss = (torch.abs(feat_recon - feat_day) * mask).sum() / (mask.sum() + 1e-8)
        
        losses['loss_map_recon'] = loss * self.recon_weight
        
        return losses


@LOSSES.register_module()
class MSIIFLLoss(nn.Module):
    """
    MS-IIFL 综合损失
    
    整合所有地图感知的跨光照一致性约束
    
    使用方式：
    loss_fn = MSIIFLLoss(
        use_trait_alignment=True,
        use_bev_distillation=True,
        use_map_reconstruction=True,
        ...
    )
    losses = loss_fn(feat_day, feat_night, bev_day, bev_night)
    """
    
    def __init__(self,
                 # 模块开关
                 use_trait_alignment: bool = True,
                 use_bev_distillation: bool = True,
                 use_map_reconstruction: bool = False,
                 # 权重
                 trait_alignment_cfg: Optional[Dict] = None,
                 bev_distillation_cfg: Optional[Dict] = None,
                 map_reconstruction_cfg: Optional[Dict] = None,
                 # 总权重
                 total_weight: float = 1.0):
        super().__init__()
        
        self.use_trait_alignment = use_trait_alignment
        self.use_bev_distillation = use_bev_distillation
        self.use_map_reconstruction = use_map_reconstruction
        self.total_weight = total_weight
        
        if use_trait_alignment:
            cfg = trait_alignment_cfg or {}
            self.trait_alignment = MapElementTraitAlignmentLoss(**cfg)
        
        if use_bev_distillation:
            cfg = bev_distillation_cfg or {}
            self.bev_distillation = BEVTopologicalDistillationLoss(**cfg)
        
        if use_map_reconstruction:
            cfg = map_reconstruction_cfg or {}
            self.map_reconstruction = MapElementReconstructionLoss(**cfg)
    
    def forward(self,
                feat_day: torch.Tensor,
                feat_night: torch.Tensor,
                bev_day: Optional[torch.Tensor] = None,
                bev_night: Optional[torch.Tensor] = None,
                map_mask: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        Args:
            feat_day: [B, C, H, W] 白天 PV 特征
            feat_night: [B, C, H, W] 夜间 PV 特征
            bev_day: [B, C, H, W] 白天 BEV 特征
            bev_night: [B, C, H, W] 夜间 BEV 特征
            map_mask: [B, 1, H, W] 地图元素掩码
        Returns:
            losses: 所有损失的字典
        """
        losses = {}
        
        # 1. 地图元素特质对齐
        if self.use_trait_alignment:
            trait_losses = self.trait_alignment(feat_day, feat_night)
            for k, v in trait_losses.items():
                losses[k] = v * self.total_weight
        
        # 2. BEV 拓扑蒸馏
        if self.use_bev_distillation and bev_day is not None and bev_night is not None:
            bev_losses = self.bev_distillation(bev_day, bev_night)
            for k, v in bev_losses.items():
                losses[k] = v * self.total_weight
        
        # 3. 地图元素重建
        if self.use_map_reconstruction:
            recon_losses = self.map_reconstruction(feat_night, feat_day, map_mask)
            for k, v in recon_losses.items():
                losses[k] = v * self.total_weight
        
        # 总损失
        total_loss = sum(losses.values())
        losses['loss_ms_iifl_total'] = total_loss
        
        return losses


@LOSSES.register_module()
class MSIIFLTemporalConsistencyLoss(nn.Module):
    """
    MS-IIFL 时序一致性损失（可选）
    
    利用相邻帧的地图元素应该一致的先验
    
    创新点：在视频场景中，同一条车道线在相邻帧的特征应该相似
    """
    
    def __init__(self, 
                 temp_weight: float = 0.5,
                 num_frames: int = 2):
        super().__init__()
        self.temp_weight = temp_weight
        self.num_frames = num_frames
    
    def forward(self, feat_sequence: List[torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        Args:
            feat_sequence: List of [B, C, H, W] 特征序列
        Returns:
            losses: 时序一致性损失
        """
        if len(feat_sequence) < 2:
            return {'loss_temporal': torch.tensor(0.0, device=feat_sequence[0].device)}
        
        loss = 0
        for i in range(len(feat_sequence) - 1):
            feat_t = feat_sequence[i]
            feat_t1 = feat_sequence[i + 1]
            
            # 余弦相似度
            feat_t_flat = feat_t.view(feat_t.shape[0], -1)
            feat_t1_flat = feat_t1.view(feat_t1.shape[0], -1)
            
            cos_sim = F.cosine_similarity(feat_t_flat, feat_t1_flat, dim=1)
            loss = loss + (1 - cos_sim.mean())
        
        loss = loss / (len(feat_sequence) - 1)
        
        return {'loss_temporal': loss * self.temp_weight}
