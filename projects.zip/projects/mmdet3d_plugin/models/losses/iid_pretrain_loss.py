"""
IID 预训练损失函数

============================================================================
文献依据 (Literature References)
============================================================================

1. 重建损失 (Reconstruction Loss): ||A × S - I||²
   - Retinex 理论基础公式
   - [Land & McCann 1971] "Lightness and Retinex Theory"
   - [Wei et al. BMVC 2018] "Deep Retinex Decomposition for Low-Light Enhancement"
   
2. Shading 平滑损失 (Shading Smoothness): ||∇S||²
   - Retinex 理论：光照应该是低频/平滑的
   - [Horn 1974] "Determining Lightness from an Image"
   - [Barron & Malik CVPR 2015] "Shape, Illumination, and Reflectance from Shading"
   
3. Map 结构保持损失 (Map Structure Preservation): M · ||∇A - ∇I||²
   - 边缘感知平滑 (Edge-aware Smoothing)
   - [He et al. ECCV 2010] "Guided Image Filtering"
   - [Rudin et al. 1992] Total Variation Regularization
   
4. Albedo 稀疏损失 (Albedo Sparsity): ||∇A||₁
   - Albedo 梯度应该是稀疏的（只在材质边界处有变化）
   - [Barron & Malik CVPR 2015] "Shape, Illumination, and Reflectance from Shading"
   - L1 稀疏约束是 IID 的标准实践
   
5. 光照低频损失 (Illumination Low-frequency): 多尺度梯度约束
   - 光照是低频信号的物理先验
   - [Chen et al. BMVC 2018] "Learning to See in the Dark"
   - [Jiang et al. CVPR 2021] "EnlightenGAN"

6. Albedo 颜色先验 (Albedo Color Prior): 车道线高亮度约束
   - 领域知识：车道线通常是白色/黄色
   - [Caesar et al. CVPR 2020] "nuScenes: A multimodal dataset" - 道路场景特性
   - Map 元素在不同光照下应保持高反射率

7. 光照扰动一致性 (Light Perturbation Consistency): ||A(I) - A(perturb(I))||²
   - 自监督一致性正则化 (Self-supervised Consistency)
   - [Chen et al. ICML 2020] "SimCLR: Simple Framework for Contrastive Learning"
   - [Guo et al. CVPR 2020] "Zero-Reference Low-Light Enhancement" - 自监督光照不变性
   - 核心思想：光照变化不应改变物体固有属性 (Albedo)
   
============================================================================
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet.models import LOSSES


class GradientOperator(nn.Module):
    """梯度计算模块"""
    
    def __init__(self):
        super().__init__()
        # Sobel kernels
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32) / 4.0
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32) / 4.0
        
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
    
    def forward(self, x):
        """
        计算图像梯度
        
        Args:
            x: [B, C, H, W]
        
        Returns:
            grad_x: [B, C, H, W] x 方向梯度
            grad_y: [B, C, H, W] y 方向梯度
        """
        B, C, H, W = x.shape
        
        # 对每个通道分别计算梯度
        grad_x_list = []
        grad_y_list = []
        
        for c in range(C):
            channel = x[:, c:c+1]
            gx = F.conv2d(channel, self.sobel_x, padding=1)
            gy = F.conv2d(channel, self.sobel_y, padding=1)
            grad_x_list.append(gx)
            grad_y_list.append(gy)
        
        grad_x = torch.cat(grad_x_list, dim=1)
        grad_y = torch.cat(grad_y_list, dim=1)
        
        return grad_x, grad_y
    
    def magnitude(self, x):
        """计算梯度幅值"""
        grad_x, grad_y = self.forward(x)
        return torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)


@LOSSES.register_module()
class ReconstructionLoss(nn.Module):
    """
    重建损失: ||A × S - I||²
    
    确保分解的有效性
    """
    
    def __init__(self, loss_weight=1.0, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
    
    def forward(self, albedo, shading, image):
        """
        Args:
            albedo: [B, 3, H, W] 反照率
            shading: [B, 1, H, W] 阴影
            image: [B, 3, H, W] 原始图像
        
        Returns:
            loss: 重建损失
        """
        # 重建
        reconstructed = albedo * shading
        
        # L2 损失
        loss = (reconstructed - image) ** 2
        
        if self.reduction == 'mean':
            loss = loss.mean()
        elif self.reduction == 'sum':
            loss = loss.sum()
        
        return self.loss_weight * loss


@LOSSES.register_module()
class ShadingSmoothLoss(nn.Module):
    """
    Shading 平滑损失: ||∇S||²
    
    光照应该是低频变化的
    """
    
    def __init__(self, loss_weight=0.1, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
        self.gradient = GradientOperator()
    
    def forward(self, shading):
        """
        Args:
            shading: [B, 1, H, W]
        
        Returns:
            loss: 平滑损失
        """
        grad_x, grad_y = self.gradient(shading)
        
        # L2 范数
        loss = grad_x ** 2 + grad_y ** 2
        
        if self.reduction == 'mean':
            loss = loss.mean()
        elif self.reduction == 'sum':
            loss = loss.sum()
        
        return self.loss_weight * loss


@LOSSES.register_module()
class MapStructurePreserveLoss(nn.Module):
    """
    Map 结构保持损失: M · ||∇A - ∇I||²
    
    在 Map 元素区域，Albedo 的边缘应该与原图一致
    这是 MPGID 的核心创新！
    """
    
    def __init__(self, loss_weight=0.5, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
        self.gradient = GradientOperator()
    
    def forward(self, albedo, image, map_prior):
        """
        Args:
            albedo: [B, 3, H, W] 反照率
            image: [B, 3, H, W] 原始图像
            map_prior: [B, 1, H, W] Map 元素先验掩码
        
        Returns:
            loss: 结构保持损失
        """
        # 计算梯度
        albedo_grad_x, albedo_grad_y = self.gradient(albedo)
        image_grad_x, image_grad_y = self.gradient(image)
        
        # 梯度差异
        diff_x = (albedo_grad_x - image_grad_x) ** 2
        diff_y = (albedo_grad_y - image_grad_y) ** 2
        diff = diff_x + diff_y
        
        # 用 Map Prior 加权
        # 在 Map 元素区域，要求梯度一致（结构保持）
        weighted_diff = diff * map_prior
        
        if self.reduction == 'mean':
            # 只对 Map 区域求平均
            loss = weighted_diff.sum() / (map_prior.sum() + 1e-8)
        elif self.reduction == 'sum':
            loss = weighted_diff.sum()
        else:
            loss = weighted_diff.mean()
        
        return self.loss_weight * loss


@LOSSES.register_module()
class AlbedoSparseLoss(nn.Module):
    """
    Albedo 稀疏损失: ||∇A||₁
    
    材质边界应该稀疏，与语义边界对齐
    """
    
    def __init__(self, loss_weight=0.1, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
        self.gradient = GradientOperator()
    
    def forward(self, albedo):
        """
        Args:
            albedo: [B, 3, H, W]
        
        Returns:
            loss: 稀疏损失
        """
        grad_x, grad_y = self.gradient(albedo)
        
        # L1 范数（促进稀疏）
        loss = grad_x.abs() + grad_y.abs()
        
        if self.reduction == 'mean':
            loss = loss.mean()
        elif self.reduction == 'sum':
            loss = loss.sum()
        
        return self.loss_weight * loss


@LOSSES.register_module()
class IlluminationLowFreqLoss(nn.Module):
    """
    光照低频损失
    
    确保 Shading 是低频的，使用多尺度下采样
    """
    
    def __init__(self, loss_weight=0.05, num_scales=3, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.num_scales = num_scales
        self.reduction = reduction
        self.gradient = GradientOperator()
    
    def forward(self, shading):
        """
        Args:
            shading: [B, 1, H, W]
        
        Returns:
            loss: 低频损失
        """
        total_loss = 0
        current = shading
        
        for i in range(self.num_scales):
            # 计算梯度
            grad_magnitude = self.gradient.magnitude(current)
            
            # 越粗糙的尺度，权重越高
            scale_weight = 2 ** i
            total_loss = total_loss + scale_weight * grad_magnitude.mean()
            
            # 下采样
            if i < self.num_scales - 1:
                current = F.avg_pool2d(current, 2)
        
        return self.loss_weight * total_loss


@LOSSES.register_module()
class MultiViewConsistencyLoss(nn.Module):
    """
    多视角一致性损失
    
    同一场景的多个视角，Map 元素的 Albedo 应该一致
    """
    
    def __init__(self, loss_weight=0.1, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
    
    def forward(self, albedos, map_priors):
        """
        Args:
            albedos: List[[B, 3, H, W]] 多视角的 Albedo
            map_priors: List[[B, 1, H, W]] 对应的 Map Prior
        
        Returns:
            loss: 一致性损失
        """
        if len(albedos) < 2:
            return torch.tensor(0.0, device=albedos[0].device)
        
        total_loss = 0
        count = 0
        
        # 计算所有视角对之间的一致性
        for i in range(len(albedos)):
            for j in range(i + 1, len(albedos)):
                # 只在 Map 区域计算一致性
                mask = map_priors[i] * map_priors[j]
                
                # Albedo 差异
                diff = (albedos[i] - albedos[j]) ** 2
                weighted_diff = diff * mask
                
                # 归一化
                loss = weighted_diff.sum() / (mask.sum() + 1e-8)
                total_loss = total_loss + loss
                count += 1
        
        if count > 0:
            total_loss = total_loss / count
        
        return self.loss_weight * total_loss


@LOSSES.register_module()
class AlbedoColorPriorLoss(nn.Module):
    """
    Albedo 颜色先验损失
    
    车道线的 Albedo 应该是高亮度（白色/黄色）
    """
    
    def __init__(self, loss_weight=0.1, target_brightness=0.8, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.target_brightness = target_brightness  # 目标亮度
        self.reduction = reduction
    
    def forward(self, albedo, map_prior):
        """
        在 Map Prior 指示的区域，Albedo 应该是高亮度
        
        Args:
            albedo: [B, 3, H, W]
            map_prior: [B, 1, H, W]
        
        Returns:
            loss: 颜色先验损失（永远为正）
        """
        # 计算亮度 (ITU-R BT.601 标准)
        luminance = 0.299 * albedo[:, 0:1] + 0.587 * albedo[:, 1:2] + 0.114 * albedo[:, 2:3]
        
        # 方法1: 鼓励 map 区域亮度接近目标值（MSE loss，永远为正）
        # 亮度越接近 target_brightness，loss 越小
        brightness_diff = (luminance - self.target_brightness) ** 2
        
        # 方法2: 同时惩罚非 map 区域的高亮度（对比损失）
        non_map_prior = 1.0 - map_prior
        # 非 map 区域不应该太亮
        non_map_penalty = F.relu(luminance - 0.5) ** 2  # 超过 0.5 的部分
        
        # 加权组合
        map_loss = brightness_diff * map_prior
        non_map_loss = non_map_penalty * non_map_prior * 0.1  # 较小权重
        
        total_loss = map_loss + non_map_loss
        
        if self.reduction == 'mean':
            # 分别归一化
            map_loss_normalized = map_loss.sum() / (map_prior.sum() + 1e-8)
            non_map_loss_normalized = non_map_loss.sum() / (non_map_prior.sum() + 1e-8)
            loss = map_loss_normalized + non_map_loss_normalized
        else:
            loss = total_loss.mean()
        
        return self.loss_weight * loss


@LOSSES.register_module()
class AlbedoColorFidelityLoss(nn.Module):
    """
    Albedo 颜色保真度损失 - 防止颜色偏移
    
    核心问题：Albedo 容易出现颜色偏移（如绿色调）
    
    解决方案：
    1. 色度一致性：Albedo 的色度（hue）应该与原图一致
    2. 色彩比例一致：RGB 通道的比例关系应该保持
    3. 灰度世界约束：非 Map 区域的平均颜色应该接近灰色
    
    文献依据：
    - [Forsyth 1990] "A Novel Algorithm for Color Constancy"
    - [Buchsbaum 1980] "A Spatial Processor Model for Object Colour Perception"
    - [van de Weijer et al. 2007] "Edge-Based Color Constancy"
    """
    
    def __init__(self, loss_weight=0.3, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
    
    def forward(self, albedo, image, map_prior=None):
        """
        Args:
            albedo: [B, 3, H, W]
            image: [B, 3, H, W] 原始图像
            map_prior: [B, 1, H, W] 可选，Map 区域掩码
        
        Returns:
            loss: 颜色保真度损失
        """
        B, C, H, W = albedo.shape
        eps = 1e-8
        
        # 1. 色彩比例一致性 (Chromaticity Consistency)
        # 计算归一化的色彩比例
        albedo_sum = albedo.sum(dim=1, keepdim=True).clamp(min=eps)
        image_sum = image.sum(dim=1, keepdim=True).clamp(min=eps)
        
        albedo_chroma = albedo / albedo_sum  # [B, 3, H, W]
        image_chroma = image / image_sum
        
        # 色度差异
        chroma_diff = (albedo_chroma - image_chroma) ** 2
        
        # 2. 灰度世界约束 (Gray World)
        # 整体平均颜色应该接近灰色（防止整体色偏）
        albedo_mean = albedo.mean(dim=(2, 3))  # [B, 3]
        gray_target = albedo_mean.mean(dim=1, keepdim=True)  # [B, 1]
        gray_world_loss = ((albedo_mean - gray_target) ** 2).mean()
        
        # 3. 通道比例一致性
        # R/G, G/B, R/B 的比例应该与原图接近
        ratio_r_g_albedo = (albedo[:, 0:1] + eps) / (albedo[:, 1:2] + eps)
        ratio_g_b_albedo = (albedo[:, 1:2] + eps) / (albedo[:, 2:3] + eps)
        
        ratio_r_g_image = (image[:, 0:1] + eps) / (image[:, 1:2] + eps)
        ratio_g_b_image = (image[:, 1:2] + eps) / (image[:, 2:3] + eps)
        
        # 使用 log 比例以处理不同数量级
        ratio_loss = (
            (torch.log(ratio_r_g_albedo) - torch.log(ratio_r_g_image)) ** 2 +
            (torch.log(ratio_g_b_albedo) - torch.log(ratio_g_b_image)) ** 2
        )
        
        # 组合损失
        if map_prior is not None:
            # 在 Map 区域更严格地约束颜色
            chroma_loss = (chroma_diff * map_prior).sum() / (map_prior.sum() + eps)
            ratio_loss_weighted = (ratio_loss * map_prior).sum() / (map_prior.sum() + eps)
        else:
            chroma_loss = chroma_diff.mean()
            ratio_loss_weighted = ratio_loss.mean()
        
        # 总损失
        total_loss = chroma_loss + 0.5 * gray_world_loss + 0.3 * ratio_loss_weighted
        
        return self.loss_weight * total_loss


@LOSSES.register_module()
class IIDPretrainLoss(nn.Module):
    """
    完整的 IID 预训练损失
    
    组合所有损失函数
    """
    
    def __init__(self,
                 recon_weight=1.0,
                 shading_smooth_weight=0.1,
                 map_structure_weight=0.5,
                 albedo_sparse_weight=0.1,
                 illumination_lowfreq_weight=0.05,
                 albedo_color_weight=0.1,
                 albedo_fidelity_weight=0.3,  # 新增：颜色保真度
                 reduction='mean'):
        super().__init__()
        
        self.recon_loss = ReconstructionLoss(loss_weight=recon_weight, reduction=reduction)
        self.shading_smooth_loss = ShadingSmoothLoss(loss_weight=shading_smooth_weight, reduction=reduction)
        self.map_structure_loss = MapStructurePreserveLoss(loss_weight=map_structure_weight, reduction=reduction)
        self.albedo_sparse_loss = AlbedoSparseLoss(loss_weight=albedo_sparse_weight, reduction=reduction)
        self.illumination_lowfreq_loss = IlluminationLowFreqLoss(loss_weight=illumination_lowfreq_weight, num_scales=3, reduction=reduction)
        self.albedo_color_loss = AlbedoColorPriorLoss(loss_weight=albedo_color_weight, target_brightness=0.8, reduction=reduction)
        self.albedo_fidelity_loss = AlbedoColorFidelityLoss(loss_weight=albedo_fidelity_weight, reduction=reduction)  # 新增
        
        self.gradient = GradientOperator()
    
    def forward(self, albedo, shading, image, map_prior):
        """
        计算所有损失
        
        Args:
            albedo: [B, 3, H, W]
            shading: [B, 1, H, W]
            image: [B, 3, H, W] 原始图像
            map_prior: [B, 1, H, W] Map 元素先验
        
        Returns:
            total_loss: 总损失
            loss_dict: 各项损失的字典
        """
        loss_dict = {}
        
        # 重建损失
        loss_recon = self.recon_loss(albedo, shading, image)
        loss_dict['loss_recon'] = loss_recon
        
        # Shading 平滑损失
        loss_shading_smooth = self.shading_smooth_loss(shading)
        loss_dict['loss_shading_smooth'] = loss_shading_smooth
        
        # Map 结构保持损失（核心创新）
        loss_map_structure = self.map_structure_loss(albedo, image, map_prior)
        loss_dict['loss_map_structure'] = loss_map_structure
        
        # Albedo 稀疏损失
        loss_albedo_sparse = self.albedo_sparse_loss(albedo)
        loss_dict['loss_albedo_sparse'] = loss_albedo_sparse
        
        # 光照低频损失
        loss_illumination_lowfreq = self.illumination_lowfreq_loss(shading)
        loss_dict['loss_illumination_lowfreq'] = loss_illumination_lowfreq
        
        # Albedo 颜色先验损失
        loss_albedo_color = self.albedo_color_loss(albedo, map_prior)
        loss_dict['loss_albedo_color'] = loss_albedo_color
        
        # Albedo 颜色保真度损失（防止颜色偏移）
        loss_albedo_fidelity = self.albedo_fidelity_loss(albedo, image, map_prior)
        loss_dict['loss_albedo_fidelity'] = loss_albedo_fidelity
        
        # 总损失
        total_loss = (loss_recon + loss_shading_smooth + loss_map_structure + 
                     loss_albedo_sparse + loss_illumination_lowfreq + loss_albedo_color +
                     loss_albedo_fidelity)  # 新增
        loss_dict['loss_iid_pretrain'] = total_loss
        
        return total_loss, loss_dict


@LOSSES.register_module()
class LightPerturbationLoss(nn.Module):
    """
    光照扰动一致性损失
    
    对同一图像施加不同的光照扰动，分解出的 Albedo 应该一致
    这是自监督预训练的重要信号！
    """
    
    def __init__(self, loss_weight=0.5, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
    
    def forward(self, albedo_normal, albedo_perturbed, map_prior=None):
        """
        Args:
            albedo_normal: [B, 3, H, W] 正常光照下的 Albedo
            albedo_perturbed: [B, 3, H, W] 扰动光照下的 Albedo
            map_prior: [B, 1, H, W] 可选，只在 Map 区域计算
        
        Returns:
            loss: 一致性损失
        """
        diff = (albedo_normal - albedo_perturbed) ** 2
        
        if map_prior is not None:
            # 只在 Map 区域计算
            weighted_diff = diff * map_prior
            if self.reduction == 'mean':
                loss = weighted_diff.sum() / (map_prior.sum() * 3 + 1e-8)  # 3 是通道数
            else:
                loss = weighted_diff.mean()
        else:
            if self.reduction == 'mean':
                loss = diff.mean()
            else:
                loss = diff.sum()
        
        return self.loss_weight * loss


# =============================================================================
# 新增模块：多视角一致性 & BEV 光照场
# =============================================================================

@LOSSES.register_module()
class MultiViewPhotometricLoss(nn.Module):
    """
    多视角光度一致性损失 (Multi-View Photometric Consistency)
    
    ============================================================================
    文献依据:
    - [Godard et al. CVPR 2017] "Unsupervised Monocular Depth Estimation with 
      Left-Right Consistency" - 多视角光度一致性的经典方法
    - [Zhou et al. CVPR 2017] "Unsupervised Learning of Depth and Ego-Motion 
      from Video" - 自监督多视角一致性
    - [Watson et al. ICCV 2021] "Temporal Consistency for Self-Supervised 
      Monocular Depth" - 时序+多视角一致性
    ============================================================================
    
    核心思想：
    相邻相机的重叠区域观察到的是同一物理表面，因此 Albedo 应该一致。
    这是一个很强的自监督信号，无需任何标注。
    
    nuScenes 相机布局:
    - CAM_FRONT, CAM_FRONT_LEFT, CAM_FRONT_RIGHT (前方 3 个)
    - CAM_BACK, CAM_BACK_LEFT, CAM_BACK_RIGHT (后方 3 个)
    
    相邻相机对:
    - FRONT_LEFT <-> FRONT (有重叠)
    - FRONT <-> FRONT_RIGHT (有重叠)
    - BACK_LEFT <-> BACK (有重叠)
    - BACK <-> BACK_RIGHT (有重叠)
    """
    
    def __init__(self, 
                 loss_weight=1.0, 
                 overlap_threshold=0.1,
                 use_ssim=True,
                 ssim_weight=0.85,
                 reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.overlap_threshold = overlap_threshold
        self.use_ssim = use_ssim
        self.ssim_weight = ssim_weight
        self.reduction = reduction
        
        # nuScenes 相邻相机对索引 (0-5: FL, F, FR, BL, B, BR)
        # 基于 nuScenes 的相机布局
        self.adjacent_pairs = [
            (0, 1),  # FRONT_LEFT <-> FRONT
            (1, 2),  # FRONT <-> FRONT_RIGHT  
            (3, 4),  # BACK_LEFT <-> BACK
            (4, 5),  # BACK <-> BACK_RIGHT
        ]
    
    def compute_ssim(self, x, y, window_size=11):
        """计算 SSIM (Structural Similarity Index)"""
        C1 = 0.01 ** 2
        C2 = 0.03 ** 2
        
        # 使用均值滤波近似
        pad = window_size // 2
        mu_x = F.avg_pool2d(x, window_size, stride=1, padding=pad)
        mu_y = F.avg_pool2d(y, window_size, stride=1, padding=pad)
        
        mu_x_sq = mu_x ** 2
        mu_y_sq = mu_y ** 2
        mu_xy = mu_x * mu_y
        
        sigma_x_sq = F.avg_pool2d(x ** 2, window_size, stride=1, padding=pad) - mu_x_sq
        sigma_y_sq = F.avg_pool2d(y ** 2, window_size, stride=1, padding=pad) - mu_y_sq
        sigma_xy = F.avg_pool2d(x * y, window_size, stride=1, padding=pad) - mu_xy
        
        ssim = ((2 * mu_xy + C1) * (2 * sigma_xy + C2)) / \
               ((mu_x_sq + mu_y_sq + C1) * (sigma_x_sq + sigma_y_sq + C2))
        
        return torch.clamp((1 - ssim) / 2, 0, 1)
    
    def forward(self, albedos, map_priors, cam_params=None):
        """
        计算多视角 Albedo 一致性损失
        
        Args:
            albedos: [B, N_cam, C, H, W] 多视角的 Albedo
            map_priors: [B, N_cam, 1, H, W] 对应的 Map Prior
            cam_params: 相机参数（可选，用于精确投影）
        
        Returns:
            loss: 多视角一致性损失
        """
        B, N_cam, C, H, W = albedos.shape
        
        if N_cam < 2:
            return torch.tensor(0.0, device=albedos.device, requires_grad=True)
        
        total_loss = 0
        valid_pairs = 0
        
        for i, j in self.adjacent_pairs:
            if i >= N_cam or j >= N_cam:
                continue
            
            albedo_i = albedos[:, i]  # [B, C, H, W]
            albedo_j = albedos[:, j]  # [B, C, H, W]
            
            prior_i = map_priors[:, i]  # [B, 1, H, W]
            prior_j = map_priors[:, j]  # [B, 1, H, W]
            
            # 简化版：使用图像边缘区域作为近似重叠区域
            # 相机 i 的右边缘 vs 相机 j 的左边缘
            overlap_width = W // 6  # 假设约 1/6 的宽度有重叠
            
            if i < j:
                # i 在左，j 在右
                albedo_i_overlap = albedo_i[:, :, :, -overlap_width:]
                albedo_j_overlap = albedo_j[:, :, :, :overlap_width]
                prior_i_overlap = prior_i[:, :, :, -overlap_width:]
                prior_j_overlap = prior_j[:, :, :, :overlap_width]
            else:
                # i 在右，j 在左
                albedo_i_overlap = albedo_i[:, :, :, :overlap_width]
                albedo_j_overlap = albedo_j[:, :, :, -overlap_width:]
                prior_i_overlap = prior_i[:, :, :, :overlap_width]
                prior_j_overlap = prior_j[:, :, :, -overlap_width:]
            
            # 计算联合 mask（两边都有 Map Prior 的区域）
            joint_mask = prior_i_overlap * prior_j_overlap
            
            # 只有当重叠区域有足够的 Map Prior 时才计算
            if joint_mask.sum() < self.overlap_threshold * joint_mask.numel():
                continue
            
            # L1 损失
            l1_loss = (albedo_i_overlap - albedo_j_overlap).abs()
            
            if self.use_ssim:
                # SSIM 损失
                ssim_loss = self.compute_ssim(albedo_i_overlap, albedo_j_overlap)
                photo_loss = self.ssim_weight * ssim_loss.mean(dim=1, keepdim=True) + \
                            (1 - self.ssim_weight) * l1_loss.mean(dim=1, keepdim=True)
            else:
                photo_loss = l1_loss.mean(dim=1, keepdim=True)
            
            # 加权
            weighted_loss = photo_loss * joint_mask
            pair_loss = weighted_loss.sum() / (joint_mask.sum() + 1e-8)
            
            total_loss = total_loss + pair_loss
            valid_pairs += 1
        
        if valid_pairs > 0:
            total_loss = total_loss / valid_pairs
        
        return self.loss_weight * total_loss


@LOSSES.register_module()
class BEVLightFieldLoss(nn.Module):
    """
    BEV 空间光照场一致性损失 (BEV-Space Light Field Consistency)
    
    ============================================================================
    文献依据:
    - [Li et al. ECCV 2022] "BEVFormer: Learning Bird's-Eye-View Representation 
      from Multi-Camera Images" - BEV 空间特征学习
    - [Philion & Fidler ECCV 2020] "Lift, Splat, Shoot" - 2D->BEV 投影
    - [Mildenhall et al. ECCV 2020] "NeRF: Representing Scenes as Neural 
      Radiance Fields" - 光照场建模的启发
    ============================================================================
    
    核心思想：
    1. 将多视角的 Shading 投影到 BEV 空间
    2. 在 BEV 空间建模全局光照场（应该是平滑、连续的）
    3. 同一 BEV 位置从不同相机看到的光照应该一致
    
    物理意义：
    - 地面上同一点从不同角度观测，受到的光照是相同的
    - BEV 光照场应该是低频、平滑的（自然光照特性）
    """
    
    def __init__(self,
                 loss_weight=1.0,
                 bev_h=100,
                 bev_w=100,
                 bev_range=[-50, 50, -25, 25],  # [x_min, x_max, y_min, y_max] in meters
                 smoothness_weight=0.5,
                 consistency_weight=0.5,
                 reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.bev_h = bev_h
        self.bev_w = bev_w
        self.bev_range = bev_range
        self.smoothness_weight = smoothness_weight
        self.consistency_weight = consistency_weight
        self.reduction = reduction
        
        self.gradient = GradientOperator()
        
        # 创建 BEV 网格坐标
        self._init_bev_grid()
    
    def _init_bev_grid(self):
        """初始化 BEV 网格坐标"""
        x_min, x_max, y_min, y_max = self.bev_range
        
        # 创建 BEV 网格 (x: 前后, y: 左右)
        xs = torch.linspace(x_min, x_max, self.bev_w)
        ys = torch.linspace(y_min, y_max, self.bev_h)
        
        # [H, W, 2] -> [H, W] for x and y
        grid_y, grid_x = torch.meshgrid(ys, xs, indexing='ij')
        
        # 保存为 buffer
        self.register_buffer('bev_grid_x', grid_x, persistent=False)
        self.register_buffer('bev_grid_y', grid_y, persistent=False)
    
    def project_to_bev_simple(self, shading, cam_idx):
        """
        简化版的 2D->BEV 投影
        
        基于相机位置的简单映射（不需要精确的相机参数）
        
        Args:
            shading: [B, 1, H, W] 单个相机的 Shading
            cam_idx: 相机索引 (0-5)
        
        Returns:
            bev_shading: [B, 1, bev_h, bev_w]
            valid_mask: [B, 1, bev_h, bev_w] 有效区域掩码
        """
        B, _, H, W = shading.shape
        device = shading.device
        
        # nuScenes 相机近似方向
        # 0: FRONT_LEFT, 1: FRONT, 2: FRONT_RIGHT
        # 3: BACK_LEFT, 4: BACK, 5: BACK_RIGHT
        cam_configs = {
            0: {'angle': 55, 'fov': 70, 'region': 'front_left'},
            1: {'angle': 0, 'fov': 70, 'region': 'front'},
            2: {'angle': -55, 'fov': 70, 'region': 'front_right'},
            3: {'angle': 125, 'fov': 70, 'region': 'back_left'},
            4: {'angle': 180, 'fov': 70, 'region': 'back'},
            5: {'angle': -125, 'fov': 70, 'region': 'back_right'},
        }
        
        config = cam_configs.get(cam_idx, cam_configs[1])
        
        # 创建该相机对应的 BEV 区域掩码
        angle_rad = config['angle'] * 3.14159 / 180
        fov_rad = config['fov'] * 3.14159 / 180
        
        # 计算每个 BEV 点相对于自车的角度
        bev_angles = torch.atan2(self.bev_grid_y, self.bev_grid_x + 1e-8)
        
        # 该相机可见的角度范围
        angle_min = angle_rad - fov_rad / 2
        angle_max = angle_rad + fov_rad / 2
        
        # 创建可见区域掩码
        visible_mask = (bev_angles >= angle_min) & (bev_angles <= angle_max)
        
        # 只考虑一定距离内的区域
        bev_dist = torch.sqrt(self.bev_grid_x ** 2 + self.bev_grid_y ** 2)
        distance_mask = (bev_dist > 3) & (bev_dist < 50)  # 3-50 米
        
        valid_mask = (visible_mask & distance_mask).float().unsqueeze(0).unsqueeze(0)
        valid_mask = valid_mask.expand(B, 1, -1, -1)
        
        # 简化投影：将图像下半部分映射到 BEV
        # 假设图像下半部分对应近处地面
        shading_lower = shading[:, :, H//2:, :]  # [B, 1, H/2, W]
        
        # 双线性插值到 BEV 尺寸
        bev_shading = F.interpolate(shading_lower, size=(self.bev_h, self.bev_w), 
                                    mode='bilinear', align_corners=False)
        
        # 应用可见掩码
        bev_shading = bev_shading * valid_mask
        
        return bev_shading, valid_mask
    
    def forward(self, shadings, map_priors=None):
        """
        计算 BEV 光照场损失
        
        Args:
            shadings: [B, N_cam, 1, H, W] 多视角的 Shading
            map_priors: [B, N_cam, 1, H, W] 对应的 Map Prior（可选）
        
        Returns:
            loss: BEV 光照场损失
            loss_dict: 细分损失
        """
        B, N_cam, _, H, W = shadings.shape
        device = shadings.device
        
        loss_dict = {}
        
        # 1. 将每个相机的 Shading 投影到 BEV
        bev_shadings = []
        bev_masks = []
        
        for cam_idx in range(N_cam):
            shading = shadings[:, cam_idx]  # [B, 1, H, W]
            bev_s, mask = self.project_to_bev_simple(shading, cam_idx)
            bev_shadings.append(bev_s)
            bev_masks.append(mask)
        
        bev_shadings = torch.stack(bev_shadings, dim=1)  # [B, N_cam, 1, bev_h, bev_w]
        bev_masks = torch.stack(bev_masks, dim=1)  # [B, N_cam, 1, bev_h, bev_w]
        
        # 2. 计算重叠区域的一致性损失
        # 多个相机看到同一位置的 Shading 应该一致
        overlap_count = bev_masks.sum(dim=1)  # [B, 1, bev_h, bev_w]
        overlap_mask = (overlap_count > 1).float()
        
        if overlap_mask.sum() > 0:
            # 计算加权平均 Shading
            weighted_sum = (bev_shadings * bev_masks).sum(dim=1)  # [B, 1, bev_h, bev_w]
            mean_shading = weighted_sum / (overlap_count + 1e-8)
            
            # 每个相机与平均值的差异
            consistency_loss = 0
            for cam_idx in range(N_cam):
                diff = (bev_shadings[:, cam_idx] - mean_shading) ** 2
                diff = diff * bev_masks[:, cam_idx] * overlap_mask
                consistency_loss = consistency_loss + diff.sum() / (overlap_mask.sum() + 1e-8)
            
            consistency_loss = consistency_loss / N_cam
        else:
            consistency_loss = torch.tensor(0.0, device=device, requires_grad=True)
        
        loss_dict['bev_consistency'] = consistency_loss
        
        # 3. 计算 BEV 光照场的平滑性损失
        # 使用所有可见区域的融合 Shading
        total_mask = (overlap_count > 0).float()
        fused_shading = (bev_shadings * bev_masks).sum(dim=1) / (overlap_count + 1e-8)
        fused_shading = fused_shading * total_mask
        
        if total_mask.sum() > 0:
            # 梯度平滑约束
            grad_x, grad_y = self.gradient(fused_shading)
            smoothness_loss = (grad_x ** 2 + grad_y ** 2) * total_mask
            smoothness_loss = smoothness_loss.sum() / (total_mask.sum() + 1e-8)
        else:
            smoothness_loss = torch.tensor(0.0, device=device, requires_grad=True)
        
        loss_dict['bev_smoothness'] = smoothness_loss
        
        # 总损失
        total_loss = (self.consistency_weight * consistency_loss + 
                     self.smoothness_weight * smoothness_loss)
        loss_dict['bev_light_field'] = total_loss
        
        return self.loss_weight * total_loss, loss_dict


@LOSSES.register_module()
class TemporalConsistencyLoss(nn.Module):
    """
    时序一致性损失（可选扩展）
    
    连续帧之间的 Albedo 应该一致
    """
    
    def __init__(self, loss_weight=0.5, reduction='mean'):
        super().__init__()
        self.loss_weight = loss_weight
        self.reduction = reduction
    
    def forward(self, albedo_t, albedo_t1, flow=None):
        """
        Args:
            albedo_t: 当前帧 Albedo
            albedo_t1: 上一帧 Albedo
            flow: 光流（可选，用于对齐）
        
        Returns:
            loss: 时序一致性损失
        """
        if flow is not None:
            # 使用光流 warp 上一帧
            albedo_t1_warped = self.warp_with_flow(albedo_t1, flow)
        else:
            # 简单对比
            albedo_t1_warped = albedo_t1
        
        diff = (albedo_t - albedo_t1_warped) ** 2
        loss = diff.mean() if self.reduction == 'mean' else diff.sum()
        
        return self.loss_weight * loss
    
    def warp_with_flow(self, img, flow):
        """使用光流 warp 图像"""
        B, C, H, W = img.shape
        
        # 创建基础网格
        grid_y, grid_x = torch.meshgrid(
            torch.arange(H, device=img.device, dtype=img.dtype),
            torch.arange(W, device=img.device, dtype=img.dtype),
            indexing='ij'
        )
        grid = torch.stack([grid_x, grid_y], dim=-1)  # [H, W, 2]
        grid = grid.unsqueeze(0).expand(B, -1, -1, -1)  # [B, H, W, 2]
        
        # 添加光流偏移
        grid = grid + flow.permute(0, 2, 3, 1)  # flow: [B, 2, H, W] -> [B, H, W, 2]
        
        # 归一化到 [-1, 1]
        grid[..., 0] = 2 * grid[..., 0] / (W - 1) - 1
        grid[..., 1] = 2 * grid[..., 1] / (H - 1) - 1
        
        # 采样
        warped = F.grid_sample(img, grid, mode='bilinear', padding_mode='zeros', align_corners=True)
        
        return warped
