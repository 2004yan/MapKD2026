"""
Element-Specific Enhancement Loss for MSALA

核心创新：基于 Map 元素类型施加不同的增强约束

设计思想：
- 车道线 (Lane/Divider): 线性边缘结构 → 方向感知的边缘一致性
- 人行横道 (Pedestrian Crossing): 周期性条纹 → Gabor 纹理一致性 + FFT 周期约束
- 道路边界 (Boundary): 连续轮廓 → 曲率平滑性 + 形状保持

与通用结构保护的区别：
- 通用方法：全图统一约束
- Element-Specific：不同区域不同策略，通过 Attention Map 加权

参考文献：
- CLRNet (CVPR 2022): 车道线方向场约束
- FDA (CVPR 2020): 频域分解
- 纹理分析: Gabor 滤波器组
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import BaseModule
import math


class DirectionalSobelFilter(nn.Module):
    """
    方向感知的 Sobel 滤波器
    
    对于车道线，不仅检测边缘强度，还检测边缘方向
    车道线通常有特定的方向（近似纵向）
    """
    
    def __init__(self):
        super().__init__()
        
        # 水平和垂直 Sobel
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        
        # 对角方向 Sobel
        sobel_45 = torch.tensor([[0, 1, 2], [-1, 0, 1], [-2, -1, 0]], dtype=torch.float32)
        sobel_135 = torch.tensor([[-2, -1, 0], [-1, 0, 1], [0, 1, 2]], dtype=torch.float32)
        
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
        self.register_buffer('sobel_45', sobel_45.view(1, 1, 3, 3))
        self.register_buffer('sobel_135', sobel_135.view(1, 1, 3, 3))
    
    def forward(self, x):
        """
        计算多方向边缘响应
        
        Args:
            x: [B, C, H, W]
        
        Returns:
            edge_magnitude: [B, 1, H, W] 边缘强度
            edge_direction: [B, 1, H, W] 边缘方向 (0~π)
        """
        # 转灰度
        if x.shape[1] == 3:
            gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            gray = x.mean(dim=1, keepdim=True)
        
        # 多方向边缘
        gx = F.conv2d(gray, self.sobel_x, padding=1)
        gy = F.conv2d(gray, self.sobel_y, padding=1)
        
        # 边缘强度和方向
        magnitude = torch.sqrt(gx ** 2 + gy ** 2 + 1e-6)
        direction = torch.atan2(gy, gx)  # -π ~ π
        
        return magnitude, direction, gx, gy


class GaborFilterBank(nn.Module):
    """
    Gabor 滤波器组
    
    用于检测人行横道的周期性条纹纹理
    Gabor 滤波器对特定方向和频率的纹理敏感
    """
    
    def __init__(self, 
                 orientations=[0, 45, 90, 135],
                 frequencies=[0.1, 0.15, 0.2],
                 kernel_size=21,
                 sigma=3.0):
        super().__init__()
        
        self.orientations = orientations
        self.frequencies = frequencies
        self.kernel_size = kernel_size
        
        # 创建 Gabor 滤波器组
        filters = []
        for theta in orientations:
            for freq in frequencies:
                kernel = self._create_gabor_kernel(kernel_size, sigma, theta, freq)
                filters.append(kernel)
        
        # 注册为 buffer
        filters = torch.stack(filters, dim=0).unsqueeze(1)  # [N_filters, 1, K, K]
        self.register_buffer('filters', filters)
        self.num_filters = len(filters)
    
    def _create_gabor_kernel(self, size, sigma, theta, frequency):
        """创建单个 Gabor 核"""
        theta_rad = theta * math.pi / 180
        
        # 创建坐标网格
        x = torch.arange(size) - size // 2
        y = torch.arange(size) - size // 2
        y, x = torch.meshgrid(y, x)
        x, y = x.float(), y.float()
        
        # 旋转坐标
        x_theta = x * math.cos(theta_rad) + y * math.sin(theta_rad)
        y_theta = -x * math.sin(theta_rad) + y * math.cos(theta_rad)
        
        # Gabor 公式
        gaussian = torch.exp(-(x_theta ** 2 + y_theta ** 2) / (2 * sigma ** 2))
        sinusoid = torch.cos(2 * math.pi * frequency * x_theta)
        
        gabor = gaussian * sinusoid
        
        # 归一化
        gabor = gabor - gabor.mean()
        gabor = gabor / (gabor.std() + 1e-6)
        
        return gabor
    
    def forward(self, x):
        """
        应用 Gabor 滤波器组
        
        Args:
            x: [B, C, H, W]
        
        Returns:
            responses: [B, N_filters, H, W] Gabor 响应
            texture_energy: [B, 1, H, W] 纹理能量（所有响应的平方和）
        """
        # 转灰度
        if x.shape[1] == 3:
            gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            gray = x.mean(dim=1, keepdim=True)
        
        # 应用滤波器组
        pad_size = self.kernel_size // 2
        responses = F.conv2d(gray, self.filters, padding=pad_size)  # [B, N_filters, H, W]
        
        # 纹理能量
        texture_energy = (responses ** 2).mean(dim=1, keepdim=True)
        
        return responses, texture_energy


class LaplacianFilter(nn.Module):
    """
    Laplacian 滤波器
    
    用于检测道路边界的形状/轮廓
    Laplacian 对图像的二阶导数敏感，突出边缘和拐角
    """
    
    def __init__(self):
        super().__init__()
        
        # 标准 Laplacian 核
        laplacian = torch.tensor([
            [0, 1, 0],
            [1, -4, 1],
            [0, 1, 0]
        ], dtype=torch.float32)
        
        # LoG (Laplacian of Gaussian) 近似
        log_kernel = torch.tensor([
            [0, 0, -1, 0, 0],
            [0, -1, -2, -1, 0],
            [-1, -2, 16, -2, -1],
            [0, -1, -2, -1, 0],
            [0, 0, -1, 0, 0]
        ], dtype=torch.float32)
        
        self.register_buffer('laplacian', laplacian.view(1, 1, 3, 3))
        self.register_buffer('log_kernel', log_kernel.view(1, 1, 5, 5))
    
    def forward(self, x, use_log=False):
        """
        计算 Laplacian 响应
        
        Args:
            x: [B, C, H, W]
            use_log: 是否使用 LoG 核
        
        Returns:
            laplacian_response: [B, 1, H, W]
        """
        # 转灰度
        if x.shape[1] == 3:
            gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            gray = x.mean(dim=1, keepdim=True)
        
        if use_log:
            response = F.conv2d(gray, self.log_kernel, padding=2)
        else:
            response = F.conv2d(gray, self.laplacian, padding=1)
        
        return response


class ElementSpecificEnhancementLoss(BaseModule):
    """
    Element-Specific Enhancement Loss
    
    核心创新：基于 Map 元素 Attention Map，对不同区域施加不同约束
    
    损失组成：
    1. Lane Loss: 方向感知的边缘一致性
    2. Crossing Loss: Gabor 纹理一致性 + 周期约束
    3. Boundary Loss: Laplacian 形状一致性 + 平滑约束
    """
    
    def __init__(self,
                 num_classes=3,
                 lane_weight=1.0,
                 crossing_weight=1.0,
                 boundary_weight=1.0,
                 use_direction_loss=True,
                 use_periodicity_loss=True,
                 use_smoothness_loss=True,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.num_classes = num_classes
        self.lane_weight = lane_weight
        self.crossing_weight = crossing_weight
        self.boundary_weight = boundary_weight
        
        self.use_direction_loss = use_direction_loss
        self.use_periodicity_loss = use_periodicity_loss
        self.use_smoothness_loss = use_smoothness_loss
        
        # 滤波器
        self.sobel = DirectionalSobelFilter()
        self.gabor = GaborFilterBank()
        self.laplacian = LaplacianFilter()
    
    def lane_edge_loss(self, original, enhanced, attention):
        """
        车道线边缘一致性损失
        
        约束：增强前后的边缘强度和方向应一致
        """
        # 计算边缘
        mag_orig, dir_orig, gx_orig, gy_orig = self.sobel(original)
        mag_enh, dir_enh, gx_enh, gy_enh = self.sobel(enhanced)
        
        # 边缘强度一致性（加权）
        loss_magnitude = F.l1_loss(mag_enh * attention, mag_orig * attention)
        
        # 梯度方向一致性（可选）
        if self.use_direction_loss:
            # 使用梯度向量的内积作为方向一致性度量
            dot_product = gx_orig * gx_enh + gy_orig * gy_enh
            norm_orig = torch.sqrt(gx_orig ** 2 + gy_orig ** 2 + 1e-6)
            norm_enh = torch.sqrt(gx_enh ** 2 + gy_enh ** 2 + 1e-6)
            cos_sim = dot_product / (norm_orig * norm_enh)
            
            # 方向一致性损失（1 - cos_sim，加权）
            loss_direction = ((1 - cos_sim) * attention).mean()
        else:
            loss_direction = 0.0
        
        return loss_magnitude + 0.5 * loss_direction
    
    def crossing_texture_loss(self, original, enhanced, attention):
        """
        人行横道纹理一致性损失
        
        约束：Gabor 响应一致 + FFT 周期特性一致
        """
        # Gabor 响应
        gabor_orig, energy_orig = self.gabor(original)
        gabor_enh, energy_enh = self.gabor(enhanced)
        
        # 纹理能量一致性（加权）
        loss_texture = F.l1_loss(energy_enh * attention, energy_orig * attention)
        
        # 周期性约束（FFT）
        if self.use_periodicity_loss:
            # 转灰度
            if original.shape[1] == 3:
                gray_orig = 0.299 * original[:, 0:1] + 0.587 * original[:, 1:2] + 0.114 * original[:, 2:3]
                gray_enh = 0.299 * enhanced[:, 0:1] + 0.587 * enhanced[:, 1:2] + 0.114 * enhanced[:, 2:3]
            else:
                gray_orig = original.mean(dim=1, keepdim=True)
                gray_enh = enhanced.mean(dim=1, keepdim=True)
            
            # 加权 FFT
            weighted_orig = gray_orig * attention
            weighted_enh = gray_enh * attention
            
            # FFT 幅度谱
            fft_orig = torch.fft.fft2(weighted_orig)
            fft_enh = torch.fft.fft2(weighted_enh)
            
            amp_orig = torch.abs(fft_orig)
            amp_enh = torch.abs(fft_enh)
            
            # 幅度谱一致性
            loss_periodicity = F.l1_loss(amp_enh, amp_orig)
        else:
            loss_periodicity = 0.0
        
        return loss_texture + 0.3 * loss_periodicity
    
    def boundary_shape_loss(self, original, enhanced, attention):
        """
        道路边界形状一致性损失
        
        约束：Laplacian 响应一致 + 二阶梯度平滑
        """
        # Laplacian 响应
        lap_orig = self.laplacian(original)
        lap_enh = self.laplacian(enhanced)
        
        # 形状一致性（加权）
        loss_shape = F.l1_loss(lap_enh * attention, lap_orig * attention)
        
        # 平滑性约束
        if self.use_smoothness_loss:
            # 计算增强图像的二阶梯度
            # 转灰度
            if enhanced.shape[1] == 3:
                gray_enh = 0.299 * enhanced[:, 0:1] + 0.587 * enhanced[:, 1:2] + 0.114 * enhanced[:, 2:3]
            else:
                gray_enh = enhanced.mean(dim=1, keepdim=True)
            
            # 二阶梯度
            grad_x = gray_enh[:, :, :, 1:] - gray_enh[:, :, :, :-1]
            grad_y = gray_enh[:, :, 1:, :] - gray_enh[:, :, :-1, :]
            
            grad_xx = grad_x[:, :, :, 1:] - grad_x[:, :, :, :-1]
            grad_yy = grad_y[:, :, 1:, :] - grad_y[:, :, :-1, :]
            
            # 需要调整 attention 的尺寸
            H, W = grad_xx.shape[2:]
            attention_xx = F.interpolate(attention, size=(H, W), mode='bilinear', align_corners=False)
            
            H, W = grad_yy.shape[2:]
            attention_yy = F.interpolate(attention, size=(H, W), mode='bilinear', align_corners=False)
            
            # 平滑损失
            loss_smoothness = (torch.abs(grad_xx) * attention_xx).mean() + \
                              (torch.abs(grad_yy) * attention_yy).mean()
        else:
            loss_smoothness = 0.0
        
        return loss_shape + 0.2 * loss_smoothness
    
    def forward(self, original, enhanced, attention_maps):
        """
        计算 Element-Specific Enhancement Loss
        
        Args:
            original: [B, C, H, W] 原始/扰动图像，范围 [0, 1]
            enhanced: [B, C, H, W] 增强后图像，范围 [0, 1]
            attention_maps: [B, num_classes, H, W] Map 元素 Attention
                           类别顺序: 0=lane, 1=crossing, 2=boundary
        
        Returns:
            losses: dict of losses
            total_loss: scalar
        """
        losses = {}
        
        # 调整 attention_maps 尺寸
        if attention_maps.shape[2:] != original.shape[2:]:
            attention_maps = F.interpolate(
                attention_maps, 
                size=original.shape[2:], 
                mode='bilinear', 
                align_corners=False
            )
        
        # 车道线损失
        if self.num_classes > 0:
            lane_attn = attention_maps[:, 0:1, :, :]
            losses['loss_lane_edge'] = self.lane_edge_loss(
                original, enhanced, lane_attn
            ) * self.lane_weight
        
        # 人行横道损失
        if self.num_classes > 1:
            crossing_attn = attention_maps[:, 1:2, :, :]
            losses['loss_crossing_texture'] = self.crossing_texture_loss(
                original, enhanced, crossing_attn
            ) * self.crossing_weight
        
        # 道路边界损失
        if self.num_classes > 2:
            boundary_attn = attention_maps[:, 2:3, :, :]
            losses['loss_boundary_shape'] = self.boundary_shape_loss(
                original, enhanced, boundary_attn
            ) * self.boundary_weight
        
        total_loss = sum(losses.values())
        
        return losses, total_loss
