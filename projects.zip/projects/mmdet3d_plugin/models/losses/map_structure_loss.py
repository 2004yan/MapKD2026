"""
Map 元素感知的结构保护损失

参考文献：
- FDA (CVPR 2020): 频域域适应
- CLRNet (CVPR 2022): 车道线几何约束
- SSIM: 结构相似度

核心思想：
在光照增强过程中，保护 Map 元素的结构特征：
1. 边缘一致性：车道线的边界不能被模糊
2. 结构相似度：人行横道的纹理不能丢失
3. 相位一致性：几何结构在频域中的相位应该保持
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class SobelFilter(nn.Module):
    """
    Sobel 边缘检测滤波器
    
    用于提取图像的边缘/梯度信息，对光照变化相对鲁棒
    """
    
    def __init__(self):
        super().__init__()
        
        # Sobel 算子
        sobel_x = torch.tensor([
            [-1, 0, 1],
            [-2, 0, 2],
            [-1, 0, 1]
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        
        sobel_y = torch.tensor([
            [-1, -2, -1],
            [0, 0, 0],
            [1, 2, 1]
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        
        # 注册为 buffer（不参与训练）
        self.register_buffer('sobel_x', sobel_x)
        self.register_buffer('sobel_y', sobel_y)
    
    def forward(self, x):
        """
        计算 Sobel 边缘
        
        Args:
            x: [B, C, H, W] 图像
        
        Returns:
            edge: [B, C, H, W] 边缘图
        """
        B, C, H, W = x.shape
        
        # 对每个通道分别计算
        edges = []
        for c in range(C):
            x_c = x[:, c:c+1, :, :]
            
            # 计算 x 和 y 方向的梯度
            grad_x = F.conv2d(x_c, self.sobel_x, padding=1)
            grad_y = F.conv2d(x_c, self.sobel_y, padding=1)
            
            # 梯度幅度
            edge = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
            edges.append(edge)
        
        return torch.cat(edges, dim=1)


class EdgeConsistencyLoss(nn.Module):
    """
    边缘一致性损失
    
    核心思想：
    增强前后的边缘/梯度应该保持一致，
    因为 Map 元素（车道线、人行横道等）的边界是关键特征
    
    参考：车道线检测中边缘特征的重要性
    """
    
    def __init__(self, loss_weight=1.0):
        super().__init__()
        self.sobel = SobelFilter()
        self.loss_weight = loss_weight
    
    def forward(self, original, enhanced):
        """
        计算边缘一致性损失
        
        Args:
            original: [B, C, H, W] 原始图像（[0, 1] 范围）
            enhanced: [B, C, H, W] 增强后图像（[0, 1] 范围）
        
        Returns:
            loss: 边缘一致性损失
        """
        # 计算边缘
        edge_original = self.sobel(original)
        edge_enhanced = self.sobel(enhanced)
        
        # L1 损失
        loss = F.l1_loss(edge_enhanced, edge_original)
        
        return loss * self.loss_weight


class SSIMLoss(nn.Module):
    """
    结构相似度损失 (SSIM-based)
    
    核心思想：
    SSIM 关注结构信息而非像素强度，
    对光照变化更鲁棒
    
    参考：SSIM (IEEE TIP 2004)
    """
    
    def __init__(self, window_size=11, loss_weight=1.0):
        super().__init__()
        self.window_size = window_size
        self.loss_weight = loss_weight
        
        # 创建高斯窗口
        self.register_buffer('window', self._create_window(window_size, 3))
    
    def _create_window(self, window_size, channel):
        """创建高斯窗口"""
        sigma = 1.5
        gauss = torch.tensor([
            math.exp(-(x - window_size // 2) ** 2 / float(2 * sigma ** 2))
            for x in range(window_size)
        ])
        gauss = gauss / gauss.sum()
        
        _1D_window = gauss.unsqueeze(1)
        _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
        
        window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
        return window
    
    def _ssim(self, img1, img2):
        """计算 SSIM"""
        C1 = 0.01 ** 2
        C2 = 0.03 ** 2
        
        channel = img1.size(1)
        window = self.window
        
        if img1.is_cuda:
            window = window.cuda(img1.get_device())
        
        mu1 = F.conv2d(img1, window, padding=self.window_size // 2, groups=channel)
        mu2 = F.conv2d(img2, window, padding=self.window_size // 2, groups=channel)
        
        mu1_sq = mu1.pow(2)
        mu2_sq = mu2.pow(2)
        mu1_mu2 = mu1 * mu2
        
        sigma1_sq = F.conv2d(img1 * img1, window, padding=self.window_size // 2, groups=channel) - mu1_sq
        sigma2_sq = F.conv2d(img2 * img2, window, padding=self.window_size // 2, groups=channel) - mu2_sq
        sigma12 = F.conv2d(img1 * img2, window, padding=self.window_size // 2, groups=channel) - mu1_mu2
        
        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / \
                   ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))
        
        return ssim_map.mean()
    
    def forward(self, original, enhanced):
        """
        计算 SSIM 损失
        
        Args:
            original: [B, C, H, W] 原始图像
            enhanced: [B, C, H, W] 增强后图像
        
        Returns:
            loss: 1 - SSIM（SSIM 越大越好，所以用 1 - SSIM 作为损失）
        """
        ssim_value = self._ssim(original, enhanced)
        loss = 1 - ssim_value
        
        return loss * self.loss_weight


class PhaseConsistencyLoss(nn.Module):
    """
    频域相位一致性损失
    
    核心思想（参考 FDA）：
    - 图像的频域表示 = 幅度 (Amplitude) × 相位 (Phase)
    - 幅度主要包含光照/风格信息
    - 相位主要包含结构/几何信息
    
    因此，增强前后的相位应该保持一致，以保护几何结构
    
    参考：FDA (CVPR 2020)
    """
    
    def __init__(self, loss_weight=1.0):
        super().__init__()
        self.loss_weight = loss_weight
    
    def forward(self, original, enhanced):
        """
        计算相位一致性损失
        
        Args:
            original: [B, C, H, W] 原始图像
            enhanced: [B, C, H, W] 增强后图像
        
        Returns:
            loss: 相位一致性损失
        """
        # FFT 变换
        fft_original = torch.fft.fft2(original)
        fft_enhanced = torch.fft.fft2(enhanced)
        
        # 提取相位
        phase_original = torch.angle(fft_original)
        phase_enhanced = torch.angle(fft_enhanced)
        
        # 相位差异损失
        # 使用 cos 相似度，因为相位是周期性的
        phase_diff = torch.cos(phase_original - phase_enhanced)
        loss = 1 - phase_diff.mean()
        
        return loss * self.loss_weight


class FrequencyStructureLoss(nn.Module):
    """
    频域结构保护损失
    
    核心思想：
    - 低频：光照/全局亮度（可以改变）
    - 高频：边缘/纹理/结构（应该保护）
    
    Map 元素的结构特征主要在高频，所以重点保护高频
    
    参考：FDA 的频域分解思想
    """
    
    def __init__(self, low_freq_ratio=0.1, loss_weight=1.0):
        super().__init__()
        self.low_freq_ratio = low_freq_ratio
        self.loss_weight = loss_weight
    
    def _create_high_freq_mask(self, h, w, device):
        """
        创建高频掩码
        
        保护高频区域（边缘、纹理），允许低频变化（光照）
        """
        # 创建距离矩阵
        cy, cx = h // 2, w // 2
        y = torch.arange(h, device=device).float() - cy
        x = torch.arange(w, device=device).float() - cx
        # PyTorch < 1.10 不支持 indexing 参数，默认行为已是 'ij'
        Y, X = torch.meshgrid(y, x)
        
        # 归一化距离
        dist = torch.sqrt(X ** 2 + Y ** 2)
        max_dist = math.sqrt(cy ** 2 + cx ** 2)
        dist_norm = dist / max_dist
        
        # 高频掩码：距离中心越远，权重越大
        # 低频区域（中心）权重为 0，高频区域权重为 1
        low_freq_radius = self.low_freq_ratio
        high_freq_mask = (dist_norm > low_freq_radius).float()
        
        return high_freq_mask
    
    def forward(self, original, enhanced):
        """
        计算高频结构保护损失
        
        Args:
            original: [B, C, H, W] 原始图像
            enhanced: [B, C, H, W] 增强后图像
        
        Returns:
            loss: 高频结构保护损失
        """
        B, C, H, W = original.shape
        
        # FFT 变换
        fft_original = torch.fft.fft2(original)
        fft_enhanced = torch.fft.fft2(enhanced)
        
        # 移到中心
        fft_original = torch.fft.fftshift(fft_original, dim=(-2, -1))
        fft_enhanced = torch.fft.fftshift(fft_enhanced, dim=(-2, -1))
        
        # 创建高频掩码
        high_freq_mask = self._create_high_freq_mask(H, W, original.device)
        high_freq_mask = high_freq_mask.unsqueeze(0).unsqueeze(0)  # [1, 1, H, W]
        
        # 提取高频部分
        high_freq_original = fft_original * high_freq_mask
        high_freq_enhanced = fft_enhanced * high_freq_mask
        
        # 计算高频差异
        # 使用幅度的差异
        amp_original = torch.abs(high_freq_original)
        amp_enhanced = torch.abs(high_freq_enhanced)
        
        loss = F.l1_loss(amp_enhanced, amp_original)
        
        return loss * self.loss_weight


class MapStructureLoss(nn.Module):
    """
    Map 元素感知的结构保护损失（总损失）
    
    整合所有结构保护约束：
    1. 边缘一致性：保护车道线边界
    2. SSIM：保护整体结构
    3. 相位一致性：保护几何信息
    4. 高频保护：保护纹理细节
    
    这是论文的核心创新点！
    """
    
    def __init__(self,
                 use_edge_loss=True,
                 use_ssim_loss=True,
                 use_phase_loss=True,
                 use_freq_loss=True,
                 edge_weight=1.0,
                 ssim_weight=1.0,
                 phase_weight=0.5,
                 freq_weight=0.5,
                 ssim_window_size=11,
                 low_freq_ratio=0.1):
        super().__init__()
        
        self.use_edge_loss = use_edge_loss
        self.use_ssim_loss = use_ssim_loss
        self.use_phase_loss = use_phase_loss
        self.use_freq_loss = use_freq_loss
        
        if use_edge_loss:
            self.edge_loss = EdgeConsistencyLoss(loss_weight=edge_weight)
        
        if use_ssim_loss:
            self.ssim_loss = SSIMLoss(window_size=ssim_window_size, loss_weight=ssim_weight)
        
        if use_phase_loss:
            self.phase_loss = PhaseConsistencyLoss(loss_weight=phase_weight)
        
        if use_freq_loss:
            self.freq_loss = FrequencyStructureLoss(
                low_freq_ratio=low_freq_ratio, loss_weight=freq_weight
            )
    
    def forward(self, original, enhanced):
        """
        计算总的结构保护损失
        
        Args:
            original: [B, C, H, W] 原始图像（[0, 1] 范围）
            enhanced: [B, C, H, W] 增强后图像（[0, 1] 范围）
        
        Returns:
            losses: dict，包含各个损失分量
            total_loss: 总损失
        """
        losses = {}
        total_loss = 0
        
        if self.use_edge_loss:
            loss_edge = self.edge_loss(original, enhanced)
            losses['loss_edge'] = loss_edge
            total_loss = total_loss + loss_edge
        
        if self.use_ssim_loss:
            loss_ssim = self.ssim_loss(original, enhanced)
            losses['loss_ssim'] = loss_ssim
            total_loss = total_loss + loss_ssim
        
        if self.use_phase_loss:
            loss_phase = self.phase_loss(original, enhanced)
            losses['loss_phase'] = loss_phase
            total_loss = total_loss + loss_phase
        
        if self.use_freq_loss:
            loss_freq = self.freq_loss(original, enhanced)
            losses['loss_freq'] = loss_freq
            total_loss = total_loss + loss_freq
        
        losses['loss_structure_total'] = total_loss
        
        return losses, total_loss
