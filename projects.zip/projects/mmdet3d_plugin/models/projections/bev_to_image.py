"""
BEV-to-Image Projection Module for MSALA

核心创新：将 BEV 空间的 Map 元素反投影到多视角图像空间，
生成 Element-Specific Attention Map 用于指导光照增强。

这是首次将检测结果反向用于指导增强的尝试。

参考：
- MapTR: BEV 特征到 Map 元素的解码
- BEVFormer: 多视角到 BEV 的投影（我们做反向）
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import BaseModule
import numpy as np


class BEVToImageProjection(BaseModule):
    """
    将 BEV 空间的 Map 元素投影到多视角图像空间
    
    核心思想：
    1. MapTR 检测出 BEV 空间的 polyline 点序列
    2. 使用相机内外参，将这些点投影回各个相机的图像平面
    3. 生成每类 Map 元素的 Attention Map
    
    技术细节：
    - BEV 点 (x, y, z=0) → 世界坐标 → 相机坐标 → 图像坐标 (u, v)
    - 使用高斯核将稀疏点扩展为连续区域
    - 处理视野范围和遮挡
    """
    
    def __init__(self,
                 pc_range=[-15.0, -30.0, -2.0, 15.0, 30.0, 2.0],
                 num_classes=3,  # divider, ped_crossing, boundary
                 gaussian_sigma=10.0,  # 高斯核标准差
                 line_width=5,  # 线宽（像素）
                 z_offset=0.0,  # BEV 点的 Z 高度偏移
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.pc_range = pc_range
        self.num_classes = num_classes
        self.gaussian_sigma = gaussian_sigma
        self.line_width = line_width
        self.z_offset = z_offset
    
    def bev_to_world(self, bev_points, pc_range):
        """
        将归一化的 BEV 点转换到世界坐标系
        
        Args:
            bev_points: [N, P, 2] 归一化的 BEV 点 (0~1)
            pc_range: [x_min, y_min, z_min, x_max, y_max, z_max]
        
        Returns:
            world_points: [N, P, 3] 世界坐标系点
        """
        # 反归一化到世界坐标
        x = bev_points[..., 0] * (pc_range[3] - pc_range[0]) + pc_range[0]
        y = bev_points[..., 1] * (pc_range[4] - pc_range[1]) + pc_range[1]
        z = torch.full_like(x, self.z_offset)  # BEV 点假设在地面
        
        world_points = torch.stack([x, y, z], dim=-1)
        return world_points
    
    def world_to_image(self, world_points, lidar2img):
        """
        将世界坐标系点投影到图像平面
        
        Args:
            world_points: [N, P, 3] 世界坐标系点
            lidar2img: [B, num_cams, 4, 4] LiDAR 到图像的投影矩阵
        
        Returns:
            img_points: [B, num_cams, N, P, 2] 图像坐标
            valid_mask: [B, num_cams, N, P] 有效点掩码
        """
        B, num_cams = lidar2img.shape[:2]
        N, P = world_points.shape[:2]
        device = world_points.device
        
        # 扩展 world_points 到 batch 维度
        world_points = world_points.unsqueeze(0).unsqueeze(0)  # [1, 1, N, P, 3]
        world_points = world_points.expand(B, num_cams, -1, -1, -1)  # [B, C, N, P, 3]
        
        # 齐次坐标
        ones = torch.ones_like(world_points[..., :1])
        world_homo = torch.cat([world_points, ones], dim=-1)  # [B, C, N, P, 4]
        
        # 投影
        lidar2img = lidar2img.view(B, num_cams, 1, 1, 4, 4)  # [B, C, 1, 1, 4, 4]
        img_homo = torch.matmul(lidar2img, world_homo.unsqueeze(-1))  # [B, C, N, P, 4, 1]
        img_homo = img_homo.squeeze(-1)  # [B, C, N, P, 4]
        
        # 归一化
        depth = img_homo[..., 2:3].clamp(min=1e-5)
        img_points = img_homo[..., :2] / depth  # [B, C, N, P, 2]
        
        # 有效性掩码（在图像范围内且深度为正）
        valid_mask = (depth.squeeze(-1) > 0.1)  # 深度大于 0.1m
        
        return img_points, valid_mask, depth.squeeze(-1)
    
    def generate_attention_map(self, img_points, valid_mask, img_shape, class_labels=None):
        """
        根据投影点生成 Attention Map
        
        Args:
            img_points: [B, num_cams, N, P, 2] 图像坐标
            valid_mask: [B, num_cams, N, P] 有效点掩码
            img_shape: (H, W) 图像尺寸
            class_labels: [N] 每个 instance 的类别
        
        Returns:
            attention_maps: [B, num_cams, num_classes, H, W]
        """
        B, num_cams, N, P = img_points.shape[:4]
        H, W = img_shape
        device = img_points.device
        
        # 初始化每类的 attention map
        attention_maps = torch.zeros(B, num_cams, self.num_classes, H, W, device=device)
        
        # 创建坐标网格用于高斯核计算
        y_grid = torch.arange(H, device=device).float().view(1, 1, H, 1)
        x_grid = torch.arange(W, device=device).float().view(1, 1, 1, W)
        
        for b in range(B):
            for c in range(num_cams):
                for n in range(N):
                    # 获取该 instance 的类别
                    if class_labels is not None:
                        cls_idx = class_labels[n].item() if isinstance(class_labels[n], torch.Tensor) else class_labels[n]
                    else:
                        cls_idx = 0  # 默认类别
                    
                    if cls_idx >= self.num_classes:
                        continue
                    
                    # 获取该 instance 的有效点
                    points = img_points[b, c, n]  # [P, 2]
                    mask = valid_mask[b, c, n]  # [P]
                    
                    valid_points = points[mask]  # [P', 2]
                    
                    if valid_points.shape[0] < 2:
                        continue
                    
                    # 使用线段连接点生成 attention
                    for i in range(valid_points.shape[0] - 1):
                        p1 = valid_points[i]
                        p2 = valid_points[i + 1]
                        
                        # 在线段上采样点
                        num_samples = max(int(torch.norm(p2 - p1).item() / 2), 1)
                        t = torch.linspace(0, 1, num_samples, device=device)
                        line_points = p1.unsqueeze(0) + t.unsqueeze(1) * (p2 - p1).unsqueeze(0)
                        
                        # 为每个采样点生成高斯
                        for pt in line_points:
                            x, y = pt[0], pt[1]
                            
                            # 检查是否在图像范围内
                            if 0 <= x < W and 0 <= y < H:
                                # 高斯核
                                gaussian = torch.exp(-((x_grid - x) ** 2 + (y_grid - y) ** 2) / (2 * self.gaussian_sigma ** 2))
                                gaussian = gaussian.squeeze(0).squeeze(0)  # [H, W]
                                
                                # 累加到对应类别
                                attention_maps[b, c, cls_idx] = torch.max(
                                    attention_maps[b, c, cls_idx], 
                                    gaussian
                                )
        
        return attention_maps
    
    def forward(self, bev_predictions, lidar2img, img_shape, class_labels=None):
        """
        主前向传播
        
        Args:
            bev_predictions: [N, P, 2] 或 list of [P, 2] BEV 空间的预测点（归一化 0~1）
            lidar2img: [B, num_cams, 4, 4] 投影矩阵
            img_shape: (H, W) 图像尺寸
            class_labels: [N] 类别标签
        
        Returns:
            attention_maps: [B, num_cams, num_classes, H, W]
        """
        # 如果是 list，转换为 tensor
        if isinstance(bev_predictions, list):
            max_points = max(p.shape[0] for p in bev_predictions)
            N = len(bev_predictions)
            device = bev_predictions[0].device
            
            bev_points = torch.zeros(N, max_points, 2, device=device)
            for i, p in enumerate(bev_predictions):
                bev_points[i, :p.shape[0]] = p
        else:
            bev_points = bev_predictions
        
        # BEV → World
        world_points = self.bev_to_world(bev_points, self.pc_range)
        
        # World → Image
        img_points, valid_mask, depth = self.world_to_image(world_points, lidar2img)
        
        # 生成 Attention Map
        attention_maps = self.generate_attention_map(
            img_points, valid_mask, img_shape, class_labels
        )
        
        return attention_maps


class MapElementAttentionGenerator(BaseModule):
    """
    基于 GT Map 元素生成图像空间的 Attention Map
    
    训练时使用 GT，推理时可选用预测结果
    
    这个模块封装了完整的 Map 元素感知流程：
    1. 解析 GT Map 元素（从 gt_bboxes_3d）
    2. 投影到图像空间
    3. 生成分类别的 Attention Map
    """
    
    def __init__(self,
                 pc_range=[-15.0, -30.0, -2.0, 15.0, 30.0, 2.0],
                 num_classes=3,
                 gaussian_sigma=8.0,
                 use_gt=True,  # 训练时使用 GT
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.projection = BEVToImageProjection(
            pc_range=pc_range,
            num_classes=num_classes,
            gaussian_sigma=gaussian_sigma
        )
        self.num_classes = num_classes
        self.use_gt = use_gt
        self.pc_range = pc_range
    
    def parse_gt_map_elements(self, gt_bboxes_3d, gt_labels_3d):
        """
        从 GT 数据中解析 Map 元素
        
        Args:
            gt_bboxes_3d: GT Map 元素（LiDARInstanceLines 类型）
            gt_labels_3d: 类别标签 tensor
        
        Returns:
            bev_points: [N, P, 2] 归一化的 BEV 点 (0~1)
            class_labels: [N] 类别
        """
        pts = None
        
        # 尝试获取点坐标
        # LiDARInstanceLines 有 fixed_num_sampled_points 属性（返回 list of tensor）
        if hasattr(gt_bboxes_3d, 'fixed_num_sampled_points'):
            pts_list = gt_bboxes_3d.fixed_num_sampled_points
            if len(pts_list) > 0:
                # 转换为 tensor [N, P, 2]
                pts = torch.stack(pts_list, dim=0)
        # 兼容其他格式
        elif hasattr(gt_bboxes_3d, 'fixed_num_sampled_points_torch'):
            pts = gt_bboxes_3d.fixed_num_sampled_points_torch
        elif hasattr(gt_bboxes_3d, 'tensor'):
            # 某些格式可能直接是 tensor
            pts = gt_bboxes_3d.tensor
        
        if pts is None or len(pts) == 0:
            return None, None
        
        # 确保 pts 在正确的设备上
        if isinstance(gt_labels_3d, torch.Tensor):
            device = gt_labels_3d.device
            if not isinstance(pts, torch.Tensor):
                pts = torch.tensor(pts, device=device, dtype=torch.float32)
            else:
                pts = pts.to(device)
        
        # 归一化到 [0, 1]
        # 注意：GT 坐标是世界坐标系 [-max_x, max_x], [-max_y, max_y]
        pts_normalized = pts.clone().float()
        pts_normalized[..., 0] = (pts[..., 0] - self.pc_range[0]) / (self.pc_range[3] - self.pc_range[0])
        pts_normalized[..., 1] = (pts[..., 1] - self.pc_range[1]) / (self.pc_range[4] - self.pc_range[1])
        
        # Clamp 到 [0, 1] 范围
        pts_normalized = pts_normalized.clamp(0, 1)
        
        return pts_normalized, gt_labels_3d
    
    def forward(self, gt_bboxes_3d, gt_labels_3d, lidar2img, img_shape):
        """
        生成 Map 元素 Attention Map
        
        Args:
            gt_bboxes_3d: GT Map 元素
            gt_labels_3d: 类别标签
            lidar2img: [B, num_cams, 4, 4] 投影矩阵
            img_shape: (H, W) 图像尺寸
        
        Returns:
            attention_maps: [B, num_cams, num_classes, H, W]
        """
        # 解析 GT
        bev_points, class_labels = self.parse_gt_map_elements(gt_bboxes_3d, gt_labels_3d)
        
        if bev_points is None:
            # 无有效 GT，返回均匀 attention
            B = lidar2img.shape[0]
            num_cams = lidar2img.shape[1]
            H, W = img_shape
            return torch.ones(B, num_cams, self.num_classes, H, W, device=lidar2img.device) / self.num_classes
        
        # 投影生成 Attention Map
        attention_maps = self.projection(
            bev_points, lidar2img, img_shape, class_labels
        )
        
        # 归一化
        attention_maps = attention_maps / (attention_maps.max() + 1e-6)
        
        return attention_maps


class FastMapElementAttention(BaseModule):
    """
    快速版本：使用预计算的特征图生成 Attention
    
    为了减少计算量，不进行精确的几何投影，
    而是基于图像特征本身推断 Map 元素区域。
    
    技术思路：
    - 使用轻量级分割网络预测 Map 元素概率图
    - 或者使用边缘检测 + 纹理分析进行启发式估计
    """
    
    def __init__(self,
                 in_channels=3,
                 num_classes=3,
                 use_learned=True,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.num_classes = num_classes
        self.use_learned = use_learned
        
        if use_learned:
            # 轻量级分割网络
            self.attention_net = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, 1, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, 32, 3, 1, 1),
                nn.ReLU(inplace=True),
                nn.Conv2d(32, num_classes, 1, 1, 0),
                nn.Sigmoid()
            )
        else:
            # 基于边缘的启发式方法
            self.sobel_x = nn.Conv2d(1, 1, 3, 1, 1, bias=False)
            self.sobel_y = nn.Conv2d(1, 1, 3, 1, 1, bias=False)
            
            sobel_x_kernel = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
            sobel_y_kernel = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
            
            self.sobel_x.weight.data = sobel_x_kernel.view(1, 1, 3, 3)
            self.sobel_y.weight.data = sobel_y_kernel.view(1, 1, 3, 3)
            
            for param in [self.sobel_x.parameters(), self.sobel_y.parameters()]:
                for p in param:
                    p.requires_grad = False
    
    def forward(self, img):
        """
        从图像直接生成 Attention Map
        
        Args:
            img: [B*N, C, H, W] 图像
        
        Returns:
            attention_maps: [B*N, num_classes, H, W]
        """
        if self.use_learned:
            return self.attention_net(img)
        else:
            # 基于边缘的启发式方法
            gray = img.mean(dim=1, keepdim=True)  # [B*N, 1, H, W]
            
            edge_x = self.sobel_x(gray)
            edge_y = self.sobel_y(gray)
            edge_magnitude = torch.sqrt(edge_x ** 2 + edge_y ** 2 + 1e-6)
            
            # 归一化
            edge_magnitude = edge_magnitude / (edge_magnitude.max() + 1e-6)
            
            # 简单假设：边缘区域可能是 Map 元素
            # 这是一个粗略的近似
            attention = edge_magnitude.repeat(1, self.num_classes, 1, 1)
            
            return attention
