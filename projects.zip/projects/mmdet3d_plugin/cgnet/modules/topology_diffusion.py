# Copyright (C) 2024 Xiaomi Corporation.
# Topology Diffusion Refiner for Lane Graph Refinement

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Dict, Optional, Tuple
from mmcv.runner.base_module import BaseModule


class SimpleDenoiser(BaseModule):
    """
    简化版去噪网络，基于Transformer Encoder
    输入: 带噪声的邻接矩阵 + 节点特征 + BEV条件
    输出: 去噪后的邻接矩阵logits
    """
    
    def __init__(self, 
                 hidden_dim: int = 256,
                 num_layers: int = 4,
                 num_heads: int = 8,
                 dropout: float = 0.1,
                 init_cfg: dict = None):
        super().__init__(init_cfg=init_cfg)
        
        self.hidden_dim = hidden_dim
        
        # 边特征编码器: 将[0,1]的邻接值映射到hidden_dim
        self.edge_embed = nn.Sequential(
            nn.Linear(1, hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // 2, hidden_dim)
        )
        
        # 噪声水平编码器 (时间步编码)
        self.noise_level_embed = nn.Sequential(
            nn.Linear(1, hidden_dim // 4),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // 4, hidden_dim)
        )
        
        # 条件投影层
        self.cond_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # 节点特征投影
        self.node_proj = nn.Linear(hidden_dim, hidden_dim)
        
        # 融合层: 将节点特征、边特征、条件融合
        self.fusion_layer = nn.Sequential(
            nn.Linear(hidden_dim * 3, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True)
        )
        
        # Transformer处理
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=num_heads,
            dim_feedforward=hidden_dim * 4,
            dropout=dropout,
            activation='relu',
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        
        # 输出头: 预测邻接矩阵的logits
        self.output_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // 2, 1)
        )
        
    def forward(self, 
                adj_noisy: torch.Tensor,
                node_features: torch.Tensor, 
                bev_cond: torch.Tensor,
                noise_level: torch.Tensor) -> torch.Tensor:
        """
        Args:
            adj_noisy: 带噪声的邻接矩阵 [B, N, N]
            node_features: 节点特征 [B, N, D]
            bev_cond: BEV条件特征 [B, D]
            noise_level: 噪声水平 [B, 1]
        Returns:
            edge_logits: 边预测的logits [B, N, N]
        """
        B, N, _ = adj_noisy.shape
        device = adj_noisy.device
        
        # 1. 编码边特征
        edge_feat = self.edge_embed(adj_noisy.unsqueeze(-1))  # [B, N, N, D]
        
        # 2. 编码噪声水平
        # noise_level输入是[B, 1]，直接处理
        noise_embed = self.noise_level_embed(noise_level)  # [B, D]
        noise_embed = noise_embed.unsqueeze(1).unsqueeze(1).expand(-1, N, N, -1)  # [B, N, N, D]
        
        # 3. 编码节点特征
        node_feat = self.node_proj(node_features)  # [B, N, D]
        # 创建节点对特征: 每对节点的特征组合
        node_feat_i = node_feat.unsqueeze(2).expand(-1, -1, N, -1)  # [B, N, N, D]
        node_feat_j = node_feat.unsqueeze(1).expand(-1, N, -1, -1)  # [B, N, N, D]
        node_pair_feat = node_feat_i + node_feat_j  # [B, N, N, D]
        
        # 4. 编码BEV条件
        cond_feat = self.cond_proj(bev_cond)  # [B, D]
        cond_feat = cond_feat.unsqueeze(1).unsqueeze(1).expand(-1, N, N, -1)  # [B, N, N, D]
        
        # 5. 融合所有特征
        combined = torch.cat([edge_feat + noise_embed, node_pair_feat, cond_feat], dim=-1)  # [B, N, N, 3D]
        fused = self.fusion_layer(combined)  # [B, N, N, D]
        
        # 6. 将边特征展平为序列，用Transformer处理
        fused_flat = fused.view(B, N * N, -1)  # [B, N*N, D]
        transformed = self.transformer(fused_flat)  # [B, N*N, D]
        transformed = transformed.view(B, N, N, -1)  # [B, N, N, D]
        
        # 7. 预测边的logits
        edge_logits = self.output_head(transformed).squeeze(-1)  # [B, N, N]
        
        return edge_logits


class TopologyDiffusionRefiner(BaseModule):
    """
    拓扑Diffusion精炼器
    
    核心思想:
    - 训练时: 对GT邻接矩阵添加噪声，学习去噪
    - 推理时: 将CGNet预测作为初始值，迭代精炼
    """
    
    def __init__(self,
                 hidden_dim: int = 256,
                 num_layers: int = 4,
                 num_heads: int = 8,
                 num_refine_steps: int = 5,
                 noise_schedule: str = 'cosine',
                 dropout: float = 0.1,
                 loss_weight: float = 1.0,
                 init_cfg: dict = None):
        super().__init__(init_cfg=init_cfg)
        
        self.hidden_dim = hidden_dim
        self.num_refine_steps = num_refine_steps
        self.noise_schedule = noise_schedule
        self.loss_weight = loss_weight
        
        # 去噪网络
        self.denoiser = SimpleDenoiser(
            hidden_dim=hidden_dim,
            num_layers=num_layers,
            num_heads=num_heads,
            dropout=dropout
        )
        
        # BEV特征编码器
        self.bev_encoder = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(start_dim=1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, hidden_dim)
        )
        
        # 预计算噪声调度参数
        self._init_noise_schedule()
        
    def _init_noise_schedule(self):
        """初始化噪声调度"""
        steps = self.num_refine_steps
        if self.noise_schedule == 'cosine':
            # Cosine schedule: 从1.0平滑过渡到0
            t = torch.linspace(0, 1, steps + 1)
            alphas = torch.cos((t + 0.008) / 1.008 * math.pi / 2) ** 2
            alphas = alphas / alphas[0]
            self.register_buffer('noise_levels', 1 - alphas[1:])  # [steps]
        else:
            # Linear schedule
            self.register_buffer('noise_levels', torch.linspace(0.9, 0.1, steps))
            
    def add_noise(self, adj: torch.Tensor, noise_level: float) -> torch.Tensor:
        """
        对邻接矩阵添加噪声
        
        使用伯努利噪声: 以noise_level的概率随机翻转边
        """
        # 生成随机翻转mask
        flip_mask = torch.rand_like(adj) < noise_level
        # 翻转: 0->1, 1->0
        adj_noisy = adj.clone()
        adj_noisy[flip_mask] = 1 - adj_noisy[flip_mask]
        return adj_noisy
    
    def add_noise_continuous(self, adj: torch.Tensor, noise_level: float) -> torch.Tensor:
        """
        连续版本的噪声添加: 混合原始值和随机值
        更适合梯度传播
        """
        random_adj = torch.rand_like(adj)
        adj_noisy = (1 - noise_level) * adj + noise_level * random_adj
        return adj_noisy
        
    def forward(self, 
                adj_gt: torch.Tensor,
                adj_pred: torch.Tensor,
                node_features: torch.Tensor,
                bev_features: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        训练前向传播
        
        Args:
            adj_gt: GT邻接矩阵 [B, N, N] (已经是匹配后的正样本)
            adj_pred: CGNet预测的邻接矩阵 [B, N, N]
            node_features: 节点特征 (来自CGNet的vertex_feat) [B, N, D]
            bev_features: BEV特征 [B, H*W, D] 或 [B, D]
        
        Returns:
            loss_dict: 包含diffusion loss
        """
        B = adj_gt.shape[0]
        device = adj_gt.device
        
        # 1. 编码BEV条件
        if bev_features.dim() == 3:
            # [B, H*W, D] -> [B, D]
            bev_cond = self.bev_encoder(bev_features.permute(0, 2, 1))
        else:
            bev_cond = bev_features
            
        # 2. 随机采样噪声水平
        t_idx = torch.randint(0, self.num_refine_steps, (B,), device=device)
        noise_level = self.noise_levels[t_idx]  # [B]
        
        # 3. 添加噪声到GT邻接矩阵
        adj_noisy = torch.stack([
            self.add_noise_continuous(adj_gt[i], noise_level[i].item())
            for i in range(B)
        ])
        
        # 4. 预测去噪后的邻接矩阵
        adj_pred_logits = self.denoiser(
            adj_noisy,
            node_features,
            bev_cond,
            noise_level.unsqueeze(-1)
        )
        
        # 5. 计算损失: BCE loss
        loss_diffusion = F.binary_cross_entropy_with_logits(
            adj_pred_logits, adj_gt,
            reduction='mean'
        )
        
        return {
            'loss_diffusion': loss_diffusion * self.loss_weight,
            'adj_pred_logits': adj_pred_logits
        }
    
    @torch.no_grad()
    def refine(self,
               adj_init: torch.Tensor,
               node_features: torch.Tensor,
               bev_features: torch.Tensor) -> torch.Tensor:
        """
        推理时的迭代精炼
        
        Args:
            adj_init: CGNet预测的初始邻接矩阵 [B, N, N]
            node_features: 节点特征 [B, N, D]
            bev_features: BEV特征 [B, H*W, D] 或 [B, D]
            
        Returns:
            adj_refined: 精炼后的邻接矩阵 [B, N, N]
        """
        # 1. 编码BEV条件
        if bev_features.dim() == 3:
            bev_cond = self.bev_encoder(bev_features.permute(0, 2, 1))
        else:
            bev_cond = bev_features
            
        # 2. 从CGNet预测开始迭代精炼
        adj_t = adj_init.clone()
        
        for step in range(self.num_refine_steps):
            # 当前噪声水平 (从高到低)
            noise_level = self.noise_levels[self.num_refine_steps - 1 - step]
            # 标量 -> [1, 1] -> [B, 1]
            noise_level = noise_level.reshape(1, 1).expand(adj_t.shape[0], -1)
            
            # 预测去噪后的邻接矩阵
            adj_pred_logits = self.denoiser(
                adj_t,
                node_features,
                bev_cond,
                noise_level
            )
            
            # 转换为概率
            adj_pred = torch.sigmoid(adj_pred_logits)
            
            # 更新: 逐步从noisy向clean过渡
            # 使用DDPM风格的更新: x_{t-1} = (1/sqrt(alpha_t)) * (x_t - (1-alpha_t)/sqrt(1-alpha_bar_t) * eps)
            # 这里简化为: 直接使用预测值的加权平均
            if step < self.num_refine_steps - 1:
                # 中间步骤: 保留一些随机性
                mix_ratio = (step + 1) / self.num_refine_steps
                adj_t = mix_ratio * adj_pred + (1 - mix_ratio) * adj_t
            else:
                # 最后一步: 直接使用预测值
                adj_t = adj_pred
                
        return adj_t


class TopologyDiffusionHead(BaseModule):
    """
    包装器类，可以直接作为nn.Module使用
    用于在CGTopoHead中集成Diffusion精炼
    """
    
    def __init__(self,
                 hidden_dim: int = 256,
                 num_layers: int = 4,
                 num_heads: int = 8,
                 num_refine_steps: int = 5,
                 loss_weight: float = 1.0,
                 init_cfg: dict = None):
        super().__init__(init_cfg=init_cfg)
        
        self.refiner = TopologyDiffusionRefiner(
            hidden_dim=hidden_dim,
            num_layers=num_layers,
            num_heads=num_heads,
            num_refine_steps=num_refine_steps,
            loss_weight=loss_weight,
            init_cfg=init_cfg
        )
        
    def forward(self,
                adj_gt: torch.Tensor,
                adj_pred: torch.Tensor,
                node_features: torch.Tensor,
                bev_features: torch.Tensor) -> Dict[str, torch.Tensor]:
        """训练前向"""
        return self.refiner(adj_gt, adj_pred, node_features, bev_features)
    
    def refine(self,
               adj_init: torch.Tensor,
               node_features: torch.Tensor,
               bev_features: torch.Tensor) -> torch.Tensor:
        """推理精炼"""
        return self.refiner.refine(adj_init, node_features, bev_features)
