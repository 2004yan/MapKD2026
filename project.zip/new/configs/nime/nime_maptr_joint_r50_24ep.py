"""
NIME-MapTR 联合训练配置（推荐）
==============================

联合训练特点：
1. NIME 增强器不冻结，检测 loss 指导增强器学习
2. 训练时随机退化图像（含真实夜间效果）
3. 增强器学习"对检测有帮助的增强"
"""

_base_ = [
    '../maptr/maptr_tiny_r50_24e.py',  # 继承 MapTR 基础配置
]

# 插件
plugin = True
plugin_dir = 'projects/mmdet3d_plugin/'

# ============================================================
# 模型配置
# ============================================================

model = dict(
    type='NIMEMapTR_Joint',
    # NIME 增强器配置
    use_nime=True,
    nime_pretrained=None,  # 可选：加载预训练权重作为初始化
    # nime_pretrained='./work_dirs/nime_pretrain/latest.pth',
    nime_n_orientations=8,
    nime_n_scales=4,
    nime_integration_radius=15,
    nime_n_channels=32,
    # 退化参数
    degrade_prob=0.5,              # 训练时 50% 概率退化
    enable_real_night_effects=True, # 启用真实夜间效果
    headlight_prob=0.0,            # 关闭车灯
    streetlight_prob=0.6,          # 只开路灯
    neon_prob=0.0,                 # 关闭霓虹灯
    lens_flare_prob=0.0,           # 关闭眩光
)

# ============================================================
# 训练配置
# ============================================================

optimizer = dict(
    type='AdamW',
    lr=3e-4,
    paramwise_cfg=dict(
        custom_keys={
            'img_backbone': dict(lr_mult=0.1),
            'nime_enhancer': dict(lr_mult=0.5),  # NIME 学习率稍低
        }
    ),
    weight_decay=0.01,
)

total_epochs = 24
evaluation = dict(interval=24)
runner = dict(type='EpochBasedRunner', max_epochs=total_epochs)

work_dir = './work_dirs/nime_maptr_joint_r50_24ep'
load_from = None

# FP16
fp16 = dict(loss_scale=512.)
