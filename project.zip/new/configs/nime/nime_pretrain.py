"""
NIME 预训练配置 (监督学习版本)
==============================

第一阶段：监督预训练 NIME 增强器
- 使用白天图像作为 GT
- 人工合成夜间/低光照图像作为输入
- 训练网络从退化图像恢复白天图像

训练流程：
1. 白天图像 (GT) → [人工退化] → 夜间图像 (Input)
2. NIME(夜间图像) → 增强图像 (Output)
3. Loss = |Output - GT| + SSIM + 梯度损失 + 地图先验损失
"""

_base_ = [
    '../datasets/custom_nus-3d.py',
    '../_base_/default_runtime.py'
]

# 插件
plugin = True
plugin_dir = 'projects/mmdet3d_plugin/'

# 数据集配置
dataset_type = 'CustomNuScenesLocalMapDataset'
data_root = 'data/nuscenes/'

# Point Cloud Range
point_cloud_range = [-15.0, -30.0, -2.0, 15.0, 30.0, 2.0]

# 图像归一化配置
img_norm_cfg = dict(
    mean=[123.675, 116.28, 103.53], 
    std=[58.395, 57.12, 57.375], 
    to_rgb=True
)

# 类别定义
class_names = [
    'car', 'truck', 'construction_vehicle', 'bus', 'trailer', 'barrier',
    'motorcycle', 'bicycle', 'pedestrian', 'traffic_cone'
]
map_classes = ['divider', 'ped_crossing', 'boundary']
fixed_ptsnum_per_line = 20
eval_use_same_gt_sample_num_flag = True

input_modality = dict(
    use_lidar=False,
    use_camera=True,
    use_radar=False,
    use_map=False,
    use_external=True)

bev_h_ = 200
bev_w_ = 100
queue_length = 1

# ============================================================
# Pipeline 配置（预训练只需要图像）
# ============================================================

train_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=True),
    dict(type='NormalizeMultiviewImage', **img_norm_cfg),
    dict(type='PadMultiViewImage', size_divisor=32),
    dict(type='DefaultFormatBundle3D', class_names=class_names, with_label=False),
    dict(type='CustomCollect3D', keys=['img'])
]

val_pipeline = train_pipeline

# ============================================================
# 数据配置
# ============================================================

data = dict(
    samples_per_gpu=4,
    workers_per_gpu=4,
    train=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file=data_root + 'nuscenes_infos_temporal_train.pkl',
        pipeline=train_pipeline,
        classes=class_names,
        modality=input_modality,
        test_mode=False,
        use_valid_flag=True,
        bev_size=(bev_h_, bev_w_),
        pc_range=point_cloud_range,
        fixed_ptsnum_per_line=fixed_ptsnum_per_line,
        eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
        padding_value=-10000,
        map_classes=map_classes,
        queue_length=queue_length,
        box_type_3d='LiDAR'),
    val=dict(type=dataset_type,
             data_root=data_root,
             ann_file=data_root + 'nuscenes_infos_temporal_val.pkl',
             map_ann_file=data_root + 'nuscenes_map_anns_val.json',
             pipeline=val_pipeline, bev_size=(bev_h_, bev_w_),
             pc_range=point_cloud_range,
             fixed_ptsnum_per_line=fixed_ptsnum_per_line,
             eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
             padding_value=-10000,
             map_classes=map_classes,
             classes=class_names, modality=input_modality, samples_per_gpu=1),
    test=dict(type=dataset_type,
              data_root=data_root,
              ann_file=data_root + 'nuscenes_infos_temporal_val.pkl',
              map_ann_file=data_root + 'nuscenes_map_anns_val.json',
              pipeline=val_pipeline, bev_size=(bev_h_, bev_w_),
              pc_range=point_cloud_range,
              fixed_ptsnum_per_line=fixed_ptsnum_per_line,
              eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
              padding_value=-10000,
              map_classes=map_classes,
              classes=class_names, modality=input_modality),
    shuffler_sampler=dict(type='DistributedGroupSampler'),
    nonshuffler_sampler=dict(type='DistributedSampler')
)

# ============================================================
# 模型配置
# ============================================================

model = dict(
    type='NIMEPretrainer',
    # Gabor 滤波器参数
    n_orientations=8,          # 8 个方向（车道线各方向）
    n_scales=4,                # 4 个尺度（不同粗细的线）
    # 轮廓整合参数
    integration_radius=15,     # Association Field 半径
    # 增强网络参数
    n_channels=32,             # 特征通道数
    # 监督学习 Loss 权重
    reconstruction_weight=1.0, # L1 重建损失
    ssim_weight=0.5,           # SSIM 结构相似性损失
    gradient_weight=0.2,       # 梯度/边缘保持损失
    map_prior_weight=0.3,      # 地图区域额外约束
    # 退化参数（LightDiff 风格）
    darkness_range=(0.01, 1.0),
    # 真实夜间效果（只保留路灯）
    enable_real_night_effects=True,
    headlight_prob=0.0,
    streetlight_prob=0.6,
    neon_prob=0.0,
    lens_flare_prob=0.0,
)

# ============================================================
# 训练配置
# ============================================================

optimizer = dict(
    type='AdamW',
    lr=2e-4,
    weight_decay=0.01,
)

optimizer_config = dict(
    grad_clip=dict(max_norm=35, norm_type=2)
)

lr_config = dict(
    policy='CosineAnnealing',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=1.0 / 3,
    min_lr_ratio=1e-3,
)

total_epochs = 12
evaluation = dict(interval=total_epochs, pipeline=val_pipeline)

runner = dict(type='EpochBasedRunner', max_epochs=total_epochs)

checkpoint_config = dict(interval=2)
log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook'),
        dict(type='TensorboardLoggerHook')
    ]
)

dist_params = dict(backend='nccl')
log_level = 'INFO'
work_dir = './work_dirs/nime_pretrain'
load_from = None
resume_from = None
workflow = [('train', 1)]

fp16 = dict(loss_scale=512.)
