"""
NIME-MapTR 微调配置
===================

第二阶段：加载预训练的 NIME 增强器，微调 MapTR 检测头
"""

_base_ = [
    '../maptr/maptr_tiny_r50_24e.py',  # 继承 MapTR 基础配置
]

# 插件
plugin = True
plugin_dir = 'projects/mmdet3d_plugin/'

# ============================================================
# 模型配置 - 覆盖基础配置
# ============================================================

# 预训练权重路径（需要先运行预训练）
nime_pretrained = './work_dirs/nime_pretrain/latest.pth'

model = dict(
    type='NIMEMapTR',
    # NIME 增强器配置
    use_nime=True,
    nime_pretrained=nime_pretrained,
    nime_freeze=True,           # 冻结增强器
    nime_n_orientations=8,
    nime_n_scales=4,
    nime_integration_radius=15,
    nime_n_channels=32,
)

# ============================================================
# 训练配置
# ============================================================

# 使用较小的学习率进行微调
optimizer = dict(
    type='AdamW',
    lr=3e-4,  # 微调学习率
    paramwise_cfg=dict(
        custom_keys={
            'img_backbone': dict(lr_mult=0.1),
        }
    ),
    weight_decay=0.01,
)

total_epochs = 24
evaluation = dict(interval=24)
runner = dict(type='EpochBasedRunner', max_epochs=total_epochs)

work_dir = './work_dirs/nime_maptr_tiny_r50_24ep'
load_from = None  # 不从 MapTR 预训练加载，从头训练（NIME 预训练已加载）

# 如果要从 MapTR 预训练开始微调，取消下面的注释
# load_from = './ckpts/maptr_tiny_r50_24e.pth'
