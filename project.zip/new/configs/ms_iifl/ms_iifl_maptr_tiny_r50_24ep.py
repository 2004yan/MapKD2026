"""
MS-IIFL MapTR Configuration
Map-Structure-Guided Illumination-Invariant Feature Learning

ECCV 级别创新框架配置文件

创新点：
1. 多模态光照扰动：夜间、雨天、雾霾等多种退化
2. 地图元素特质对齐：梯度方向 + 频域一致性
3. BEV 拓扑蒸馏：借鉴 SafeMap 的特征蒸馏
"""

_base_ = [
    '../maptr/maptr_tiny_r50_24e.py'  # 继承基础配置
]

# ========== MS-IIFL 配置 ==========
# 多模态光照扰动生成器 - 调整为较温和的退化
perturbation_cfg = dict(
    degradation_type='multi_modal',
    enable_night=True,
    enable_rain=False,              # 先关闭雨天，简化训练
    enable_fog=False,               # 先关闭雾霾，简化训练
    enable_overexpose=False,
    enable_local_light=True,
    night_darkness_range=(0.2, 0.5),  # 调整为更温和的暗度
    night_gamma_range=(1.5, 2.5),     # 降低 gamma 范围
    night_noise_range=(0.01, 0.03),   # 降低噪声
    rain_intensity_range=(0.1, 0.3),
    fog_density_range=(0.1, 0.3),
    mode_probs=dict(
        night=0.8,                    # 主要使用夜间退化
        rain=0.0,
        fog=0.0,
        overexpose=0.0,
        combined=0.2
    )
)

# MS-IIFL 损失配置 - 调整为更保守的权重
ms_iifl_loss_cfg = dict(
    use_trait_alignment=True,
    use_bev_distillation=False,     # 暂时关闭 BEV 蒸馏，简化训练
    use_map_reconstruction=False,
    trait_alignment_cfg=dict(
        direction_weight=0.5,       # 降低梯度方向一致性权重
        frequency_weight=0.2,       # 降低频域一致性权重
        edge_threshold=0.1,
        high_freq_ratio=0.5
    ),
    bev_distillation_cfg=dict(
        distill_weight=0.5,
        topo_weight=0.3,
        downsample_factor=8,
        num_samples=512,
        use_cosine_distill=True
    ),
    total_weight=1.0                # 这里乘以 model.ms_iifl_loss_weight=0.1
)

# 重建模块配置（可选）
reconstruction_cfg = dict(
    embed_dim=256,
    num_queries=100,
    use_reconstructor=True,
    use_adapter=True
)

# ========== 修改 model 配置 ==========
model = dict(
    type='MSIIFLMapTR',
    # MS-IIFL 专属参数
    use_ms_iifl_training=True,
    perturbation_cfg=perturbation_cfg,
    ms_iifl_loss_cfg=ms_iifl_loss_cfg,
    use_reconstruction=False,       # 是否使用重建模块
    reconstruction_cfg=reconstruction_cfg,
    # 特征对齐层级
    align_pv_feat=True,             # PV 特征层对齐
    align_bev_feat=False,           # 关闭 BEV 对齐，先只用 PV 对齐
    # 总权重 - 重要！不能太大，否则会干扰主任务
    ms_iifl_loss_weight=0.1         # 降低到 0.1
)

# ========== 消融实验开关 ==========
# 可以通过修改以下配置进行消融实验：

# 1. 只使用梯度方向一致性
# ms_iifl_loss_cfg = dict(
#     use_trait_alignment=True,
#     use_bev_distillation=False,
#     trait_alignment_cfg=dict(
#         direction_weight=1.0,
#         frequency_weight=0.0,  # 关闭频域
#     )
# )

# 2. 只使用 BEV 蒸馏
# ms_iifl_loss_cfg = dict(
#     use_trait_alignment=False,
#     use_bev_distillation=True,
# )

# 3. 只使用夜间退化
# perturbation_cfg = dict(
#     degradation_type='multi_modal',
#     enable_night=True,
#     enable_rain=False,
#     enable_fog=False,
# )

# ========== 训练参数 ==========
# 可以根据需要调整
runner = dict(type='EpochBasedRunner', max_epochs=24)

# 学习率调度
lr_config = dict(
    policy='CosineAnnealing',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=1.0 / 3,
    min_lr_ratio=1e-3
)

# 优化器
optimizer = dict(
    type='AdamW',
    lr=6e-4,
    weight_decay=0.01
)

# 日志配置
log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook'),
        dict(type='TensorboardLoggerHook')
    ]
)
