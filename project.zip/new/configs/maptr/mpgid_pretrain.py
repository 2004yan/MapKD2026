"""
MPGID Stage 1: 预训练配置

使用 Map Prior 自监督预训练 IID 网络

============================================================================
ECCV 级别创新模块开关（消融实验）:
- use_multi_view_consistency: 多视角光度一致性
- use_bev_light_field: BEV 空间光照场
- use_temporal_consistency: 时序一致性

通过修改下面的开关可以方便地进行消融实验:
- Baseline: 全部关闭
- +MV: use_multi_view_consistency=True
- +BEV: use_bev_light_field=True
- +MV+BEV: 两者都开启
- Full: 全部开启
============================================================================
"""

_base_ = [
    '../datasets/custom_nus-3d.py',
    '../_base_/default_runtime.py'
]

plugin = True
plugin_dir = 'projects/mmdet3d_plugin/'

# 图像归一化配置
img_norm_cfg = dict(
    mean=[123.675, 116.28, 103.53], 
    std=[58.395, 57.12, 57.375], 
    to_rgb=True
)

# 类别配置（预训练不需要，但保持兼容）
class_names = [
    'car', 'truck', 'construction_vehicle', 'bus', 'trailer', 'barrier',
    'motorcycle', 'bicycle', 'pedestrian', 'traffic_cone'
]
map_classes = ['divider', 'ped_crossing', 'boundary']

point_cloud_range = [-15.0, -30.0, -2.0, 15.0, 30.0, 2.0]

input_modality = dict(
    use_lidar=False,
    use_camera=True,
    use_radar=False,
    use_map=False,
    use_external=True
)

# ============================================================================
# ECCV 创新模块开关 - 消融实验控制
# ============================================================================
# 修改这里来控制使用哪些模块
USE_MULTI_VIEW_CONSISTENCY = True   # 多视角光度一致性 [ECCV 创新 1]
USE_BEV_LIGHT_FIELD = True          # BEV 空间光照场 [ECCV 创新 2]
USE_TEMPORAL_CONSISTENCY = False     # 时序一致性 [可选扩展]

# ====================
# MPGID 预训练模型配置
# ====================
model = dict(
    type='MPGIDMapTR_Pretrain',
    
    # IID 网络配置
    iid_cfg=dict(
        type='IIDNetworkLite',
        in_channels=3,
        base_channels=32,
    ),
    
    # Map Prior 估计器配置
    map_prior_cfg=dict(
        type='FastMapPriorEstimator',
    ),
    
    # 预训练损失配置（提高权重，让 loss 更有影响力）
    pretrain_loss_cfg=dict(
        type='IIDPretrainLoss',
        recon_weight=10.0,            # 重建损失 (1.0 → 10.0)
        shading_smooth_weight=1.0,    # Shading 平滑 (0.1 → 1.0)
        map_structure_weight=5.0,     # Map 结构保持 - 核心！(0.5 → 5.0)
        albedo_sparse_weight=1.0,     # Albedo 稀疏 (0.1 → 1.0)
        illumination_lowfreq_weight=0.5,  # 光照低频 (0.05 → 0.5)
        albedo_color_weight=2.0,      # Albedo 颜色先验 (0.1 → 2.0)
    ),
    
    img_norm_cfg=img_norm_cfg,
    
    # ============ ECCV 创新模块开关 ============
    use_multi_view_consistency=USE_MULTI_VIEW_CONSISTENCY,
    use_bev_light_field=USE_BEV_LIGHT_FIELD,
    use_temporal_consistency=USE_TEMPORAL_CONSISTENCY,
    
    # 多视角一致性配置
    multi_view_cfg=dict(
        loss_weight=1.0,        # 损失权重
        overlap_threshold=0.1,  # 重叠区域阈值
        use_ssim=True,          # 是否使用 SSIM
        ssim_weight=0.85,       # SSIM 权重
    ),
    
    # BEV 光照场配置
    bev_light_field_cfg=dict(
        loss_weight=1.0,        # 损失权重
        bev_h=100,              # BEV 高度
        bev_w=100,              # BEV 宽度
        bev_range=[-50, 50, -25, 25],  # BEV 范围 [x_min, x_max, y_min, y_max]
        smoothness_weight=0.5,  # 平滑性权重
        consistency_weight=0.5, # 一致性权重
    ),
    
    # 时序一致性配置
    temporal_cfg=dict(
        loss_weight=0.5,        # 损失权重
    ),
)

# ====================
# 数据配置
# ====================
dataset_type = 'CustomNuScenesLocalMapDataset'
data_root = 'data/nuscenes/'

# 预训练数据增强（简化版，不需要 GT）
train_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=True),
    dict(type='PhotoMetricDistortionMultiViewImage'),  # 光照增强
    dict(type='NormalizeMultiviewImage', **img_norm_cfg),
    dict(type='RandomScaleImageMultiViewImage', scales=[0.5]),
    dict(type='PadMultiViewImage', size_divisor=32),
    dict(type='DefaultFormatBundle3D', class_names=class_names),
    dict(type='CustomCollect3D', keys=['img'])  # 只需要图像
]

test_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=True),
    dict(type='NormalizeMultiviewImage', **img_norm_cfg),
    dict(
        type='MultiScaleFlipAug3D',
        img_scale=(1600, 900),
        pts_scale_ratio=1,
        flip=False,
        transforms=[
            dict(type='RandomScaleImageMultiViewImage', scales=[0.5]),
            dict(type='PadMultiViewImage', size_divisor=32),
            dict(type='DefaultFormatBundle3D', class_names=class_names, with_label=False),
            dict(type='CustomCollect3D', keys=['img'])
        ])
]

bev_h_ = 200
bev_w_ = 100
fixed_ptsnum_per_gt_line = 20
eval_use_same_gt_sample_num_flag = True

data = dict(
    samples_per_gpu=2,  # 减小 batch size 以适应 GPU 内存
    workers_per_gpu=4,
    train=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file=data_root + 'nuscenes_infos_temporal_train.pkl',
        pipeline=train_pipeline,
        classes=class_names,
        modality=input_modality,
        test_mode=False,
        use_valid_flag=True,
        bev_size=(bev_h_, bev_w_),
        pc_range=point_cloud_range,
        fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
        eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
        padding_value=-10000,
        map_classes=map_classes,
        queue_length=1,
        box_type_3d='LiDAR'),
    val=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file=data_root + 'nuscenes_infos_temporal_val.pkl',
        map_ann_file=data_root + 'nuscenes_map_anns_val.json',
        pipeline=test_pipeline,
        bev_size=(bev_h_, bev_w_),
        pc_range=point_cloud_range,
        fixed_ptsnum_per_line=fixed_ptsnum_per_gt_line,
        eval_use_same_gt_sample_num_flag=eval_use_same_gt_sample_num_flag,
        padding_value=-10000,
        map_classes=map_classes,
        classes=class_names,
        modality=input_modality,
        samples_per_gpu=1),
    shuffler_sampler=dict(type='DistributedGroupSampler'),
    nonshuffler_sampler=dict(type='DistributedSampler')
)

# ====================
# 优化器配置
# ====================
optimizer = dict(
    type='AdamW',
    lr=1e-3,  # 预训练可以用较大学习率
    weight_decay=0.01
)

optimizer_config = dict(grad_clip=dict(max_norm=35, norm_type=2))

# 学习率策略
lr_config = dict(
    policy='CosineAnnealing',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=1.0 / 3,
    min_lr_ratio=1e-3
)

# 预训练 epochs（相对较少）
total_epochs = 12

runner = dict(type='EpochBasedRunner', max_epochs=total_epochs)

log_config = dict(
    interval=50,
    hooks=[
        dict(type='TextLoggerHook'),
        dict(type='TensorboardLoggerHook')
    ]
)

checkpoint_config = dict(interval=2)

# 工作目录
work_dir = 'work_dirs/mpgid_pretrain'
