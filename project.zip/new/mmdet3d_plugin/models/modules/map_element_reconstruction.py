"""
Map Element Reconstruction Module
地图元素重建模块

借鉴 SafeMap 的 G-PVR (Gaussian-based Perspective View Reconstruction)

核心思想：
- SafeMap 通过遮挡视角并重建来学习鲁棒特征
- 我们将光照退化视为一种"不完整观测"
- 通过重建地图元素区域的特征来学习光照不变性

创新点：
1. 不重建整个特征图，而是聚焦于地图元素区域
2. 使用可学习查询来聚合多视角信息
3. 高斯采样机制，关注最相关的区域
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple, Dict, List
import math


class GaussianReferenceSampling(nn.Module):
    """
    高斯参考点采样模块
    
    借鉴 SafeMap G-PVR 的高斯采样策略：
    - 以目标区域为中心的高斯分布采样
    - 邻近区域贡献更大
    """
    
    def __init__(self, num_points: int = 256, sigma: float = 0.3):
        super().__init__()
        self.num_points = num_points
        self.sigma = sigma
    
    def forward(self, center_x: float, center_y: float,
                H: int, W: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        生成高斯分布的参考点
        
        Args:
            center_x: 中心点 x 坐标（归一化 0-1）
            center_y: 中心点 y 坐标（归一化 0-1）
            H, W: 特征图尺寸
            device: 设备
        Returns:
            ref_x: [num_points] x 坐标
            ref_y: [num_points] y 坐标
        """
        # 高斯采样
        ref_x = torch.randn(self.num_points, device=device) * self.sigma + center_x
        ref_y = torch.randn(self.num_points, device=device) * self.sigma + center_y
        
        # 裁剪到 [0, 1]
        ref_x = ref_x.clamp(0, 1)
        ref_y = ref_y.clamp(0, 1)
        
        return ref_x, ref_y


class DeformableAttentionDecoder(nn.Module):
    """
    可变形注意力解码器
    
    用于从周围特征重建目标区域
    """
    
    def __init__(self, 
                 embed_dim: int = 256,
                 num_heads: int = 8,
                 num_points: int = 4):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.num_points = num_points
        
        self.sampling_offsets = nn.Linear(embed_dim, num_heads * num_points * 2)
        self.attention_weights = nn.Linear(embed_dim, num_heads * num_points)
        self.value_proj = nn.Linear(embed_dim, embed_dim)
        self.output_proj = nn.Linear(embed_dim, embed_dim)
        
        self._reset_parameters()
    
    def _reset_parameters(self):
        nn.init.constant_(self.sampling_offsets.weight.data, 0.)
        nn.init.constant_(self.sampling_offsets.bias.data, 0.)
        nn.init.constant_(self.attention_weights.weight.data, 0.)
        nn.init.constant_(self.attention_weights.bias.data, 0.)
        nn.init.xavier_uniform_(self.value_proj.weight.data)
        nn.init.constant_(self.value_proj.bias.data, 0.)
        nn.init.xavier_uniform_(self.output_proj.weight.data)
        nn.init.constant_(self.output_proj.bias.data, 0.)
    
    def forward(self, query: torch.Tensor,
                reference_points: torch.Tensor,
                value: torch.Tensor) -> torch.Tensor:
        """
        Args:
            query: [B, N, C] 查询向量
            reference_points: [B, N, 2] 参考点（归一化坐标）
            value: [B, H, W, C] 值特征
        Returns:
            output: [B, N, C] 解码后的特征
        """
        B, N, C = query.shape
        _, H, W, _ = value.shape
        
        # 计算采样偏移
        sampling_offsets = self.sampling_offsets(query)
        sampling_offsets = sampling_offsets.view(B, N, self.num_heads, self.num_points, 2)
        
        # 计算注意力权重
        attention_weights = self.attention_weights(query)
        attention_weights = attention_weights.view(B, N, self.num_heads, self.num_points)
        attention_weights = F.softmax(attention_weights, dim=-1)
        
        # 计算采样点
        reference_points = reference_points.view(B, N, 1, 1, 2)
        sampling_locations = reference_points + sampling_offsets / torch.tensor([W, H], device=query.device)
        sampling_locations = sampling_locations.clamp(0, 1)
        
        # 值投影
        value_proj = self.value_proj(value)  # [B, H, W, C]
        value_proj = value_proj.permute(0, 3, 1, 2)  # [B, C, H, W]
        
        # 采样
        # 将采样位置转换为 grid_sample 格式 [-1, 1]
        sampling_locations_grid = sampling_locations * 2 - 1  # [B, N, heads, points, 2]
        
        # 对每个 head 和 point 进行采样
        outputs = []
        for head in range(self.num_heads):
            for point in range(self.num_points):
                grid = sampling_locations_grid[:, :, head, point, :].unsqueeze(2)  # [B, N, 1, 2]
                sampled = F.grid_sample(value_proj, grid, mode='bilinear', 
                                       padding_mode='zeros', align_corners=False)
                sampled = sampled.squeeze(-1).permute(0, 2, 1)  # [B, N, C]
                outputs.append(sampled * attention_weights[:, :, head, point:point+1])
        
        output = sum(outputs) / self.num_heads
        output = self.output_proj(output)
        
        return output


class MapElementReconstructor(nn.Module):
    """
    地图元素重建器
    
    核心模块：从退化特征重建原始地图元素特征
    
    借鉴 SafeMap 的策略：
    1. 使用可学习查询向量表示目标重建区域
    2. 通过可变形注意力从周围区域聚合信息
    3. 使用 Transformer 解码器重建特征
    """
    
    def __init__(self,
                 embed_dim: int = 256,
                 num_queries: int = 100,
                 num_decoder_layers: int = 2,
                 num_heads: int = 8,
                 ffn_dim: int = 1024,
                 dropout: float = 0.1):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_queries = num_queries
        
        # 可学习查询向量（表示要重建的地图元素区域）
        self.query_embed = nn.Embedding(num_queries, embed_dim)
        
        # 位置编码
        self.pos_encoding = nn.Parameter(torch.randn(1, num_queries, embed_dim) * 0.02)
        
        # Transformer 解码器层
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=ffn_dim,
            dropout=dropout,
            batch_first=True
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_decoder_layers)
        
        # 特征重建头
        self.recon_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embed_dim, embed_dim)
        )
        
        # 空间位置预测头（预测每个查询对应的空间位置）
        self.pos_head = nn.Linear(embed_dim, 2)  # 预测 (x, y) 坐标
    
    def forward(self, feat_degraded: torch.Tensor,
                feat_original: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        Args:
            feat_degraded: [B, C, H, W] 退化特征（如夜间）
            feat_original: [B, C, H, W] 原始特征（如白天），用于监督
        Returns:
            outputs: 包含重建特征和损失的字典
        """
        B, C, H, W = feat_degraded.shape
        
        # 将特征转换为序列 [B, H*W, C]
        feat_seq = feat_degraded.flatten(2).permute(0, 2, 1)
        
        # 添加位置编码
        pos_embed = self._get_pos_embed(H, W, feat_degraded.device)
        feat_seq = feat_seq + pos_embed
        
        # 查询向量
        query = self.query_embed.weight.unsqueeze(0).expand(B, -1, -1)
        query = query + self.pos_encoding
        
        # Transformer 解码
        decoded = self.decoder(query, feat_seq)  # [B, num_queries, C]
        
        # 特征重建
        recon_feat = self.recon_head(decoded)  # [B, num_queries, C]
        
        # 预测空间位置
        pred_pos = self.pos_head(decoded)  # [B, num_queries, 2]
        pred_pos = torch.sigmoid(pred_pos)  # 归一化到 [0, 1]
        
        outputs = {
            'recon_feat': recon_feat,
            'pred_pos': pred_pos
        }
        
        # 如果有原始特征，计算重建损失
        if feat_original is not None:
            loss = self._compute_reconstruction_loss(
                recon_feat, pred_pos, feat_original
            )
            outputs['loss_reconstruction'] = loss
        
        return outputs
    
    def _get_pos_embed(self, H: int, W: int, device: torch.device) -> torch.Tensor:
        """生成 2D 正弦位置编码"""
        y_embed = torch.arange(H, device=device).float()
        x_embed = torch.arange(W, device=device).float()
        
        y_embed = y_embed / H * 2 * math.pi
        x_embed = x_embed / W * 2 * math.pi
        
        dim_t = torch.arange(self.embed_dim // 4, device=device).float()
        dim_t = 10000 ** (2 * dim_t / (self.embed_dim // 4))
        
        pos_y = y_embed.view(H, 1, 1) / dim_t.view(1, 1, -1)
        pos_x = x_embed.view(1, W, 1) / dim_t.view(1, 1, -1)
        
        pos_y = torch.cat([pos_y.sin(), pos_y.cos()], dim=-1).view(H, 1, -1)
        pos_x = torch.cat([pos_x.sin(), pos_x.cos()], dim=-1).view(1, W, -1)
        
        pos_embed = pos_y + pos_x  # [H, W, C//2]
        pos_embed = pos_embed.view(H * W, -1).unsqueeze(0)  # [1, H*W, C//2]
        
        # 扩展到 embed_dim
        if pos_embed.shape[-1] < self.embed_dim:
            pos_embed = F.pad(pos_embed, (0, self.embed_dim - pos_embed.shape[-1]))
        
        return pos_embed
    
    def _compute_reconstruction_loss(self, 
                                      recon_feat: torch.Tensor,
                                      pred_pos: torch.Tensor,
                                      feat_original: torch.Tensor) -> torch.Tensor:
        """
        计算重建损失
        
        策略：在预测位置从原始特征采样，与重建特征比较
        """
        B, N, C = recon_feat.shape
        _, _, H, W = feat_original.shape
        
        # 从原始特征中采样目标
        # 将 pred_pos 转换为 grid_sample 格式
        grid = pred_pos * 2 - 1  # [B, N, 2] -> [-1, 1]
        grid = grid.unsqueeze(2)  # [B, N, 1, 2]
        
        # 采样
        target_feat = F.grid_sample(feat_original, grid, mode='bilinear',
                                   padding_mode='zeros', align_corners=False)
        target_feat = target_feat.squeeze(-1).permute(0, 2, 1)  # [B, N, C]
        
        # L1 损失
        loss = F.l1_loss(recon_feat, target_feat)
        
        return loss


class LightInvariantFeatureExtractor(nn.Module):
    """
    光照不变特征提取器
    
    结合重建和对齐的思想，学习光照不变的特征表示
    
    整体流程：
    1. 接收退化图像特征
    2. 通过重建模块恢复地图元素区域
    3. 输出光照不变的特征
    """
    
    def __init__(self,
                 embed_dim: int = 256,
                 num_queries: int = 100,
                 use_reconstructor: bool = True,
                 use_adapter: bool = True):
        super().__init__()
        self.embed_dim = embed_dim
        self.use_reconstructor = use_reconstructor
        self.use_adapter = use_adapter
        
        if use_reconstructor:
            self.reconstructor = MapElementReconstructor(
                embed_dim=embed_dim,
                num_queries=num_queries
            )
        
        if use_adapter:
            # 特征适配器：将重建特征融合回原始特征
            self.adapter = nn.Sequential(
                nn.Conv2d(embed_dim, embed_dim, 1),
                nn.BatchNorm2d(embed_dim),
                nn.ReLU(inplace=True),
                nn.Conv2d(embed_dim, embed_dim, 3, padding=1),
                nn.BatchNorm2d(embed_dim)
            )
    
    def forward(self, feat_degraded: torch.Tensor,
                feat_original: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        Args:
            feat_degraded: [B, C, H, W] 退化特征
            feat_original: [B, C, H, W] 原始特征（训练时使用）
        Returns:
            outputs: 包含增强特征和损失的字典
        """
        outputs = {}
        
        if self.use_reconstructor:
            recon_outputs = self.reconstructor(feat_degraded, feat_original)
            outputs.update(recon_outputs)
        
        # 特征适配
        if self.use_adapter:
            feat_adapted = self.adapter(feat_degraded) + feat_degraded
            outputs['feat_adapted'] = feat_adapted
        else:
            outputs['feat_adapted'] = feat_degraded
        
        return outputs
