"""
模型模块

包含：
1. MapElementReconstructor: 地图元素重建器（借鉴 SafeMap G-PVR）
2. LightInvariantFeatureExtractor: 光照不变特征提取器
"""

from .map_element_reconstruction import (
    GaussianReferenceSampling,
    DeformableAttentionDecoder,
    MapElementReconstructor,
    LightInvariantFeatureExtractor,
)

__all__ = [
    'GaussianReferenceSampling',
    'DeformableAttentionDecoder',
    'MapElementReconstructor',
    'LightInvariantFeatureExtractor',
]
