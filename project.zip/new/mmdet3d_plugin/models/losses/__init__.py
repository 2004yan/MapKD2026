"""
损失函数模块

包含：
1. MapStructureLoss: 基础结构保护损失
2. MapAwareLightAdaptationLoss: Map 元素感知的光照自适应损失
3. ElementSpecificEnhancementLoss: ECCV 核心创新 - Element-Specific Enhancement
4. IIDPretrainLoss: MPGID 预训练损失（核心创新）
5. MapAwareConsistencyLoss: Map 感知特征对齐损失（新核心创新）
"""

from .map_structure_loss import (
    MapStructureLoss,
    EdgeConsistencyLoss,
    SSIMLoss,
    PhaseConsistencyLoss,
    FrequencyStructureLoss
)

from .map_aware_loss import (
    MapElementCategoryLoss,
    MapGeometryPriorLoss,
    MapAwareLightAdaptationLoss,
    MapElementAttentionGenerator,
    GaborFilterBank
)

from .element_specific_loss import (
    ElementSpecificEnhancementLoss,
    DirectionalSobelFilter,
    GaborFilterBank as GaborFilterBankV2,
    LaplacianFilter
)

from .iid_pretrain_loss import (
    ReconstructionLoss,
    ShadingSmoothLoss,
    MapStructurePreserveLoss,
    AlbedoSparseLoss,
    IlluminationLowFreqLoss,
    MultiViewConsistencyLoss,
    AlbedoColorPriorLoss,
    AlbedoColorFidelityLoss,  # 新增：颜色保真度损失
    IIDPretrainLoss,
    LightPerturbationLoss,
    # 新增：ECCV 级别创新模块
    MultiViewPhotometricLoss,
    BEVLightFieldLoss,
    TemporalConsistencyLoss,
)

from .map_aware_consistency_loss import (
    GradientDirectionConsistencyLoss,
    FrequencyDomainConsistencyLoss,
    BEVGeometricConsistencyLoss,
    MapAwareConsistencyLoss,
)

# MS-IIFL: Map-Structure-Guided Illumination-Invariant Feature Learning (ECCV 级别创新)
from .ms_iifl_losses import (
    MapElementTraitAlignmentLoss,
    BEVTopologicalDistillationLoss,
    MapElementReconstructionLoss,
    MSIIFLLoss,
    MSIIFLTemporalConsistencyLoss,
)

__all__ = [
    # 基础结构损失
    'MapStructureLoss',
    'EdgeConsistencyLoss', 
    'SSIMLoss',
    'PhaseConsistencyLoss',
    'FrequencyStructureLoss',
    # Map 元素感知损失
    'MapElementCategoryLoss',
    'MapGeometryPriorLoss',
    'MapAwareLightAdaptationLoss',
    'MapElementAttentionGenerator',
    'GaborFilterBank',
    # ECCV 核心创新 - Element-Specific Enhancement
    'ElementSpecificEnhancementLoss',
    'DirectionalSobelFilter',
    'GaborFilterBankV2',
    'LaplacianFilter',
    # MPGID 预训练损失
    'ReconstructionLoss',
    'ShadingSmoothLoss',
    'MapStructurePreserveLoss',
    'AlbedoSparseLoss',
    'IlluminationLowFreqLoss',
    'MultiViewConsistencyLoss',
    'AlbedoColorPriorLoss',
    'AlbedoColorFidelityLoss',  # 新增：颜色保真度损失
    'IIDPretrainLoss',
    'LightPerturbationLoss',
    # 新增：ECCV 级别创新 - 多视角 & BEV 光照场
    'MultiViewPhotometricLoss',
    'BEVLightFieldLoss',
    'TemporalConsistencyLoss',
    # 新增：Map-Aware Feature Alignment（核心创新）
    'GradientDirectionConsistencyLoss',
    'FrequencyDomainConsistencyLoss',
    'BEVGeometricConsistencyLoss',
    'MapAwareConsistencyLoss',
    # MS-IIFL: Map-Structure-Guided Illumination-Invariant Feature Learning (ECCV 级别创新)
    'MapElementTraitAlignmentLoss',
    'BEVTopologicalDistillationLoss',
    'MapElementReconstructionLoss',
    'MSIIFLLoss',
    'MSIIFLTemporalConsistencyLoss',
]
