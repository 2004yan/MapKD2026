"""
Map-Structure-Aware Feature Alignment Loss

核心创新：利用地图元素的几何与频域特质，作为特征对齐的"锚点"

三大模块：
1. 梯度方向一致性 (Gradient Direction Consistency) - 针对车道线/边界
2. 频域一致性 (Frequency Domain Consistency) - 针对人行横道
3. BEV 几何一致性 (BEV Geometric Consistency) - 针对整体拓扑

文献支持：
- Gradient Direction: "Learning to See in the Dark" CVPR 2018 - 边缘方向对光照鲁棒
- Frequency Domain: "Fourier Domain Adaptation for Semantic Segmentation" CVPR 2020
- BEV Consistency: "BEVFormer" ECCV 2022 - BEV 空间的特征对齐
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from mmdet.models.builder import LOSSES


@LOSSES.register_module()
class GradientDirectionConsistencyLoss(nn.Module):
    """
    梯度方向一致性 Loss
    
    针对地图特质：车道线和边界是强边缘（Edge）
    
    关键洞察：
    - 光照变化会改变梯度的强度（Magnitude），但不会改变方向（Direction）
    - 车道线的走向是不变的，无论光照如何
    
    实现：
    - 计算特征图的 Sobel 梯度
    - 约束梯度的角度（Angle）一致，忽略模长差异
    
    意义：让模型学会 "不管多暗，只要有线，方向必须对"
    """
    
    def __init__(self, loss_weight=1.0, edge_threshold=0.1):
        super().__init__()
        self.loss_weight = loss_weight
        self.edge_threshold = edge_threshold
        
        # Sobel 算子
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        self.register_buffer('sobel_x', sobel_x.view(1, 1, 3, 3))
        self.register_buffer('sobel_y', sobel_y.view(1, 1, 3, 3))
    
    def forward(self, feat_day: torch.Tensor, feat_night: torch.Tensor) -> torch.Tensor:
        """
        Args:
            feat_day: [B, C, H, W] 白天特征
            feat_night: [B, C, H, W] 夜间（合成）特征
        Returns:
            loss: 梯度方向一致性损失
        """
        B, C, H, W = feat_day.shape
        
        # 转为灰度（或取通道均值）
        if C > 1:
            feat_day_gray = feat_day.mean(dim=1, keepdim=True)
            feat_night_gray = feat_night.mean(dim=1, keepdim=True)
        else:
            feat_day_gray = feat_day
            feat_night_gray = feat_night
        
        # 计算梯度
        grad_x_day = F.conv2d(feat_day_gray, self.sobel_x, padding=1)
        grad_y_day = F.conv2d(feat_day_gray, self.sobel_y, padding=1)
        
        grad_x_night = F.conv2d(feat_night_gray, self.sobel_x, padding=1)
        grad_y_night = F.conv2d(feat_night_gray, self.sobel_y, padding=1)
        
        # 计算梯度模长
        mag_day = torch.sqrt(grad_x_day ** 2 + grad_y_day ** 2 + 1e-8)
        mag_night = torch.sqrt(grad_x_night ** 2 + grad_y_night ** 2 + 1e-8)
        
        # 只在有明显边缘的区域计算方向一致性
        edge_mask = (mag_day > self.edge_threshold).float()
        
        # 计算单位方向向量
        dir_x_day = grad_x_day / mag_day
        dir_y_day = grad_y_day / mag_day
        
        dir_x_night = grad_x_night / mag_night
        dir_y_night = grad_y_night / mag_night
        
        # 方向一致性：用点积衡量（cos(theta)）
        # 完全一致时 cos=1，垂直时 cos=0
        cos_similarity = dir_x_day * dir_x_night + dir_y_day * dir_y_night
        
        # Loss: 1 - cos（方向越一致，loss 越小）
        # 使用绝对值，因为方向可能相反（180度）但仍然是同一条线
        direction_loss = 1 - torch.abs(cos_similarity)
        
        # 只在边缘区域计算 loss
        loss = (direction_loss * edge_mask).sum() / (edge_mask.sum() + 1e-8)
        
        return loss * self.loss_weight


@LOSSES.register_module()
class FrequencyDomainConsistencyLoss(nn.Module):
    """
    频域一致性 Loss
    
    针对地图特质：人行横道是周期性纹理，在频域表现为特定高频分量
    
    关键洞察：
    - 夜间/低光照相当于低通滤波器，抹平高频细节
    - 斑马线的周期性结构在频域有明确的高频峰
    
    实现：
    - 用 FFT 将特征转到频域
    - 强制夜间特征的高频分量逼近白天
    
    意义：强迫网络在夜间"脑补"出丢失的高频周期性纹理
    """
    
    def __init__(self, loss_weight=1.0, high_freq_ratio=0.5):
        super().__init__()
        self.loss_weight = loss_weight
        self.high_freq_ratio = high_freq_ratio  # 高频区域比例
    
    def forward(self, feat_day: torch.Tensor, feat_night: torch.Tensor) -> torch.Tensor:
        """
        Args:
            feat_day: [B, C, H, W] 白天特征
            feat_night: [B, C, H, W] 夜间（合成）特征
        Returns:
            loss: 频域一致性损失
        """
        B, C, H, W = feat_day.shape
        
        # FFT 变换
        fft_day = torch.fft.fft2(feat_day, norm='ortho')
        fft_night = torch.fft.fft2(feat_night, norm='ortho')
        
        # 计算幅度谱
        amp_day = torch.abs(fft_day)
        amp_night = torch.abs(fft_night)
        
        # 创建高频掩码（中心是低频，四周是高频）
        # 将频谱移到中心
        amp_day_shift = torch.fft.fftshift(amp_day, dim=(-2, -1))
        amp_night_shift = torch.fft.fftshift(amp_night, dim=(-2, -1))
        
        # 高频掩码：距离中心超过一定比例的区域
        center_h, center_w = H // 2, W // 2
        radius_h = int(H * self.high_freq_ratio / 2)
        radius_w = int(W * self.high_freq_ratio / 2)
        
        # 创建低频区域掩码
        y_coords = torch.arange(H, device=feat_day.device).view(1, 1, H, 1).expand(B, C, H, W)
        x_coords = torch.arange(W, device=feat_day.device).view(1, 1, 1, W).expand(B, C, H, W)
        
        dist_y = torch.abs(y_coords - center_h)
        dist_x = torch.abs(x_coords - center_w)
        
        # 高频区域：距离中心较远
        high_freq_mask = ((dist_y > radius_h) | (dist_x > radius_w)).float()
        
        # 高频一致性 Loss
        high_freq_diff = torch.abs(amp_day_shift - amp_night_shift) * high_freq_mask
        loss = high_freq_diff.mean()
        
        return loss * self.loss_weight


@LOSSES.register_module()
class BEVGeometricConsistencyLoss(nn.Module):
    """
    BEV 几何一致性 Loss
    
    针对地图特质：地图元素在 BEV 空间具有平行性和连续性
    
    关键洞察：
    - 夜间会导致车道线断裂或弯曲（噪声干扰）
    - 但地图的拓扑结构应该保持不变
    
    实现（内存优化版）：
    - 使用局部自相关而不是全局自相关
    - 或使用采样的方式计算相关性
    
    意义：如果位置 A 和 B 在白天是连通的（同一条线），夜间也必须连通
    """
    
    def __init__(self, loss_weight=1.0, downsample_factor=16, num_samples=256):
        super().__init__()
        self.loss_weight = loss_weight
        self.downsample_factor = downsample_factor  # 更大的下采样
        self.num_samples = num_samples  # 采样点数
    
    def forward(self, feat_day: torch.Tensor, feat_night: torch.Tensor) -> torch.Tensor:
        """
        Args:
            feat_day: [B, C, H, W] 白天特征（可以是 BEV 特征）
            feat_night: [B, C, H, W] 夜间（合成）特征
        Returns:
            loss: BEV 几何一致性损失
        """
        B, C, H, W = feat_day.shape
        
        # 大幅下采样以减少计算量
        feat_day = F.adaptive_avg_pool2d(feat_day, (H // self.downsample_factor, W // self.downsample_factor))
        feat_night = F.adaptive_avg_pool2d(feat_night, (H // self.downsample_factor, W // self.downsample_factor))
        
        B, C, H_small, W_small = feat_day.shape
        num_positions = H_small * W_small
        
        # 如果位置太多，随机采样
        if num_positions > self.num_samples:
            # 随机采样位置
            indices = torch.randperm(num_positions, device=feat_day.device)[:self.num_samples]
            
            feat_day_flat = feat_day.view(B, C, -1)[:, :, indices]  # [B, C, num_samples]
            feat_night_flat = feat_night.view(B, C, -1)[:, :, indices]
        else:
            feat_day_flat = feat_day.view(B, C, -1)
            feat_night_flat = feat_night.view(B, C, -1)
        
        # L2 归一化
        feat_day_norm = F.normalize(feat_day_flat, p=2, dim=1)
        feat_night_norm = F.normalize(feat_night_flat, p=2, dim=1)
        
        # 计算采样点的自相关矩阵：[B, num_samples, num_samples]
        corr_day = torch.bmm(feat_day_norm.transpose(1, 2), feat_day_norm)
        corr_night = torch.bmm(feat_night_norm.transpose(1, 2), feat_night_norm)
        
        # 一致性 Loss：两个相关矩阵应该相似
        loss = F.mse_loss(corr_day, corr_night)
        
        return loss * self.loss_weight


@LOSSES.register_module()
class MapAwareConsistencyLoss(nn.Module):
    """
    地图感知一致性 Loss（综合三个子 Loss）
    
    这是针对 HD Map 任务设计的跨光照一致性约束
    
    创新点：
    1. 不是通用的光照增强，而是针对地图元素特质设计
    2. 利用地图元素的几何（方向）、频域（周期性）、拓扑（连通性）特性
    3. 自监督：通过合成夜间数据，无需额外标注
    """
    
    def __init__(self,
                 direction_weight=1.0,
                 frequency_weight=0.5,
                 geometric_weight=0.5,
                 edge_threshold=0.1,
                 high_freq_ratio=0.5):
        super().__init__()
        
        self.direction_loss = GradientDirectionConsistencyLoss(
            loss_weight=direction_weight,
            edge_threshold=edge_threshold
        )
        
        self.frequency_loss = FrequencyDomainConsistencyLoss(
            loss_weight=frequency_weight,
            high_freq_ratio=high_freq_ratio
        )
        
        self.geometric_loss = BEVGeometricConsistencyLoss(
            loss_weight=geometric_weight
        )
    
    def forward(self, feat_day: torch.Tensor, feat_night: torch.Tensor) -> dict:
        """
        Args:
            feat_day: [B, C, H, W] 白天特征
            feat_night: [B, C, H, W] 夜间（合成）特征
        Returns:
            losses: 包含各子 loss 的字典
        """
        loss_dir = self.direction_loss(feat_day, feat_night)
        loss_freq = self.frequency_loss(feat_day, feat_night)
        loss_geo = self.geometric_loss(feat_day, feat_night)
        
        losses = {
            'loss_gradient_direction': loss_dir,
            'loss_frequency_domain': loss_freq,
            'loss_bev_geometric': loss_geo,
            'loss_map_consistency': loss_dir + loss_freq + loss_geo
        }
        
        return losses
