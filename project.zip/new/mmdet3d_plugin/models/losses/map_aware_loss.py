"""
Map 元素感知的光照自适应损失

核心创新点：
1. Map 元素类别感知约束：不同 Map 元素使用不同的增强策略
   - 车道线 (divider)：强调边缘/梯度约束（线性结构）
   - 人行横道 (ped_crossing)：强调纹理/周期性约束
   - 道路边界 (boundary)：强调几何形状约束

2. Map 几何先验约束：利用 Map 元素的固有几何特性
   - 车道线：平行性、曲率连续性
   - 人行横道：周期性条纹模式
   - 道路边界：平滑性、连续性

参考文献：
- CLRNet (CVPR 2022): 车道线几何约束
- VectorNet (CVPR 2020): 向量化地图表示
- PolyLaneNet: 多项式车道线约束
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class MapElementAttentionGenerator(nn.Module):
    """
    生成 Map 元素的注意力图
    
    根据检测 Query 的注意力权重，生成不同 Map 元素在图像上的关注区域
    """
    
    def __init__(self, num_classes=3, hidden_dim=256):
        super().__init__()
        self.num_classes = num_classes
        
        # 从检测特征预测空间注意力
        self.attention_predictor = nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim // 2, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim // 2, num_classes, 1),
            nn.Sigmoid()
        )
    
    def forward(self, bev_feat):
        """
        Args:
            bev_feat: BEV 特征 [B, C, H, W]
        
        Returns:
            attention_maps: 各类别的注意力图 [B, num_classes, H, W]
        """
        return self.attention_predictor(bev_feat)


class GaborFilterBank(nn.Module):
    """
    Gabor 滤波器组
    
    用于检测人行横道的周期性条纹纹理
    """
    
    def __init__(self, num_orientations=4, num_scales=2):
        super().__init__()
        self.num_orientations = num_orientations
        self.num_scales = num_scales
        
        # 创建 Gabor 滤波器
        filters = self._create_gabor_filters()
        self.register_buffer('filters', filters)
    
    def _create_gabor_filters(self, ksize=21):
        """创建多方向多尺度的 Gabor 滤波器"""
        filters = []
        
        for scale_idx in range(self.num_scales):
            sigma = 3.0 + scale_idx * 2.0
            lambd = 8.0 + scale_idx * 4.0
            
            for orient_idx in range(self.num_orientations):
                theta = orient_idx * math.pi / self.num_orientations
                
                # 创建 Gabor 核
                kernel = self._gabor_kernel(ksize, sigma, theta, lambd)
                filters.append(kernel)
        
        # [num_filters, 1, ksize, ksize]
        return torch.stack(filters, dim=0).unsqueeze(1)
    
    def _gabor_kernel(self, ksize, sigma, theta, lambd, gamma=0.5, psi=0):
        """生成单个 Gabor 核"""
        half = ksize // 2
        # PyTorch < 1.10 不支持 indexing 参数，默认行为已是 'ij'
        y, x = torch.meshgrid(
            torch.arange(-half, half + 1).float(),
            torch.arange(-half, half + 1).float()
        )
        
        # 旋转坐标
        x_theta = x * math.cos(theta) + y * math.sin(theta)
        y_theta = -x * math.sin(theta) + y * math.cos(theta)
        
        # Gabor 函数
        exp_part = torch.exp(-0.5 * (x_theta**2 + gamma**2 * y_theta**2) / sigma**2)
        cos_part = torch.cos(2 * math.pi * x_theta / lambd + psi)
        
        kernel = exp_part * cos_part
        return kernel
    
    def forward(self, x):
        """
        提取纹理特征
        
        Args:
            x: [B, C, H, W] 输入图像
        
        Returns:
            texture_response: [B, num_filters, H, W] 纹理响应
        """
        B, C, H, W = x.shape
        
        # 转为灰度图
        if C == 3:
            x_gray = 0.299 * x[:, 0:1] + 0.587 * x[:, 1:2] + 0.114 * x[:, 2:3]
        else:
            x_gray = x
        
        # 应用 Gabor 滤波器
        padding = self.filters.shape[-1] // 2
        response = F.conv2d(x_gray, self.filters, padding=padding)
        
        return response


class MapElementCategoryLoss(nn.Module):
    """
    Map 元素类别感知损失
    
    核心创新：不同 Map 元素使用不同的约束策略
    - 车道线：边缘/梯度约束
    - 人行横道：纹理/周期性约束
    - 道路边界：几何形状约束
    """
    
    def __init__(self,
                 num_classes=3,
                 lane_weight=1.0,
                 crossing_weight=1.0,
                 boundary_weight=1.0):
        super().__init__()
        
        self.num_classes = num_classes
        self.lane_weight = lane_weight
        self.crossing_weight = crossing_weight
        self.boundary_weight = boundary_weight
        
        # 车道线：边缘检测器
        self.sobel_x = nn.Conv2d(1, 1, 3, padding=1, bias=False)
        self.sobel_y = nn.Conv2d(1, 1, 3, padding=1, bias=False)
        self._init_sobel()
        
        # 人行横道：Gabor 纹理检测器
        self.gabor_bank = GaborFilterBank(num_orientations=4, num_scales=2)
        
        # 道路边界：形状检测器（使用 Laplacian）
        self.laplacian = nn.Conv2d(1, 1, 3, padding=1, bias=False)
        self._init_laplacian()
    
    def _init_sobel(self):
        """初始化 Sobel 算子"""
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32)
        
        self.sobel_x.weight.data = sobel_x.view(1, 1, 3, 3)
        self.sobel_y.weight.data = sobel_y.view(1, 1, 3, 3)
        self.sobel_x.weight.requires_grad = False
        self.sobel_y.weight.requires_grad = False
    
    def _init_laplacian(self):
        """初始化 Laplacian 算子"""
        laplacian = torch.tensor([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=torch.float32)
        self.laplacian.weight.data = laplacian.view(1, 1, 3, 3)
        self.laplacian.weight.requires_grad = False
    
    def compute_edge_feature(self, img):
        """计算边缘特征（用于车道线）"""
        # 转灰度
        if img.shape[1] == 3:
            gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        else:
            gray = img
        
        grad_x = self.sobel_x(gray)
        grad_y = self.sobel_y(gray)
        edge = torch.sqrt(grad_x**2 + grad_y**2 + 1e-8)
        
        return edge
    
    def compute_texture_feature(self, img):
        """计算纹理特征（用于人行横道）"""
        texture_response = self.gabor_bank(img)
        # 取最大响应
        texture_max, _ = texture_response.max(dim=1, keepdim=True)
        return texture_max
    
    def compute_shape_feature(self, img):
        """计算形状特征（用于道路边界）"""
        if img.shape[1] == 3:
            gray = 0.299 * img[:, 0:1] + 0.587 * img[:, 1:2] + 0.114 * img[:, 2:3]
        else:
            gray = img
        
        shape = torch.abs(self.laplacian(gray))
        return shape
    
    def forward(self, original, enhanced, class_attention_maps=None):
        """
        计算类别感知损失
        
        Args:
            original: [B, C, H, W] 原始图像 [0, 1]
            enhanced: [B, C, H, W] 增强后图像 [0, 1]
            class_attention_maps: [B, num_classes, H, W] 各类别的注意力图（可选）
        
        Returns:
            losses: dict
            total_loss: 总损失
        """
        losses = {}
        total_loss = 0
        
        # 1. 车道线损失：边缘一致性
        edge_orig = self.compute_edge_feature(original)
        edge_enh = self.compute_edge_feature(enhanced)
        
        if class_attention_maps is not None:
            # 使用类别注意力加权
            lane_mask = class_attention_maps[:, 0:1, :, :]  # divider
            lane_mask = F.interpolate(lane_mask, size=edge_orig.shape[-2:], mode='bilinear')
            lane_loss = F.l1_loss(edge_enh * lane_mask, edge_orig * lane_mask)
        else:
            lane_loss = F.l1_loss(edge_enh, edge_orig)
        
        losses['loss_lane_edge'] = lane_loss * self.lane_weight
        total_loss = total_loss + losses['loss_lane_edge']
        
        # 2. 人行横道损失：纹理一致性
        texture_orig = self.compute_texture_feature(original)
        texture_enh = self.compute_texture_feature(enhanced)
        
        if class_attention_maps is not None:
            crossing_mask = class_attention_maps[:, 1:2, :, :]  # ped_crossing
            crossing_mask = F.interpolate(crossing_mask, size=texture_orig.shape[-2:], mode='bilinear')
            crossing_loss = F.l1_loss(texture_enh * crossing_mask, texture_orig * crossing_mask)
        else:
            crossing_loss = F.l1_loss(texture_enh, texture_orig)
        
        losses['loss_crossing_texture'] = crossing_loss * self.crossing_weight
        total_loss = total_loss + losses['loss_crossing_texture']
        
        # 3. 道路边界损失：形状一致性
        shape_orig = self.compute_shape_feature(original)
        shape_enh = self.compute_shape_feature(enhanced)
        
        if class_attention_maps is not None:
            boundary_mask = class_attention_maps[:, 2:3, :, :]  # boundary
            boundary_mask = F.interpolate(boundary_mask, size=shape_orig.shape[-2:], mode='bilinear')
            boundary_loss = F.l1_loss(shape_enh * boundary_mask, shape_orig * boundary_mask)
        else:
            boundary_loss = F.l1_loss(shape_enh, shape_orig)
        
        losses['loss_boundary_shape'] = boundary_loss * self.boundary_weight
        total_loss = total_loss + losses['loss_boundary_shape']
        
        losses['loss_category_total'] = total_loss
        
        return losses, total_loss


class MapGeometryPriorLoss(nn.Module):
    """
    Map 几何先验约束损失
    
    核心创新：利用 Map 元素的固有几何特性
    - 车道线：平行性、曲率连续性、等距性
    - 人行横道：周期性条纹模式
    - 道路边界：平滑性、连续性
    
    这些几何特性在任何光照下都应该保持不变！
    """
    
    def __init__(self,
                 parallel_weight=1.0,
                 smoothness_weight=1.0,
                 periodicity_weight=1.0):
        super().__init__()
        
        self.parallel_weight = parallel_weight
        self.smoothness_weight = smoothness_weight
        self.periodicity_weight = periodicity_weight
    
    def compute_direction_field(self, edge_map):
        """
        计算方向场
        
        用于检测车道线的方向一致性（平行约束）
        """
        # 使用 Sobel 计算梯度方向
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], 
                               dtype=edge_map.dtype, device=edge_map.device)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], 
                               dtype=edge_map.dtype, device=edge_map.device)
        
        sobel_x = sobel_x.view(1, 1, 3, 3)
        sobel_y = sobel_y.view(1, 1, 3, 3)
        
        grad_x = F.conv2d(edge_map, sobel_x, padding=1)
        grad_y = F.conv2d(edge_map, sobel_y, padding=1)
        
        # 方向角
        direction = torch.atan2(grad_y, grad_x + 1e-8)
        
        return direction
    
    def compute_parallel_loss(self, direction_orig, direction_enh):
        """
        计算平行约束损失
        
        车道线的方向在增强前后应该保持一致
        """
        # 使用 cos 相似度（处理角度的周期性）
        cos_diff = torch.cos(direction_orig - direction_enh)
        loss = 1 - cos_diff.mean()
        
        return loss
    
    def compute_smoothness_loss(self, img):
        """
        计算平滑性损失
        
        道路边界应该是平滑连续的曲线
        """
        # 二阶梯度（曲率）
        grad_x = img[:, :, :, 1:] - img[:, :, :, :-1]
        grad_y = img[:, :, 1:, :] - img[:, :, :-1, :]
        
        # 二阶梯度的变化应该小
        grad_xx = grad_x[:, :, :, 1:] - grad_x[:, :, :, :-1]
        grad_yy = grad_y[:, :, 1:, :] - grad_y[:, :, :-1, :]
        
        smoothness = (torch.abs(grad_xx).mean() + torch.abs(grad_yy).mean()) / 2
        
        return smoothness
    
    def compute_periodicity_loss(self, texture_orig, texture_enh):
        """
        计算周期性损失
        
        人行横道的条纹周期在增强前后应该保持一致
        使用 FFT 分析周期性
        """
        # FFT 变换
        fft_orig = torch.fft.fft2(texture_orig)
        fft_enh = torch.fft.fft2(texture_enh)
        
        # 取幅度谱
        amp_orig = torch.abs(fft_orig)
        amp_enh = torch.abs(fft_enh)
        
        # 归一化
        amp_orig = amp_orig / (amp_orig.sum(dim=(-2, -1), keepdim=True) + 1e-8)
        amp_enh = amp_enh / (amp_enh.sum(dim=(-2, -1), keepdim=True) + 1e-8)
        
        # 周期性特征应该一致
        loss = F.l1_loss(amp_enh, amp_orig)
        
        return loss
    
    def forward(self, original, enhanced, edge_orig=None, edge_enh=None,
                texture_orig=None, texture_enh=None):
        """
        计算几何先验损失
        
        Args:
            original: [B, C, H, W] 原始图像
            enhanced: [B, C, H, W] 增强后图像
            edge_orig/edge_enh: 边缘特征（可选，用于车道线）
            texture_orig/texture_enh: 纹理特征（可选，用于人行横道）
        
        Returns:
            losses: dict
            total_loss: 总损失
        """
        losses = {}
        total_loss = 0
        
        # 转灰度
        if original.shape[1] == 3:
            gray_orig = 0.299 * original[:, 0:1] + 0.587 * original[:, 1:2] + 0.114 * original[:, 2:3]
            gray_enh = 0.299 * enhanced[:, 0:1] + 0.587 * enhanced[:, 1:2] + 0.114 * enhanced[:, 2:3]
        else:
            gray_orig = original
            gray_enh = enhanced
        
        # 1. 车道线平行约束
        if edge_orig is None:
            edge_orig = gray_orig
        if edge_enh is None:
            edge_enh = gray_enh
            
        direction_orig = self.compute_direction_field(edge_orig)
        direction_enh = self.compute_direction_field(edge_enh)
        
        parallel_loss = self.compute_parallel_loss(direction_orig, direction_enh)
        losses['loss_parallel'] = parallel_loss * self.parallel_weight
        total_loss = total_loss + losses['loss_parallel']
        
        # 2. 道路边界平滑约束
        # 增强前后的平滑性应该一致
        smooth_orig = self.compute_smoothness_loss(gray_orig)
        smooth_enh = self.compute_smoothness_loss(gray_enh)
        
        smoothness_loss = torch.abs(smooth_enh - smooth_orig)
        losses['loss_smoothness'] = smoothness_loss * self.smoothness_weight
        total_loss = total_loss + losses['loss_smoothness']
        
        # 3. 人行横道周期约束
        if texture_orig is None:
            texture_orig = gray_orig
        if texture_enh is None:
            texture_enh = gray_enh
            
        periodicity_loss = self.compute_periodicity_loss(texture_orig, texture_enh)
        losses['loss_periodicity'] = periodicity_loss * self.periodicity_weight
        total_loss = total_loss + losses['loss_periodicity']
        
        losses['loss_geometry_total'] = total_loss
        
        return losses, total_loss


class MapAwareLightAdaptationLoss(nn.Module):
    """
    Map-Aware Light Adaptation Loss (总损失)
    
    整合：
    1. Map 元素类别感知损失
    2. Map 几何先验损失
    
    这是论文的核心创新点！
    """
    
    def __init__(self,
                 # 类别感知损失配置
                 use_category_loss=True,
                 num_classes=3,
                 lane_weight=1.0,
                 crossing_weight=1.0,
                 boundary_weight=1.0,
                 # 几何先验损失配置
                 use_geometry_loss=True,
                 parallel_weight=1.0,
                 smoothness_weight=1.0,
                 periodicity_weight=1.0,
                 # 总权重
                 category_loss_weight=1.0,
                 geometry_loss_weight=1.0):
        super().__init__()
        
        self.use_category_loss = use_category_loss
        self.use_geometry_loss = use_geometry_loss
        self.category_loss_weight = category_loss_weight
        self.geometry_loss_weight = geometry_loss_weight
        
        if use_category_loss:
            self.category_loss = MapElementCategoryLoss(
                num_classes=num_classes,
                lane_weight=lane_weight,
                crossing_weight=crossing_weight,
                boundary_weight=boundary_weight
            )
        
        if use_geometry_loss:
            self.geometry_loss = MapGeometryPriorLoss(
                parallel_weight=parallel_weight,
                smoothness_weight=smoothness_weight,
                periodicity_weight=periodicity_weight
            )
    
    def forward(self, original, enhanced, class_attention_maps=None):
        """
        计算 Map-Aware 损失
        
        Args:
            original: [B, C, H, W] 原始图像 [0, 1]
            enhanced: [B, C, H, W] 增强后图像 [0, 1]
            class_attention_maps: [B, num_classes, H, W] 类别注意力图（可选）
        
        Returns:
            losses: dict
            total_loss: 总损失
        """
        losses = {}
        total_loss = 0
        
        # 1. Map 元素类别感知损失
        if self.use_category_loss:
            category_losses, category_total = self.category_loss(
                original, enhanced, class_attention_maps
            )
            for k, v in category_losses.items():
                losses[k] = v * self.category_loss_weight
            total_loss = total_loss + category_total * self.category_loss_weight
        
        # 2. Map 几何先验损失
        if self.use_geometry_loss:
            geometry_losses, geometry_total = self.geometry_loss(
                original, enhanced
            )
            for k, v in geometry_losses.items():
                losses[k] = v * self.geometry_loss_weight
            total_loss = total_loss + geometry_total * self.geometry_loss_weight
        
        losses['loss_map_aware_total'] = total_loss
        
        return losses, total_loss
