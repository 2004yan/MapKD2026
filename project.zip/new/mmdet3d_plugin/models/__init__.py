from .backbones.vovnet import VoVNet
from .backbones.efficientnet import EfficientNet
from .utils import *
from .opt.adamw import AdamW2

# 光照增强器
from .enhancers import (
    ZeroDCE, ZeroDCEPP, LightEnhancer,
    # IID Network
    IIDNetwork, IIDNetworkLite, RetinexNet,
    # Map Prior Estimator
    MapPriorEstimator, FastMapPriorEstimator,
    # MS-IIFL: 多模态光照扰动生成器
    MultiModalLightPerturbation,
    MapAwareLightPerturbation,
    DayNightPairGeneratorV2,
    # 光照退化模块
    LightDegradation,
    AdvancedLightDegradation,
    DayNightPairGenerator,
)

# Map 元素结构保护损失
from .losses import (
    MapStructureLoss,
    EdgeConsistencyLoss,
    SSIMLoss,
    PhaseConsistencyLoss,
    FrequencyStructureLoss,
    # Map 元素感知损失
    MapElementCategoryLoss,
    MapGeometryPriorLoss,
    MapAwareLightAdaptationLoss,
    MapElementAttentionGenerator,
    GaborFilterBank,
    # ECCV 核心创新 - Element-Specific Enhancement
    ElementSpecificEnhancementLoss,
    # MPGID 预训练损失
    IIDPretrainLoss,
    ReconstructionLoss,
    ShadingSmoothLoss,
    MapStructurePreserveLoss,
    AlbedoSparseLoss,
    LightPerturbationLoss,
    # MS-IIFL: Map-Structure-Guided Illumination-Invariant Feature Learning (ECCV 级别创新)
    MSIIFLLoss,
    MapElementTraitAlignmentLoss,
    BEVTopologicalDistillationLoss,
    MapElementReconstructionLoss,
)

# 模型模块（MS-IIFL 重建模块等）
from .modules import (
    MapElementReconstructor,
    LightInvariantFeatureExtractor,
)

# BEV-to-Image 投影模块（ECCV 核心创新）
from .projections import BEVToImageProjection, MapElementAttentionGenerator as MapElementAttentionGeneratorV2
