"""
Light Enhancer Module - 光照增强插件
====================================

这是一个真正的图像增强模块，类似 Retinexformer/Zero-DCE

功能：
1. 输入：低光照/退化图像
2. 输出：增强后的图像（可视化）
3. 可以独立预训练，然后插入到检测网络前面

架构借鉴：
- Retinexformer: Illumination Estimator + IG-MSA
- Zero-DCE: Deep Curve Estimation
- Retinex 理论: Image = Reflectance × Illumination
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Tuple, Dict, Optional


class IlluminationEstimator(nn.Module):
    """
    光照估计器 (借鉴 Retinexformer)
    
    估计图像的光照分量，用于后续的光照校正
    
    输入: 图像 [B, 3, H, W]
    输出: 
        - illu_fea: 光照特征 [B, C, H, W]
        - illu_map: 光照图 [B, 3, H, W]
    """
    
    def __init__(self, n_fea_middle=32, n_fea_in=4, n_fea_out=3):
        super().__init__()
        
        # 输入是 RGB + mean_channel
        self.conv1 = nn.Conv2d(n_fea_in, n_fea_middle, kernel_size=1, bias=True)
        
        # 深度可分离卷积
        self.depth_conv = nn.Conv2d(
            n_fea_middle, n_fea_middle, kernel_size=5, 
            padding=2, bias=True, groups=n_fea_middle
        )
        
        self.conv2 = nn.Conv2d(n_fea_middle, n_fea_out, kernel_size=1, bias=True)
        
    def forward(self, img: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            img: [B, 3, H, W] 输入图像，范围 [0, 1]
        Returns:
            illu_fea: [B, n_fea_middle, H, W] 光照特征
            illu_map: [B, 3, H, W] 光照图
        """
        # 计算均值通道
        mean_c = img.mean(dim=1, keepdim=True)  # [B, 1, H, W]
        
        # 拼接
        x = torch.cat([img, mean_c], dim=1)  # [B, 4, H, W]
        
        # 估计光照
        x = self.conv1(x)
        illu_fea = self.depth_conv(x)
        illu_map = self.conv2(illu_fea)
        
        return illu_fea, illu_map


class DeepCurveEstimator(nn.Module):
    """
    深度曲线估计器 (借鉴 Zero-DCE)
    
    学习一组像素级的增强曲线，用于光照调整
    
    核心公式: LE(x) = x + α * x * (1 - x)
    其中 α 是学习到的曲线参数
    """
    
    def __init__(self, n_iterations=8):
        super().__init__()
        self.n_iterations = n_iterations
        
        # 曲线参数估计网络
        self.curve_net = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, 3, padding=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, 3, padding=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 32, 3, padding=1, bias=True),
            nn.ReLU(inplace=True),
            # 输出 n_iterations * 3 个曲线参数
            nn.Conv2d(32, n_iterations * 3, 3, padding=1, bias=True),
            nn.Tanh()  # 限制在 [-1, 1]
        )
        
    def forward(self, img: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            img: [B, 3, H, W] 输入图像，范围 [0, 1]
        Returns:
            enhanced: [B, 3, H, W] 增强后的图像
            curves: [B, n_iter*3, H, W] 曲线参数
        """
        # 估计曲线参数
        curves = self.curve_net(img)  # [B, n_iter*3, H, W]
        
        # 迭代应用曲线
        enhanced = img
        for i in range(self.n_iterations):
            alpha = curves[:, i*3:(i+1)*3, :, :]  # [B, 3, H, W]
            enhanced = enhanced + alpha * enhanced * (1 - enhanced)
        
        return enhanced.clamp(0, 1), curves


class RetinexDecomposer(nn.Module):
    """
    Retinex 分解器
    
    将图像分解为 Reflectance (反射率) 和 Illumination (光照)
    
    核心公式: Image = Reflectance × Illumination
    
    Reflectance: 物体的内在颜色，光照无关
    Illumination: 场景光照，需要归一化
    """
    
    def __init__(self, n_channels=32):
        super().__init__()
        
        # 编码器
        self.encoder = nn.Sequential(
            nn.Conv2d(3, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
        )
        
        # 反射率解码器
        self.reflectance_decoder = nn.Sequential(
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, 3, 3, padding=1),
            nn.Sigmoid()  # 反射率在 [0, 1]
        )
        
        # 光照解码器
        self.illumination_decoder = nn.Sequential(
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, 1, 3, padding=1),  # 光照通常是单通道
            nn.Sigmoid()  # 光照在 [0, 1]
        )
        
    def forward(self, img: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            img: [B, 3, H, W] 输入图像
        Returns:
            reflectance: [B, 3, H, W] 反射率图
            illumination: [B, 1, H, W] 光照图
        """
        feat = self.encoder(img)
        reflectance = self.reflectance_decoder(feat)
        illumination = self.illumination_decoder(feat)
        
        return reflectance, illumination


class LightEnhancer(nn.Module):
    """
    光照增强插件 - 主模块
    
    这是一个完整的图像增强模块，可以：
    1. 独立预训练（使用 Retinex 自监督损失）
    2. 插入到检测网络前面
    3. 可视化增强效果
    
    使用方式：
    ```python
    enhancer = LightEnhancer(method='retinex')
    enhanced_img = enhancer(low_light_img)  # 直接获得增强图像
    ```
    """
    
    def __init__(self,
                 method: str = 'retinex',  # 'retinex', 'zero_dce', 'combined'
                 n_channels: int = 32,
                 n_iterations: int = 8):
        super().__init__()
        self.method = method
        
        if method == 'retinex':
            self.decomposer = RetinexDecomposer(n_channels)
        elif method == 'zero_dce':
            self.curve_estimator = DeepCurveEstimator(n_iterations)
        elif method == 'combined':
            # 结合两种方法
            self.decomposer = RetinexDecomposer(n_channels)
            self.curve_estimator = DeepCurveEstimator(n_iterations)
        else:
            raise ValueError(f"Unknown method: {method}")
        
        # 光照调整网络（用于 Retinex）
        if method in ['retinex', 'combined']:
            self.illumination_adjust = nn.Sequential(
                nn.Conv2d(1, 16, 3, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(16, 16, 3, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(16, 1, 3, padding=1),
                nn.Sigmoid()
            )
    
    def forward(self, img: torch.Tensor, 
                return_decomposition: bool = False) -> torch.Tensor:
        """
        Args:
            img: [B, 3, H, W] 输入图像，范围 [0, 1]
            return_decomposition: 是否返回分解结果（用于可视化）
        Returns:
            enhanced: [B, 3, H, W] 增强后的图像
            (可选) decomposition: dict 分解结果
        """
        if self.method == 'retinex':
            return self._forward_retinex(img, return_decomposition)
        elif self.method == 'zero_dce':
            return self._forward_zero_dce(img, return_decomposition)
        elif self.method == 'combined':
            return self._forward_combined(img, return_decomposition)
    
    def _forward_retinex(self, img: torch.Tensor, 
                         return_decomposition: bool) -> torch.Tensor:
        """Retinex 方法的前向传播"""
        # 分解
        reflectance, illumination = self.decomposer(img)
        
        # 调整光照（将暗处提亮）
        illumination_adjusted = self.illumination_adjust(illumination)
        # 确保调整后的光照不低于原光照
        illumination_adjusted = torch.max(illumination, illumination_adjusted)
        
        # 重建：Enhanced = Reflectance × Adjusted_Illumination
        enhanced = reflectance * illumination_adjusted
        enhanced = enhanced.clamp(0, 1)
        
        if return_decomposition:
            return enhanced, {
                'reflectance': reflectance,
                'illumination': illumination,
                'illumination_adjusted': illumination_adjusted
            }
        return enhanced
    
    def _forward_zero_dce(self, img: torch.Tensor,
                          return_decomposition: bool) -> torch.Tensor:
        """Zero-DCE 方法的前向传播"""
        enhanced, curves = self.curve_estimator(img)
        
        if return_decomposition:
            return enhanced, {'curves': curves}
        return enhanced
    
    def _forward_combined(self, img: torch.Tensor,
                          return_decomposition: bool) -> torch.Tensor:
        """组合方法的前向传播"""
        # 先用 Retinex 分解
        reflectance, illumination = self.decomposer(img)
        
        # 用 Zero-DCE 调整光照
        illumination_3ch = illumination.expand(-1, 3, -1, -1)
        illumination_enhanced, curves = self.curve_estimator(illumination_3ch)
        illumination_adjusted = illumination_enhanced.mean(dim=1, keepdim=True)
        
        # 重建
        enhanced = reflectance * illumination_adjusted
        enhanced = enhanced.clamp(0, 1)
        
        if return_decomposition:
            return enhanced, {
                'reflectance': reflectance,
                'illumination': illumination,
                'illumination_adjusted': illumination_adjusted,
                'curves': curves
            }
        return enhanced


class LightEnhancerLoss(nn.Module):
    """
    光照增强器的自监督训练损失
    
    不需要成对的低光照/正常光照图像对
    使用 Retinex 理论的先验约束进行自监督学习
    
    损失组成：
    1. 重建损失: ||I - R × L||
    2. 反射率平滑损失: 反射率应该分段平滑
    3. 光照平滑损失: 光照应该空间平滑
    4. 光照一致性损失: 同一场景的光照应该一致
    """
    
    def __init__(self,
                 recon_weight: float = 1.0,
                 reflectance_smooth_weight: float = 0.1,
                 illumination_smooth_weight: float = 0.1,
                 color_constancy_weight: float = 0.5):
        super().__init__()
        self.recon_weight = recon_weight
        self.reflectance_smooth_weight = reflectance_smooth_weight
        self.illumination_smooth_weight = illumination_smooth_weight
        self.color_constancy_weight = color_constancy_weight
        
    def forward(self, img: torch.Tensor,
                reflectance: torch.Tensor,
                illumination: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Args:
            img: [B, 3, H, W] 原始图像
            reflectance: [B, 3, H, W] 反射率
            illumination: [B, 1, H, W] 光照
        Returns:
            losses: 各项损失的字典
        """
        losses = {}
        
        # 1. 重建损失
        reconstructed = reflectance * illumination
        loss_recon = F.l1_loss(reconstructed, img)
        losses['loss_recon'] = loss_recon * self.recon_weight
        
        # 2. 反射率平滑损失（梯度加权）
        # 在边缘处允许反射率不连续
        img_grad_x = torch.abs(img[:, :, :, :-1] - img[:, :, :, 1:])
        img_grad_y = torch.abs(img[:, :, :-1, :] - img[:, :, 1:, :])
        weight_x = torch.exp(-10 * img_grad_x.mean(dim=1, keepdim=True))
        weight_y = torch.exp(-10 * img_grad_y.mean(dim=1, keepdim=True))
        
        ref_grad_x = torch.abs(reflectance[:, :, :, :-1] - reflectance[:, :, :, 1:])
        ref_grad_y = torch.abs(reflectance[:, :, :-1, :] - reflectance[:, :, 1:, :])
        
        loss_ref_smooth = (weight_x * ref_grad_x).mean() + (weight_y * ref_grad_y).mean()
        losses['loss_ref_smooth'] = loss_ref_smooth * self.reflectance_smooth_weight
        
        # 3. 光照平滑损失
        illu_grad_x = torch.abs(illumination[:, :, :, :-1] - illumination[:, :, :, 1:])
        illu_grad_y = torch.abs(illumination[:, :, :-1, :] - illumination[:, :, 1:, :])
        loss_illu_smooth = illu_grad_x.mean() + illu_grad_y.mean()
        losses['loss_illu_smooth'] = loss_illu_smooth * self.illumination_smooth_weight
        
        # 4. 颜色一致性损失
        # 增强后的图像应该保持颜色通道间的比例
        mean_rgb = reflectance.mean(dim=(2, 3), keepdim=True)
        loss_color = torch.abs(mean_rgb[:, 0] - mean_rgb[:, 1]).mean() + \
                     torch.abs(mean_rgb[:, 1] - mean_rgb[:, 2]).mean() + \
                     torch.abs(mean_rgb[:, 0] - mean_rgb[:, 2]).mean()
        losses['loss_color'] = loss_color * self.color_constancy_weight
        
        # 总损失
        losses['loss_total'] = sum(losses.values())
        
        return losses


# ========== 用于 MapTR 的封装 ==========
class MapTRLightEnhancer(nn.Module):
    """
    专门用于 MapTR 的光照增强插件
    
    可以直接插入到 MapTR 的数据流中
    
    使用方式：
    ```python
    # 在 MapTR 配置中
    model = dict(
        type='MapTR',
        light_enhancer=dict(
            type='MapTRLightEnhancer',
            method='retinex',
            pretrained='path/to/pretrained.pth'
        ),
        ...
    )
    ```
    """
    
    def __init__(self,
                 method: str = 'retinex',
                 pretrained: Optional[str] = None,
                 freeze: bool = False):
        super().__init__()
        self.enhancer = LightEnhancer(method=method)
        self.freeze = freeze
        
        if pretrained is not None:
            self.load_pretrained(pretrained)
        
        if freeze:
            for param in self.enhancer.parameters():
                param.requires_grad = False
    
    def load_pretrained(self, path: str):
        """加载预训练权重"""
        state_dict = torch.load(path, map_location='cpu')
        if 'state_dict' in state_dict:
            state_dict = state_dict['state_dict']
        self.enhancer.load_state_dict(state_dict, strict=False)
        print(f"Loaded pretrained light enhancer from {path}")
    
    def forward(self, img: torch.Tensor) -> torch.Tensor:
        """
        Args:
            img: [B*N, 3, H, W] 归一化后的输入图像
        Returns:
            enhanced: [B*N, 3, H, W] 增强后的图像
        """
        # 注意：MapTR 的图像是 ImageNet 归一化的
        # 需要先反归一化到 [0, 1]
        
        # ImageNet 统计量
        mean = torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1).to(img.device)
        std = torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1).to(img.device)
        
        # 反归一化
        img_denorm = img * std + mean
        img_denorm = img_denorm / 255.0
        img_denorm = img_denorm.clamp(0, 1)
        
        # 增强
        if self.freeze:
            with torch.no_grad():
                enhanced = self.enhancer(img_denorm)
        else:
            enhanced = self.enhancer(img_denorm)
        
        # 重新归一化
        enhanced_norm = enhanced * 255.0
        enhanced_norm = (enhanced_norm - mean) / std
        
        return enhanced_norm
