"""
Multi-Modal Light Perturbation Generator
多模态光照扰动生成器

MS-IIFL 框架核心组件之一

超越简单的伽马/噪声，模拟更多种类的光照退化：
1. 夜间低光照 (Night Low-Light)
2. 雨天反射 (Rainy Reflection)  
3. 雾霾散射 (Foggy Scattering)
4. 强光过曝 (Overexposure)
5. 路灯局部光照 (Street Light Spots)

参考：
- LightDiff (CVPR 2024): Multi-condition diffusion
- MAET (ICCV 2021): Low-light degradation model
- RainNet: Rain streak modeling
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random
from typing import Tuple, Dict, Optional, List


class MultiModalLightPerturbation(nn.Module):
    """
    多模态光照扰动生成器
    
    可同时生成多种退化类型，用于更鲁棒的训练
    
    创新点：
    1. 多模态退化：不仅是夜间，还包括雨雾等
    2. 地图感知退化：可以针对地图元素区域进行定向退化
    3. 物理可信：基于物理模型的退化，更真实
    """
    
    def __init__(self,
                 # 退化类型开关
                 enable_night: bool = True,
                 enable_rain: bool = True,
                 enable_fog: bool = True,
                 enable_overexpose: bool = False,
                 enable_local_light: bool = True,
                 # 退化强度参数
                 night_darkness_range: Tuple[float, float] = (0.05, 0.3),
                 night_gamma_range: Tuple[float, float] = (2.0, 3.5),
                 night_noise_range: Tuple[float, float] = (0.01, 0.05),
                 rain_intensity_range: Tuple[float, float] = (0.1, 0.4),
                 fog_density_range: Tuple[float, float] = (0.1, 0.5),
                 # 采样概率
                 mode_probs: Optional[Dict[str, float]] = None):
        super().__init__()
        
        self.enable_night = enable_night
        self.enable_rain = enable_rain
        self.enable_fog = enable_fog
        self.enable_overexpose = enable_overexpose
        self.enable_local_light = enable_local_light
        
        self.night_darkness_range = night_darkness_range
        self.night_gamma_range = night_gamma_range
        self.night_noise_range = night_noise_range
        self.rain_intensity_range = rain_intensity_range
        self.fog_density_range = fog_density_range
        
        # 默认采样概率
        if mode_probs is None:
            mode_probs = {
                'night': 0.5,
                'rain': 0.2,
                'fog': 0.2,
                'overexpose': 0.05,
                'combined': 0.05
            }
        self.mode_probs = mode_probs
        
        # ISP 相关矩阵
        self.register_buffer('rgb2gray', 
            torch.tensor([0.299, 0.587, 0.114]).view(1, 3, 1, 1))
    
    def forward(self, img: torch.Tensor, 
                mode: Optional[str] = None) -> Tuple[torch.Tensor, Dict]:
        """
        Args:
            img: [B, C, H, W] RGB 图像，范围 [0, 1]
            mode: 指定退化模式，None 则随机选择
        Returns:
            degraded: 退化后的图像
            params: 退化参数（用于可视化/调试）
        """
        if mode is None:
            mode = self._sample_mode()
        
        params = {'mode': mode}
        
        if mode == 'night':
            degraded, night_params = self._apply_night_degradation(img)
            params.update(night_params)
        elif mode == 'rain':
            degraded, rain_params = self._apply_rain_degradation(img)
            params.update(rain_params)
        elif mode == 'fog':
            degraded, fog_params = self._apply_fog_degradation(img)
            params.update(fog_params)
        elif mode == 'overexpose':
            degraded, over_params = self._apply_overexposure(img)
            params.update(over_params)
        elif mode == 'combined':
            degraded, comb_params = self._apply_combined_degradation(img)
            params.update(comb_params)
        else:
            degraded = img
        
        # 可选：添加局部光照
        if self.enable_local_light and random.random() < 0.3:
            degraded, light_params = self._add_local_lights(degraded)
            params['local_light'] = light_params
        
        return degraded.clamp(0, 1), params
    
    def _sample_mode(self) -> str:
        """根据概率采样退化模式"""
        modes = []
        probs = []
        
        if self.enable_night:
            modes.append('night')
            probs.append(self.mode_probs.get('night', 0.5))
        if self.enable_rain:
            modes.append('rain')
            probs.append(self.mode_probs.get('rain', 0.2))
        if self.enable_fog:
            modes.append('fog')
            probs.append(self.mode_probs.get('fog', 0.2))
        if self.enable_overexpose:
            modes.append('overexpose')
            probs.append(self.mode_probs.get('overexpose', 0.05))
        
        # 组合模式
        modes.append('combined')
        probs.append(self.mode_probs.get('combined', 0.05))
        
        # 归一化
        probs = np.array(probs) / sum(probs)
        
        return np.random.choice(modes, p=probs)
    
    def _apply_night_degradation(self, img: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        夜间低光照退化
        
        物理模型：
        I_night = (I_day * darkness)^gamma + noise
        """
        B, C, H, W = img.shape
        device = img.device
        params = {}
        
        # 1. 全局暗化
        darkness = random.uniform(*self.night_darkness_range)
        degraded = img * darkness
        params['darkness'] = darkness
        
        # 2. 伽马畸变（非线性压缩）
        gamma = random.uniform(*self.night_gamma_range)
        degraded = torch.pow(degraded + 1e-8, gamma)
        params['gamma'] = gamma
        
        # 3. 传感器噪声（Shot noise + Read noise）
        noise_level = random.uniform(*self.night_noise_range)
        # Shot noise（信号依赖）
        shot_noise = torch.randn_like(degraded) * torch.sqrt(degraded + 1e-8) * noise_level
        # Read noise（固定）
        read_noise = torch.randn_like(degraded) * noise_level * 0.5
        degraded = degraded + shot_noise + read_noise
        params['noise_level'] = noise_level
        
        # 4. 颜色偏移（夜间相机色偏）
        if random.random() < 0.3:
            color_shift = torch.randn(1, 3, 1, 1, device=device) * 0.05
            degraded = degraded + color_shift
            params['color_shift'] = True
        
        return degraded.clamp(0, 1), params
    
    def _apply_rain_degradation(self, img: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        雨天退化
        
        物理模型：
        I_rain = I * (1 - rain_mask) + rain_streaks + reflection
        
        雨天对地图的影响：
        - 路面反射导致车道线模糊
        - 雨滴遮挡视野
        """
        B, C, H, W = img.shape
        device = img.device
        params = {}
        
        rain_intensity = random.uniform(*self.rain_intensity_range)
        params['rain_intensity'] = rain_intensity
        
        # 1. 生成雨条纹
        rain_streaks = self._generate_rain_streaks(B, H, W, device, rain_intensity)
        
        # 2. 路面反射（下半部分图像更强）
        y_coords = torch.linspace(0, 1, H, device=device).view(1, 1, H, 1)
        reflection_mask = y_coords ** 2 * rain_intensity * 0.5  # 越下面反射越强
        
        # 3. 整体降低对比度
        degraded = img * (1 - rain_intensity * 0.3)
        
        # 4. 添加雨条纹
        degraded = degraded + rain_streaks * 0.5
        
        # 5. 添加反射（翻转上半部分图像到下半部分）
        if random.random() < 0.5:
            reflection = torch.flip(img[:, :, :H//2, :], dims=[2])
            reflection = F.pad(reflection, (0, 0, H - H//2, 0), mode='constant', value=0)
            degraded = degraded + reflection * reflection_mask * 0.3
        
        return degraded.clamp(0, 1), params
    
    def _generate_rain_streaks(self, B: int, H: int, W: int, 
                                device: torch.device, intensity: float) -> torch.Tensor:
        """生成雨条纹纹理"""
        # 使用倾斜的噪声模拟雨条纹
        noise = torch.randn(B, 1, H, W, device=device)
        
        # 应用运动模糊核（模拟雨滴下落）
        kernel_size = 15
        kernel = torch.zeros(1, 1, kernel_size, kernel_size, device=device)
        for i in range(kernel_size):
            kernel[0, 0, i, kernel_size - 1 - i] = 1.0 / kernel_size
        
        rain = F.conv2d(noise, kernel, padding=kernel_size // 2)
        rain = (rain - rain.min()) / (rain.max() - rain.min() + 1e-8)
        rain = rain * intensity
        
        # 扩展到 3 通道
        return rain.expand(B, 3, H, W)
    
    def _apply_fog_degradation(self, img: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        雾霾退化
        
        物理模型（Atmospheric Scattering Model）：
        I_fog = I * t + A * (1 - t)
        其中 t = exp(-beta * d)，d 为深度
        
        雾霾对地图的影响：
        - 远处地图元素更模糊
        - 整体对比度下降
        """
        B, C, H, W = img.shape
        device = img.device
        params = {}
        
        fog_density = random.uniform(*self.fog_density_range)
        params['fog_density'] = fog_density
        
        # 1. 大气光 A（通常是白色或灰白色）
        atmospheric_light = random.uniform(0.7, 0.95)
        params['atmospheric_light'] = atmospheric_light
        
        # 2. 模拟深度图（假设上方远、下方近）
        # 这是一个简化，真实场景需要深度估计
        y_coords = torch.linspace(0, 1, H, device=device).view(1, 1, H, 1)
        pseudo_depth = 1 - y_coords  # 上远下近
        
        # 3. 传输图 t
        transmission = torch.exp(-fog_density * 10 * pseudo_depth)
        transmission = transmission.expand(B, C, H, W)
        
        # 4. 应用散射模型
        degraded = img * transmission + atmospheric_light * (1 - transmission)
        
        # 5. 添加轻微噪声
        degraded = degraded + torch.randn_like(degraded) * 0.01
        
        return degraded.clamp(0, 1), params
    
    def _apply_overexposure(self, img: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        过曝退化（模拟强光直射）
        
        影响：高光区域饱和，细节丢失
        """
        B, C, H, W = img.shape
        device = img.device
        params = {}
        
        exposure_factor = random.uniform(1.5, 3.0)
        params['exposure_factor'] = exposure_factor
        
        # 1. 增加曝光
        degraded = img * exposure_factor
        
        # 2. 软饱和（避免硬剪裁）
        degraded = 1 - torch.exp(-degraded)
        
        # 3. 局部过曝（模拟阳光直射区域）
        if random.random() < 0.5:
            cx = random.randint(W // 4, W * 3 // 4)
            cy = random.randint(0, H // 3)  # 通常在上方
            radius = random.randint(100, 300)
            
            y_coords = torch.arange(H, device=device).view(1, 1, H, 1).float()
            x_coords = torch.arange(W, device=device).view(1, 1, 1, W).float()
            
            dist = torch.sqrt((x_coords - cx) ** 2 + (y_coords - cy) ** 2)
            flare_mask = torch.exp(-dist ** 2 / (2 * radius ** 2))
            
            degraded = degraded + flare_mask * 0.3
            params['lens_flare'] = True
        
        return degraded.clamp(0, 1), params
    
    def _apply_combined_degradation(self, img: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        组合退化（同时应用多种退化）
        
        例如：雨夜 = 夜间 + 雨天
        """
        params = {'combined': True, 'components': []}
        degraded = img
        
        # 随机组合 1-2 种退化
        available_modes = []
        if self.enable_night:
            available_modes.append('night')
        if self.enable_rain:
            available_modes.append('rain')
        if self.enable_fog:
            available_modes.append('fog')
        
        num_combine = random.randint(1, 2)
        selected_modes = random.sample(available_modes, min(num_combine, len(available_modes)))
        
        for mode in selected_modes:
            if mode == 'night':
                degraded, p = self._apply_night_degradation(degraded)
            elif mode == 'rain':
                degraded, p = self._apply_rain_degradation(degraded)
            elif mode == 'fog':
                degraded, p = self._apply_fog_degradation(degraded)
            
            params['components'].append({mode: p})
        
        return degraded.clamp(0, 1), params
    
    def _add_local_lights(self, img: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """
        添加局部光源（路灯、车灯）
        
        这对夜间场景很重要，因为：
        - 车道线在路灯下可见
        - 人行横道在车灯下可见
        """
        B, C, H, W = img.shape
        device = img.device
        params = {}
        
        num_lights = random.randint(1, 4)
        params['num_lights'] = num_lights
        
        light_mask = torch.zeros(B, 1, H, W, device=device)
        
        for i in range(num_lights):
            # 路灯通常在图像上部或两侧
            if random.random() < 0.7:  # 路灯
                cx = random.randint(0, W)
                cy = random.randint(0, H // 3)
                radius = random.randint(80, 200)
                intensity = random.uniform(0.3, 0.7)
            else:  # 车灯（中下部）
                cx = random.randint(W // 3, W * 2 // 3)
                cy = random.randint(H // 2, H)
                radius = random.randint(50, 100)
                intensity = random.uniform(0.2, 0.4)
            
            y_coords = torch.arange(H, device=device).view(1, 1, H, 1).float()
            x_coords = torch.arange(W, device=device).view(1, 1, 1, W).float()
            
            dist_sq = (x_coords - cx) ** 2 + (y_coords - cy) ** 2
            gaussian = torch.exp(-dist_sq / (2 * radius ** 2)) * intensity
            
            light_mask = light_mask + gaussian
        
        light_mask = light_mask.clamp(0, 1)
        
        # 添加光照效果（增亮）
        img_with_lights = img + light_mask * (1 - img) * 0.6
        
        params['light_coverage'] = light_mask.mean().item()
        
        return img_with_lights.clamp(0, 1), params


class MapAwareLightPerturbation(MultiModalLightPerturbation):
    """
    地图感知光照扰动生成器
    
    创新点：针对地图元素区域进行定向退化/保护
    
    例如：
    - 在车道线区域添加更强的反光（模拟真实的车道线反光）
    - 在人行横道区域添加更多噪声（模拟斑马线磨损）
    """
    
    def __init__(self,
                 lane_reflect_prob: float = 0.3,
                 crosswalk_noise_prob: float = 0.2,
                 **kwargs):
        super().__init__(**kwargs)
        self.lane_reflect_prob = lane_reflect_prob
        self.crosswalk_noise_prob = crosswalk_noise_prob
    
    def forward_with_mask(self, img: torch.Tensor,
                          map_mask: Optional[torch.Tensor] = None,
                          mode: Optional[str] = None) -> Tuple[torch.Tensor, Dict]:
        """
        带地图掩码的退化
        
        Args:
            img: [B, C, H, W] RGB 图像
            map_mask: [B, 3, H, W] 地图元素掩码（车道线、边界、人行横道）
            mode: 退化模式
        """
        # 先应用基础退化
        degraded, params = self.forward(img, mode)
        
        if map_mask is not None:
            # 在地图元素区域应用特殊处理
            lane_mask = map_mask[:, 0:1, :, :]  # 车道线
            boundary_mask = map_mask[:, 1:2, :, :]  # 边界
            crosswalk_mask = map_mask[:, 2:3, :, :]  # 人行横道
            
            # 车道线反光
            if random.random() < self.lane_reflect_prob:
                lane_reflect = torch.randn_like(degraded) * 0.1 + 0.2
                degraded = degraded + lane_mask * lane_reflect
                params['lane_reflect'] = True
            
            # 人行横道额外噪声
            if random.random() < self.crosswalk_noise_prob:
                crosswalk_noise = torch.randn_like(degraded) * 0.05
                degraded = degraded + crosswalk_mask * crosswalk_noise
                params['crosswalk_noise'] = True
        
        return degraded.clamp(0, 1), params


class DayNightPairGeneratorV2(nn.Module):
    """
    升级版白天-夜间图像对生成器
    
    用于 MS-IIFL 框架的自监督训练
    """
    
    def __init__(self,
                 degradation_type: str = 'multi_modal',
                 **kwargs):
        super().__init__()
        
        if degradation_type == 'multi_modal':
            self.degradation = MultiModalLightPerturbation(**kwargs)
        elif degradation_type == 'map_aware':
            self.degradation = MapAwareLightPerturbation(**kwargs)
        else:
            raise ValueError(f"Unknown degradation type: {degradation_type}")
    
    def forward(self, img_day: torch.Tensor,
                map_mask: Optional[torch.Tensor] = None,
                mode: Optional[str] = None) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
        """
        Args:
            img_day: [B, C, H, W] 白天图像，范围 [0, 1]
            map_mask: [B, 3, H, W] 可选的地图掩码
            mode: 指定退化模式
        Returns:
            img_day: 原始白天图像
            img_degraded: 退化后的图像
            params: 退化参数
        """
        if isinstance(self.degradation, MapAwareLightPerturbation) and map_mask is not None:
            img_degraded, params = self.degradation.forward_with_mask(img_day, map_mask, mode)
        else:
            img_degraded, params = self.degradation(img_day, mode)
        
        return img_day, img_degraded, params
