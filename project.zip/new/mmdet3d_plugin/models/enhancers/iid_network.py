"""
Intrinsic Image Decomposition (IID) Network
Map-Prior Guided Intrinsic Decomposition (MPGID)

核心思想：将图像分解为 Albedo（反照率）和 Shading（阴影）
I = A × S
- Albedo: 物体的固有材质颜色，光照不变
- Shading: 光照效应，低频变化

Reference:
- Intrinsic Images in the Wild (SIGGRAPH 2014)
- CGIntrinsics (ECCV 2018)
- USI3D (CVPR 2020)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import BaseModule
from mmdet.models import BACKBONES


class ConvBlock(nn.Module):
    """基础卷积块"""
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, 
                 padding=1, use_bn=True, activation='relu'):
        super().__init__()
        layers = [
            nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=not use_bn)
        ]
        if use_bn:
            layers.append(nn.BatchNorm2d(out_channels))
        if activation == 'relu':
            layers.append(nn.ReLU(inplace=True))
        elif activation == 'leaky_relu':
            layers.append(nn.LeakyReLU(0.2, inplace=True))
        elif activation == 'sigmoid':
            layers.append(nn.Sigmoid())
        elif activation == 'tanh':
            layers.append(nn.Tanh())
        
        self.block = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.block(x)


class ResidualBlock(nn.Module):
    """残差块"""
    def __init__(self, channels, use_bn=True):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, 1, 1, bias=not use_bn)
        self.bn1 = nn.BatchNorm2d(channels) if use_bn else nn.Identity()
        self.conv2 = nn.Conv2d(channels, channels, 3, 1, 1, bias=not use_bn)
        self.bn2 = nn.BatchNorm2d(channels) if use_bn else nn.Identity()
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        residual = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = out + residual
        return self.relu(out)


class EncoderBlock(nn.Module):
    """编码器块：下采样"""
    def __init__(self, in_channels, out_channels, use_bn=True):
        super().__init__()
        self.conv = ConvBlock(in_channels, out_channels, 3, 2, 1, use_bn, 'leaky_relu')
        self.res = ResidualBlock(out_channels, use_bn)
    
    def forward(self, x):
        x = self.conv(x)
        x = self.res(x)
        return x


class DecoderBlock(nn.Module):
    """解码器块：上采样"""
    def __init__(self, in_channels, out_channels, use_bn=True):
        super().__init__()
        self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.conv = ConvBlock(in_channels, out_channels, 3, 1, 1, use_bn, 'relu')
        self.res = ResidualBlock(out_channels, use_bn)
    
    def forward(self, x, skip=None):
        x = self.up(x)
        if skip is not None:
            # 处理尺寸不匹配
            if x.shape[2:] != skip.shape[2:]:
                x = F.interpolate(x, size=skip.shape[2:], mode='bilinear', align_corners=True)
            x = torch.cat([x, skip], dim=1)
        x = self.conv(x)
        x = self.res(x)
        return x


@BACKBONES.register_module()
class IIDNetwork(BaseModule):
    """
    Intrinsic Image Decomposition Network
    
    分解图像为 Albedo 和 Shading:
    I = A × S
    
    Args:
        in_channels: 输入通道数 (RGB = 3)
        base_channels: 基础通道数
        num_levels: 编码器/解码器层数
        use_bn: 是否使用 BatchNorm
        share_encoder: 是否共享编码器
    """
    
    def __init__(self,
                 in_channels=3,
                 base_channels=64,
                 num_levels=4,
                 use_bn=True,
                 share_encoder=True,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        self.in_channels = in_channels
        self.base_channels = base_channels
        self.num_levels = num_levels
        self.share_encoder = share_encoder
        
        # 计算每层通道数
        channels = [base_channels * (2 ** i) for i in range(num_levels)]
        # 限制最大通道数
        channels = [min(c, 512) for c in channels]
        
        # 共享编码器
        self.init_conv = ConvBlock(in_channels, base_channels, 7, 1, 3, use_bn, 'relu')
        
        self.encoders = nn.ModuleList()
        for i in range(num_levels):
            in_ch = channels[i-1] if i > 0 else base_channels
            out_ch = channels[i]
            self.encoders.append(EncoderBlock(in_ch, out_ch, use_bn))
        
        # Bottleneck
        self.bottleneck = nn.Sequential(
            ResidualBlock(channels[-1], use_bn),
            ResidualBlock(channels[-1], use_bn),
        )
        
        # Albedo 解码器
        # 构建时需要追踪上一层输出通道数
        self.albedo_decoders = nn.ModuleList()
        prev_out_ch = channels[-1]  # bottleneck 输出通道数
        for i in range(num_levels - 1, -1, -1):
            in_ch = prev_out_ch  # 上一层输出
            skip_ch = channels[i-1] if i > 0 else base_channels  # encoder 对应层输出
            out_ch = channels[i-1] if i > 0 else base_channels
            # 考虑 skip connection: 输入 = 上一层输出 + skip
            self.albedo_decoders.append(DecoderBlock(in_ch + skip_ch, out_ch, use_bn))
            prev_out_ch = out_ch  # 更新上一层输出
        
        self.albedo_out = nn.Sequential(
            nn.Conv2d(base_channels, in_channels, 3, 1, 1),
            nn.Sigmoid()  # Albedo 在 [0, 1] 范围
        )
        
        # Shading 解码器
        # 构建时需要追踪上一层输出通道数
        self.shading_decoders = nn.ModuleList()
        prev_out_ch = channels[-1]  # bottleneck 输出通道数
        for i in range(num_levels - 1, -1, -1):
            in_ch = prev_out_ch  # 上一层输出
            skip_ch = channels[i-1] if i > 0 else base_channels
            out_ch = channels[i-1] if i > 0 else base_channels
            self.shading_decoders.append(DecoderBlock(in_ch + skip_ch, out_ch, use_bn))
            prev_out_ch = out_ch  # 更新上一层输出
        
        self.shading_out = nn.Sequential(
            nn.Conv2d(base_channels, 1, 3, 1, 1),  # Shading 是单通道
            nn.Sigmoid()  # Shading 在 [0, 1] 范围
        )
        
        self._init_weights()
    
    def _init_weights(self):
        """初始化权重"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
    
    def forward(self, x):
        """
        前向传播
        
        Args:
            x: 输入图像 [B, 3, H, W]，范围 [0, 1]
        
        Returns:
            albedo: 反照率 [B, 3, H, W]，范围 [0, 1]
            shading: 阴影 [B, 1, H, W]，范围 [0, 1]
        """
        # 编码
        feat = self.init_conv(x)
        
        encoder_feats = [feat]
        for encoder in self.encoders:
            feat = encoder(feat)
            encoder_feats.append(feat)
        
        # Bottleneck
        feat = self.bottleneck(feat)
        
        # Albedo 解码
        albedo_feat = feat
        for i, decoder in enumerate(self.albedo_decoders):
            skip_idx = self.num_levels - 1 - i
            skip = encoder_feats[skip_idx]
            albedo_feat = decoder(albedo_feat, skip)
        
        albedo = self.albedo_out(albedo_feat)
        
        # Shading 解码
        shading_feat = feat
        for i, decoder in enumerate(self.shading_decoders):
            skip_idx = self.num_levels - 1 - i
            skip = encoder_feats[skip_idx]
            shading_feat = decoder(shading_feat, skip)
        
        shading = self.shading_out(shading_feat)
        
        return albedo, shading
    
    def reconstruct(self, albedo, shading):
        """
        从 Albedo 和 Shading 重建图像
        
        Args:
            albedo: [B, 3, H, W]
            shading: [B, 1, H, W]
        
        Returns:
            reconstructed: [B, 3, H, W]
        """
        return albedo * shading


@BACKBONES.register_module()
class IIDNetworkLite(BaseModule):
    """
    轻量级 IID 网络
    
    使用更少的参数，适合预训练
    """
    
    def __init__(self,
                 in_channels=3,
                 base_channels=32,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        # 共享编码器
        self.encoder = nn.Sequential(
            ConvBlock(in_channels, base_channels, 3, 1, 1),
            ConvBlock(base_channels, base_channels * 2, 3, 2, 1),
            ResidualBlock(base_channels * 2),
            ConvBlock(base_channels * 2, base_channels * 4, 3, 2, 1),
            ResidualBlock(base_channels * 4),
            ResidualBlock(base_channels * 4),
        )
        
        # Albedo 分支
        self.albedo_decoder = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            ConvBlock(base_channels * 4, base_channels * 2, 3, 1, 1),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            ConvBlock(base_channels * 2, base_channels, 3, 1, 1),
            nn.Conv2d(base_channels, in_channels, 3, 1, 1),
            nn.Sigmoid()
        )
        
        # Shading 分支
        self.shading_decoder = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            ConvBlock(base_channels * 4, base_channels * 2, 3, 1, 1),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            ConvBlock(base_channels * 2, base_channels, 3, 1, 1),
            nn.Conv2d(base_channels, 1, 3, 1, 1),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        feat = self.encoder(x)
        albedo = self.albedo_decoder(feat)
        shading = self.shading_decoder(feat)
        
        # 确保输出尺寸与输入一致
        if albedo.shape[2:] != x.shape[2:]:
            albedo = F.interpolate(albedo, size=x.shape[2:], mode='bilinear', align_corners=True)
            shading = F.interpolate(shading, size=x.shape[2:], mode='bilinear', align_corners=True)
        
        return albedo, shading
    
    def reconstruct(self, albedo, shading):
        return albedo * shading


@BACKBONES.register_module()
class RetinexNet(BaseModule):
    """
    RetinexNet 风格的 IID 网络
    
    参考 RetinexNet (BMVC 2018) 的设计
    """
    
    def __init__(self,
                 in_channels=3,
                 base_channels=32,
                 init_cfg=None):
        super().__init__(init_cfg)
        
        # DecomNet - 分解网络
        self.decom_net = nn.Sequential(
            nn.Conv2d(in_channels, base_channels, 3, 1, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_channels, base_channels, 3, 1, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_channels, base_channels, 3, 1, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_channels, base_channels, 3, 1, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_channels, base_channels, 3, 1, 1),
            nn.ReLU(inplace=True),
        )
        
        # Albedo 输出
        self.albedo_out = nn.Sequential(
            nn.Conv2d(base_channels, in_channels, 3, 1, 1),
            nn.Sigmoid()
        )
        
        # Shading (Illumination) 输出
        self.shading_out = nn.Sequential(
            nn.Conv2d(base_channels, 1, 3, 1, 1),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        feat = self.decom_net(x)
        albedo = self.albedo_out(feat)
        shading = self.shading_out(feat)
        return albedo, shading
    
    def reconstruct(self, albedo, shading):
        return albedo * shading
