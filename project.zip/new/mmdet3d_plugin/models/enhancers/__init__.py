"""
光照增强器模块

包含：
1. Zero-DCE: 零参考深度曲线估计
2. IID Network: Intrinsic Image Decomposition 网络
3. Map Prior Estimator: Map 元素先验估计器（多版本）
   - v2: RobustMapPriorEstimator (通用光照鲁棒)
   - v4: TaskAwareMapPrior (针对三类地图元素设计)
"""

from .zero_dce import ZeroDCE, ZeroDCEPP
from .enhancer_wrapper import LightEnhancer
from .iid_network import IIDNetwork, IIDNetworkLite, RetinexNet
from .map_prior_estimator import (
    # 原有类（保持兼容）
    MapPriorEstimator,
    FastMapPriorEstimator,
    SobelEdgeDetector,
    GradientOperator,
    # v2: 光照鲁棒版本
    RobustMapPriorEstimator,
    AdaptiveBrightnessEnhancer,
    AdaptiveEdgeDetector,
    StructureTensorEdge,
    RobustColorFilter,
    # [v3] 道路专用检测器（已弃用，效果不好）
    LinearStructureDetector,
    RoadRegionMask,
    TextureConsistencyFilter,
)
# v4: 任务感知版本（针对三类地图元素设计）
from .task_aware_map_prior import (
    TaskAwareMapPrior,
    LaneLinePrior,
    RoadBoundaryPrior,
    CrosswalkPrior,
)

# MS-IIFL: 多模态光照扰动生成器 (ECCV 级别创新)
from .multi_modal_light_perturbation import (
    MultiModalLightPerturbation,
    MapAwareLightPerturbation,
    DayNightPairGeneratorV2,
)

# 光照退化模块
from .light_degradation import (
    LightDegradation,
    AdvancedLightDegradation,
    DayNightPairGenerator,
)

# 光照增强插件（正确的架构 - 类似 Retinexformer）
from .light_enhancer import (
    LightEnhancer as RetinexLightEnhancer,  # 避免命名冲突
    MapTRLightEnhancer,
    IlluminationEstimator,
    DeepCurveEstimator,
    RetinexDecomposer,
    LightEnhancerLoss,
)

# NIME: Neural-Inspired Map Element Enhancement (新框架)
from .nime_enhancer import (
    NIMEEnhancer,
    NIMELoss,
    NIMEMapTREnhancer,
    GaborFilterBank,
    ContourIntegration,
    MapElementPrior,
    ReflectanceEnhancer,
    LightDegradation as NIMELightDegradation,
)

__all__ = [
    # Zero-DCE
    'ZeroDCE', 'ZeroDCEPP', 'LightEnhancer',
    # IID Network
    'IIDNetwork', 'IIDNetworkLite', 'RetinexNet',
    # Map Prior v1 (原有)
    'MapPriorEstimator', 'FastMapPriorEstimator',
    'SobelEdgeDetector', 'GradientOperator',
    # Map Prior v2 (光照鲁棒)
    'RobustMapPriorEstimator',
    'AdaptiveBrightnessEnhancer',
    'AdaptiveEdgeDetector',
    'StructureTensorEdge',
    'RobustColorFilter',
    # Map Prior v4 (任务感知 - 推荐)
    'TaskAwareMapPrior',
    'LaneLinePrior',
    'RoadBoundaryPrior', 
    'CrosswalkPrior',
    # MS-IIFL: 多模态光照扰动生成器 (ECCV 级别创新)
    'MultiModalLightPerturbation',
    'MapAwareLightPerturbation',
    'DayNightPairGeneratorV2',
    # 光照退化模块
    'LightDegradation',
    'AdvancedLightDegradation',
    'DayNightPairGenerator',
    # NIME: Neural-Inspired Map Element Enhancement (新框架)
    'NIMEEnhancer',
    'NIMELoss',
    'NIMEMapTREnhancer',
    'GaborFilterBank',
    'ContourIntegration',
    'MapElementPrior',
    'ReflectanceEnhancer',
]
