"""
NIME: Neural-Inspired Map Element Enhancement
==============================================

基于神经科学视觉感知理论的地图元素增强框架

理论基础：
1. Gabor 滤波器 - V1 视觉皮层模型 (Hubel & Wiesel, 1962)
2. 轮廓整合 - Association Field (Field et al., 1993)
3. Retinex - 反射率恒常性 (Land & McCann, 1971)
4. CSF - 对比度敏感度函数 (Campbell & Robson, 1968)

针对地图元素设计：
- 车道线：方向性 Gabor 响应
- 人行横道：周期性频率响应
- 道路边界：轮廓整合连续性
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math
from typing import Tuple, Dict, Optional, List


# ============================================================
# Part 1: Gabor Filter Bank (V1 视觉皮层模型)
# ============================================================

class GaborFilterBank(nn.Module):
    """
    Gabor 滤波器组 - 模拟 V1 视觉皮层
    
    理论依据：
    - Hubel & Wiesel (1962): V1 简单细胞的方向选择性
    - Daugman (1985): Gabor 函数是 V1 细胞的最佳数学描述
    
    Gabor 函数：
    G(x,y) = exp(-(x'^2 + γ^2*y'^2)/(2σ^2)) * cos(2π*x'/λ + φ)
    
    其中 x' = x*cos(θ) + y*sin(θ), y' = -x*sin(θ) + y*cos(θ)
    """
    
    def __init__(self,
                 n_orientations: int = 8,      # 方向数（车道线各方向）
                 n_scales: int = 4,            # 尺度数（不同粗细的线）
                 kernel_size: int = 31,
                 sigma_range: Tuple[float, float] = (2.0, 8.0),
                 lambda_range: Tuple[float, float] = (4.0, 16.0),
                 gamma: float = 0.5):          # 长宽比
        super().__init__()
        
        self.n_orientations = n_orientations
        self.n_scales = n_scales
        
        # 生成 Gabor 滤波器
        filters = []
        orientations = np.linspace(0, np.pi, n_orientations, endpoint=False)
        sigmas = np.linspace(sigma_range[0], sigma_range[1], n_scales)
        lambdas = np.linspace(lambda_range[0], lambda_range[1], n_scales)
        
        for sigma, lam in zip(sigmas, lambdas):
            for theta in orientations:
                kernel = self._create_gabor_kernel(
                    kernel_size, sigma, theta, lam, gamma
                )
                filters.append(kernel)
        
        # [n_filters, 1, H, W]
        filters = torch.stack(filters, dim=0).unsqueeze(1)
        self.register_buffer('filters', filters)
        
        self.n_filters = len(filters)
        
    def _create_gabor_kernel(self, size: int, sigma: float, 
                              theta: float, lambd: float, 
                              gamma: float) -> torch.Tensor:
        """创建单个 Gabor 核"""
        half = size // 2
        # 兼容旧版 PyTorch（不支持 indexing 参数）
        coords = torch.arange(-half, half + 1, dtype=torch.float32)
        y, x = torch.meshgrid(coords, coords)  # 默认 'ij' 顺序
        
        # 旋转
        x_theta = x * np.cos(theta) + y * np.sin(theta)
        y_theta = -x * np.sin(theta) + y * np.cos(theta)
        
        # Gabor 函数
        gaussian = torch.exp(-(x_theta**2 + gamma**2 * y_theta**2) / (2 * sigma**2))
        sinusoid = torch.cos(2 * np.pi * x_theta / lambd)
        
        gabor = gaussian * sinusoid
        
        # 归一化（零均值）
        gabor = gabor - gabor.mean()
        gabor = gabor / (gabor.abs().sum() + 1e-8)
        
        return gabor
    
    def forward(self, img: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            img: [B, C, H, W] 输入图像
        Returns:
            responses: [B, n_filters, H, W] Gabor 响应
            orientation_map: [B, 1, H, W] 主方向图
        """
        B, C, H, W = img.shape
        
        # 转灰度
        if C == 3:
            gray = 0.299 * img[:, 0] + 0.587 * img[:, 1] + 0.114 * img[:, 2]
            gray = gray.unsqueeze(1)
        else:
            gray = img
        
        # ========================================
        # 关键改进：亮度自适应预处理
        # 解决夜间图像 Gabor 响应弱的问题
        # ========================================
        
        # 1. 计算图像亮度
        mean_brightness = gray.mean(dim=[2, 3], keepdim=True)
        
        # 2. 如果是暗图（亮度 < 0.3），做局部对比度增强
        is_dark = (mean_brightness < 0.3).float()
        
        # 局部对比度归一化（类似 CLAHE 的效果）
        # 计算局部均值和标准差
        kernel_size = 31
        pad = kernel_size // 2
        
        # 局部均值
        kernel = torch.ones(1, 1, kernel_size, kernel_size, device=gray.device) / (kernel_size ** 2)
        local_mean = F.conv2d(F.pad(gray, (pad, pad, pad, pad), mode='reflect'), kernel)
        
        # 局部标准差
        local_sq_mean = F.conv2d(F.pad(gray ** 2, (pad, pad, pad, pad), mode='reflect'), kernel)
        local_std = torch.sqrt((local_sq_mean - local_mean ** 2).clamp(min=1e-6))
        
        # 归一化
        gray_normalized = (gray - local_mean) / (local_std + 1e-6)
        gray_normalized = gray_normalized * 0.2 + 0.5  # 映射到 [0.3, 0.7]
        gray_normalized = gray_normalized.clamp(0, 1)
        
        # 3. 混合：暗图用归一化版本，亮图用原版
        gray_adaptive = is_dark * gray_normalized + (1 - is_dark) * gray
        
        # 应用所有滤波器
        responses = F.conv2d(gray_adaptive, self.filters, padding=self.filters.shape[-1]//2)
        
        # 计算主方向（取每个位置响应最大的方向）
        responses_reshaped = responses.view(B, self.n_scales, self.n_orientations, H, W)
        
        # 在尺度上求和，然后找最大方向
        orientation_responses = responses_reshaped.sum(dim=1)  # [B, n_orient, H, W]
        orientation_idx = orientation_responses.argmax(dim=1, keepdim=True)  # [B, 1, H, W]
        orientation_map = orientation_idx.float() / self.n_orientations * np.pi
        
        return responses, orientation_map


# ============================================================
# Part 2: Contour Integration (轮廓整合)
# ============================================================

class ContourIntegration(nn.Module):
    """
    轮廓整合模块 - Association Field 理论
    
    理论依据：
    - Field, Hayes & Hess (1993): Association Field
    - 人类视觉系统能将断续边缘整合为连续轮廓
    
    核心思想：
    - 相邻像素如果方向一致，则它们更可能属于同一轮廓
    - 使用方向一致性约束连接断续的地图元素
    """
    
    def __init__(self, 
                 integration_radius: int = 15,
                 n_orientations: int = 8,
                 sigma_space: float = 5.0,
                 sigma_orient: float = 0.3):
        super().__init__()
        
        self.integration_radius = integration_radius
        self.n_orientations = n_orientations
        self.sigma_space = sigma_space
        self.sigma_orient = sigma_orient
        
        # 预计算 Association Field 权重
        self._precompute_association_field()
    
    def _precompute_association_field(self):
        """预计算 Association Field 核"""
        r = self.integration_radius
        size = 2 * r + 1
        
        # 空间距离权重（兼容旧版 PyTorch）
        coords = torch.arange(-r, r + 1, dtype=torch.float32)
        y, x = torch.meshgrid(coords, coords)
        dist = torch.sqrt(x**2 + y**2)
        spatial_weight = torch.exp(-dist**2 / (2 * self.sigma_space**2))
        spatial_weight[r, r] = 0  # 中心点不参与
        
        # 方向一致性权重（连接方向与边缘方向的关系）
        connection_angle = torch.atan2(y, x)  # 连接方向
        
        self.register_buffer('spatial_weight', spatial_weight)
        self.register_buffer('connection_angle', connection_angle)
    
    def forward(self, edge_response: torch.Tensor,
                orientation_map: torch.Tensor) -> torch.Tensor:
        """
        Args:
            edge_response: [B, 1, H, W] 边缘响应强度
            orientation_map: [B, 1, H, W] 边缘方向
        Returns:
            integrated: [B, 1, H, W] 整合后的轮廓图
        """
        B, _, H, W = edge_response.shape
        device = edge_response.device
        
        # 使用可学习的轻量网络近似 Association Field
        # （完整的 Association Field 计算量太大）
        
        # 方向一致性卷积
        # 创建方向敏感的卷积核
        kernels = self._create_orientation_kernels(device)
        
        # 对每个方向分别处理
        integrated = torch.zeros_like(edge_response)
        
        for i, kernel in enumerate(kernels):
            # 计算当前方向的响应
            theta = i * np.pi / self.n_orientations
            
            # 方向差异
            angle_diff = torch.abs(orientation_map - theta)
            angle_diff = torch.min(angle_diff, np.pi - angle_diff)
            
            # 方向一致性权重
            orient_weight = torch.exp(-angle_diff**2 / (2 * self.sigma_orient**2))
            
            # 加权的边缘响应
            weighted_response = edge_response * orient_weight
            
            # 空间整合
            kernel = kernel.unsqueeze(0).unsqueeze(0).to(device)
            integrated_i = F.conv2d(weighted_response, kernel, 
                                    padding=self.integration_radius)
            
            integrated = integrated + integrated_i
        
        # 归一化
        integrated = integrated / self.n_orientations
        
        return integrated
    
    def _create_orientation_kernels(self, device) -> List[torch.Tensor]:
        """创建方向敏感的整合核"""
        kernels = []
        r = self.integration_radius
        size = 2 * r + 1
        
        for i in range(self.n_orientations):
            theta = i * np.pi / self.n_orientations
            
            # 兼容旧版 PyTorch
            coords = torch.arange(-r, r + 1, dtype=torch.float32)
            y, x = torch.meshgrid(coords, coords)
            
            # 沿方向的距离权重
            dist_along = x * np.cos(theta) + y * np.sin(theta)
            dist_perp = -x * np.sin(theta) + y * np.cos(theta)
            
            # Association field: 沿方向扩展，垂直方向衰减
            kernel = torch.exp(-dist_perp**2 / (2 * 2.0**2))
            kernel = kernel * torch.exp(-torch.abs(dist_along) / 10.0)
            kernel[r, r] = 0
            
            # 归一化
            kernel = kernel / (kernel.sum() + 1e-8)
            kernels.append(kernel)
        
        return kernels


# ============================================================
# Part 3: Map Element Prior (地图元素先验)
# ============================================================

class LearnableMapPrior(nn.Module):
    """
    可学习的地图元素先验估计器
    
    解决问题：固定的 Gabor 滤波器在夜间图像上响应弱
    方案：用一个轻量 CNN 学习在各种光照条件下估计地图元素位置
    
    优势：
    1. 可以适应不同光照条件
    2. 端到端可训练
    3. 可以学习更复杂的特征
    """
    
    def __init__(self, in_channels: int = 3, hidden_channels: int = 32):
        super().__init__()
        
        # 轻量编码器
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, 3, padding=1),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, hidden_channels, 3, padding=1, stride=2),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, hidden_channels, 3, padding=1),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
        )
        
        # 先验预测头
        self.prior_head = nn.Sequential(
            nn.Conv2d(hidden_channels, hidden_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False),
            nn.Conv2d(hidden_channels, 1, 1),
            nn.Sigmoid()
        )
        
        # 亮度自适应模块
        self.brightness_adapter = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(hidden_channels, hidden_channels),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_channels, hidden_channels),
            nn.Sigmoid()
        )
    
    def forward(self, img: torch.Tensor) -> torch.Tensor:
        """
        Args:
            img: [B, 3, H, W] 输入图像
        Returns:
            prior: [B, 1, H, W] 地图元素先验图
        """
        # 编码
        feat = self.encoder(img)
        
        # 亮度自适应调制
        brightness_weight = self.brightness_adapter(feat)
        feat = feat * brightness_weight.unsqueeze(-1).unsqueeze(-1)
        
        # 预测先验
        prior = self.prior_head(feat)
        
        return prior


class MapElementPrior(nn.Module):
    """
    地图元素先验模块
    
    基于地图元素的物理特性设计先验约束：
    1. 车道线：高反射率 + 方向连续性
    2. 人行横道：周期性纹理 + 高反射率
    3. 道路边界：边缘连续性
    """
    
    def __init__(self,
                 # 车道线参数
                 lane_reflectance_range: Tuple[float, float] = (0.6, 0.95),
                 # 人行横道参数
                 crosswalk_frequency_range: Tuple[float, float] = (0.05, 0.15),
                 # 道路参数
                 road_reflectance_range: Tuple[float, float] = (0.05, 0.25)):
        super().__init__()
        
        self.lane_reflectance_range = lane_reflectance_range
        self.crosswalk_frequency_range = crosswalk_frequency_range
        self.road_reflectance_range = road_reflectance_range
        
        # 可学习的先验权重
        self.lane_prior_weight = nn.Parameter(torch.tensor(1.0))
        self.crosswalk_prior_weight = nn.Parameter(torch.tensor(1.0))
        self.boundary_prior_weight = nn.Parameter(torch.tensor(1.0))
    
    def compute_lane_prior(self, 
                           gabor_responses: torch.Tensor,
                           orientation_map: torch.Tensor) -> torch.Tensor:
        """
        计算车道线先验
        
        基于：
        1. 强方向性 Gabor 响应
        2. 方向连续性
        """
        B, n_filters, H, W = gabor_responses.shape
        
        # 取最强响应
        max_response, _ = gabor_responses.abs().max(dim=1, keepdim=True)
        
        # 方向一致性（局部方向变化小）
        orient_grad_x = torch.abs(orientation_map[:, :, :, 1:] - orientation_map[:, :, :, :-1])
        orient_grad_y = torch.abs(orientation_map[:, :, 1:, :] - orientation_map[:, :, :-1, :])
        
        # 处理周期性（0 和 π 是相同方向）
        orient_grad_x = torch.min(orient_grad_x, np.pi - orient_grad_x)
        orient_grad_y = torch.min(orient_grad_y, np.pi - orient_grad_y)
        
        orient_consistency = torch.exp(-5 * (
            F.pad(orient_grad_x, (0, 1, 0, 0)) + 
            F.pad(orient_grad_y, (0, 0, 0, 1))
        ))
        
        # 车道线先验 = 强响应 × 方向一致
        lane_prior = max_response * orient_consistency
        
        return lane_prior * self.lane_prior_weight
    
    def compute_crosswalk_prior(self, img: torch.Tensor) -> torch.Tensor:
        """
        计算人行横道先验
        
        基于：
        1. 周期性纹理（傅里叶分析）
        2. 高对比度条纹
        """
        B, C, H, W = img.shape
        
        # 转灰度
        if C == 3:
            gray = 0.299 * img[:, 0] + 0.587 * img[:, 1] + 0.114 * img[:, 2]
        else:
            gray = img.squeeze(1)
        
        # 局部窗口的频率分析
        # 使用简化的方法：检测水平方向的周期性
        
        # 水平方向梯度
        grad_x = gray[:, :, 1:] - gray[:, :, :-1]
        grad_x = F.pad(grad_x, (0, 1, 0, 0))
        
        # 检测周期性变化（交替的正负梯度）
        sign_change = (grad_x[:, :, 1:] * grad_x[:, :, :-1]) < 0
        sign_change = F.pad(sign_change.float(), (0, 1, 0, 0))
        
        # 周期性强度（局部窗口内符号变化的频率）
        kernel_size = 21
        kernel = torch.ones(1, 1, kernel_size, kernel_size, device=img.device)
        kernel = kernel / (kernel_size * kernel_size)
        
        periodicity = F.conv2d(sign_change.unsqueeze(1), kernel, 
                               padding=kernel_size // 2)
        
        # 结合高对比度
        contrast = F.conv2d(torch.abs(grad_x).unsqueeze(1), kernel,
                           padding=kernel_size // 2)
        
        crosswalk_prior = periodicity * contrast
        
        return crosswalk_prior * self.crosswalk_prior_weight
    
    def compute_boundary_prior(self,
                               contour_map: torch.Tensor) -> torch.Tensor:
        """
        计算道路边界先验
        
        基于：
        1. 长连续边缘
        2. 曲率约束（道路边界曲率有限）
        """
        # 边界先验主要来自轮廓整合结果
        return contour_map * self.boundary_prior_weight
    
    def forward(self, 
                img: torch.Tensor,
                gabor_responses: torch.Tensor,
                orientation_map: torch.Tensor,
                contour_map: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        计算所有地图元素先验
        
        Returns:
            priors: 包含各类先验图的字典
        """
        priors = {
            'lane_prior': self.compute_lane_prior(gabor_responses, orientation_map),
            'crosswalk_prior': self.compute_crosswalk_prior(img),
            'boundary_prior': self.compute_boundary_prior(contour_map),
        }
        
        # 合并先验
        combined = priors['lane_prior'] + priors['crosswalk_prior'] + priors['boundary_prior']
        priors['combined_prior'] = combined / 3
        
        return priors


# ============================================================
# Part 4: Reflectance Enhancement (反射率增强)
# ============================================================

class ReflectanceEnhancer(nn.Module):
    """
    反射率增强模块
    
    理论依据：
    - Retinex 理论: I = R × L
    - 地图元素具有高反射率先验
    - 基于 CSF 优化对比度
    """
    
    def __init__(self, n_channels: int = 32):
        super().__init__()
        
        # Retinex 分解网络
        self.encoder = nn.Sequential(
            nn.Conv2d(3, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
        )
        
        # 反射率估计
        self.reflectance_head = nn.Sequential(
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, 3, 3, padding=1),
            nn.Sigmoid()
        )
        
        # 光照估计
        self.illumination_head = nn.Sequential(
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, 1, 3, padding=1),
            nn.Sigmoid()
        )
        
        # 先验引导的增强网络
        self.prior_fusion = nn.Sequential(
            nn.Conv2d(n_channels + 1, n_channels, 3, padding=1),  # +1 for prior
            nn.ReLU(inplace=True),
            nn.Conv2d(n_channels, n_channels, 3, padding=1),
            nn.ReLU(inplace=True),
        )
        
        # 增强输出
        self.enhance_head = nn.Sequential(
            nn.Conv2d(n_channels, 3, 3, padding=1),
            nn.Sigmoid()
        )
    
    def forward(self, 
                img: torch.Tensor,
                map_prior: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Args:
            img: [B, 3, H, W] 输入图像 [0, 1]
            map_prior: [B, 1, H, W] 地图元素先验
        Returns:
            enhanced: [B, 3, H, W] 增强后的图像
            decomposition: 分解结果字典
        """
        # 编码
        feat = self.encoder(img)
        
        # Retinex 分解
        reflectance = self.reflectance_head(feat)
        illumination = self.illumination_head(feat)
        
        # 先验引导增强
        # 在地图元素区域增强反射率
        prior_feat = torch.cat([feat, map_prior], dim=1)
        enhanced_feat = self.prior_fusion(prior_feat)
        
        # 基于先验的选择性增强
        # 地图元素区域：提升到高反射率
        # 非地图元素区域：保持原样
        enhanced_reflectance = self.enhance_head(enhanced_feat)
        
        # 融合：先验区域用增强反射率，其他用原反射率
        alpha = torch.sigmoid(map_prior * 5)  # 软掩码
        final_reflectance = alpha * enhanced_reflectance + (1 - alpha) * reflectance
        
        # 光照校正：提亮暗区但保持对比度
        illumination_corrected = torch.clamp(illumination + 0.3 * (1 - illumination), 0.1, 1.0)
        
        # 重建增强图像
        enhanced = final_reflectance * illumination_corrected
        enhanced = enhanced.clamp(0, 1)
        
        decomposition = {
            'reflectance': reflectance,
            'illumination': illumination,
            'enhanced_reflectance': final_reflectance,
            'illumination_corrected': illumination_corrected,
        }
        
        return enhanced, decomposition


# ============================================================
# Part 5: NIME Main Module (主模块)
# ============================================================

class NIMEEnhancer(nn.Module):
    """
    NIME: Neural-Inspired Map Element Enhancement
    
    完整的地图元素增强管道：
    1. Gabor 滤波器提取方向性特征
    2. 轮廓整合连接断续边缘
    3. 地图元素先验估计
    4. 反射率引导增强
    
    使用方式：
    ```python
    enhancer = NIMEEnhancer()
    enhanced_img = enhancer(low_light_img)
    ```
    """
    
    def __init__(self,
                 # Gabor 参数
                 n_orientations: int = 8,
                 n_scales: int = 4,
                 # 轮廓整合参数
                 integration_radius: int = 15,
                 # 增强参数
                 n_channels: int = 32,
                 # 先验估计器选择
                 use_learnable_prior: bool = True,  # 推荐开启
                 prior_hidden_channels: int = 32):
        super().__init__()
        
        self.use_learnable_prior = use_learnable_prior
        
        # 1. Gabor 滤波器组（带亮度自适应）
        self.gabor_bank = GaborFilterBank(
            n_orientations=n_orientations,
            n_scales=n_scales
        )
        
        # 2. 轮廓整合
        self.contour_integration = ContourIntegration(
            integration_radius=integration_radius,
            n_orientations=n_orientations
        )
        
        # 3. 地图元素先验
        # 可选：使用固定的 Gabor 先验 或 可学习的 CNN 先验
        self.map_prior = MapElementPrior()
        
        if use_learnable_prior:
            # 可学习的先验估计器（解决夜间 Gabor 响应弱的问题）
            self.learnable_prior = LearnableMapPrior(
                in_channels=3, 
                hidden_channels=prior_hidden_channels
            )
        
        # 4. 反射率增强
        self.reflectance_enhancer = ReflectanceEnhancer(n_channels)
        
        # ImageNet 归一化参数
        self.register_buffer('img_mean',
            torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1))
        self.register_buffer('img_std',
            torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1))
    
    def forward(self, 
                img: torch.Tensor,
                return_intermediate: bool = False) -> torch.Tensor:
        """
        Args:
            img: [B, 3, H, W] 输入图像（ImageNet 归一化格式或 [0,1]）
            return_intermediate: 是否返回中间结果（用于可视化）
        Returns:
            enhanced: [B, 3, H, W] 增强后的图像
        """
        # 检测输入格式并转换到 [0, 1]
        if img.min() < 0:  # ImageNet 归一化格式
            img_01 = (img * self.img_std + self.img_mean) / 255.0
            img_01 = img_01.clamp(0, 1)
            need_renorm = True
        else:
            img_01 = img
            need_renorm = False
        
        # 1. Gabor 特征提取（已带亮度自适应预处理）
        gabor_responses, orientation_map = self.gabor_bank(img_01)
        
        # 2. 计算边缘强度
        edge_strength = gabor_responses.abs().max(dim=1, keepdim=True)[0]
        edge_strength = edge_strength / (edge_strength.max() + 1e-8)
        
        # 3. 轮廓整合
        contour_map = self.contour_integration(edge_strength, orientation_map)
        
        # 4. 地图元素先验
        # 传统 Gabor 先验
        priors = self.map_prior(
            img_01, gabor_responses, orientation_map, contour_map
        )
        gabor_prior = priors['combined_prior']
        
        # 5. 融合先验（如果启用可学习先验）
        if self.use_learnable_prior:
            # 可学习先验（在暗图上更准确）
            learned_prior = self.learnable_prior(img_01)
            
            # 自适应融合：暗图更依赖可学习先验，亮图更依赖 Gabor 先验
            mean_brightness = img_01.mean(dim=[1, 2, 3], keepdim=True)
            # 亮度权重：亮度越低，可学习先验权重越高
            learn_weight = (1 - mean_brightness.view(-1, 1, 1, 1)).clamp(0.3, 0.8)
            
            combined_prior = learn_weight * learned_prior + (1 - learn_weight) * gabor_prior
            priors['learned_prior'] = learned_prior
            priors['combined_prior'] = combined_prior
        else:
            combined_prior = gabor_prior
        
        # 6. 反射率增强
        enhanced_01, decomposition = self.reflectance_enhancer(
            img_01, combined_prior
        )
        
        # 转回原格式
        if need_renorm:
            enhanced = (enhanced_01 * 255.0 - self.img_mean) / self.img_std
        else:
            enhanced = enhanced_01
        
        if return_intermediate:
            return enhanced, {
                'gabor_responses': gabor_responses,
                'orientation_map': orientation_map,
                'edge_strength': edge_strength,
                'contour_map': contour_map,
                'priors': priors,
                'decomposition': decomposition
            }
        
        return enhanced


# ============================================================
# Part 6: Training Losses (监督训练损失)
# ============================================================

class RealNightEffects(nn.Module):
    """
    真实夜间场景效果模拟
    
    模拟真实夜间图像特有的元素：
    - 车灯光晕 (Headlight Glare)
    - 路灯反射 (Streetlight Reflection)
    - 霓虹灯/广告牌 (Neon Lights)
    - 交通信号灯光晕
    - 局部高光区域
    """
    
    def __init__(self,
                 # 车灯光晕参数
                 headlight_prob: float = 0.5,
                 headlight_num_range: Tuple[int, int] = (1, 4),
                 headlight_radius_range: Tuple[int, int] = (30, 100),
                 headlight_intensity_range: Tuple[float, float] = (0.3, 0.8),
                 # 路灯参数
                 streetlight_prob: float = 0.4,
                 streetlight_num_range: Tuple[int, int] = (2, 8),
                 # 霓虹灯参数
                 neon_prob: float = 0.3,
                 neon_num_range: Tuple[int, int] = (1, 5),
                 # 光晕/眩光参数
                 lens_flare_prob: float = 0.2):
        super().__init__()
        
        self.headlight_prob = headlight_prob
        self.headlight_num_range = headlight_num_range
        self.headlight_radius_range = headlight_radius_range
        self.headlight_intensity_range = headlight_intensity_range
        
        self.streetlight_prob = streetlight_prob
        self.streetlight_num_range = streetlight_num_range
        
        self.neon_prob = neon_prob
        self.neon_num_range = neon_num_range
        
        self.lens_flare_prob = lens_flare_prob
    
    def _create_gaussian_kernel(self, size: int, sigma: float, 
                                 device: torch.device) -> torch.Tensor:
        """创建高斯核"""
        coords = torch.arange(size, dtype=torch.float32, device=device) - size // 2
        g = torch.exp(-(coords ** 2) / (2 * sigma ** 2))
        kernel = g.unsqueeze(0) * g.unsqueeze(1)
        return kernel / kernel.sum()
    
    def _add_headlight_glare(self, img: torch.Tensor) -> torch.Tensor:
        """
        添加车灯光晕效果
        
        车灯光晕特点：
        - 位于道路上（图像下半部分）
        - 对向车道通常在中间偏左或偏右
        - 成对出现（左右两个车灯）
        - 白色或微黄色
        - 有放射状光芒
        
        固定位置区域：
        - Y: 图像高度的 55%-80%（道路区域）
        - X: 分为左侧车道 (20%-45%) 和右侧车道 (55%-80%)
        """
        B, C, H, W = img.shape
        device = img.device
        
        # 预定义车灯可能出现的位置（模拟对向车道）
        # 每个位置是 (x_ratio, y_ratio) 表示相对位置
        headlight_positions = [
            # 对向车道 - 左侧
            (0.30, 0.65), (0.35, 0.70), (0.28, 0.60),
            # 对向车道 - 右侧  
            (0.70, 0.65), (0.65, 0.70), (0.72, 0.60),
            # 远处车辆（更小更远）
            (0.45, 0.55), (0.55, 0.55),
        ]
        
        for b in range(B):
            if np.random.random() > self.headlight_prob:
                continue
            
            num_lights = np.random.randint(self.headlight_num_range[0], 
                                           self.headlight_num_range[1] + 1)
            
            # 随机选择位置（倾向于成对选择）
            if num_lights >= 2 and np.random.random() < 0.7:
                # 成对出现（同一辆车的左右车灯）
                pair_idx = np.random.choice([0, 3])  # 左侧或右侧车辆
                selected_positions = [
                    headlight_positions[pair_idx],
                    headlight_positions[pair_idx + 1] if pair_idx + 1 < len(headlight_positions) else headlight_positions[pair_idx]
                ]
                # 如果还有更多灯，随机添加
                for _ in range(num_lights - 2):
                    selected_positions.append(headlight_positions[np.random.randint(len(headlight_positions))])
            else:
                selected_positions = [headlight_positions[np.random.randint(len(headlight_positions))] 
                                     for _ in range(num_lights)]
            
            for pos in selected_positions:
                # 在预定义位置附近添加小随机扰动
                cx = int(pos[0] * W + np.random.randint(-30, 30))
                cy = int(pos[1] * H + np.random.randint(-20, 20))
                
                # 确保在有效范围内
                cx = max(50, min(W - 50, cx))
                cy = max(int(H * 0.5), min(int(H * 0.85), cy))
                
                # 大小和强度
                radius = np.random.randint(self.headlight_radius_range[0],
                                          self.headlight_radius_range[1])
                intensity = np.random.uniform(self.headlight_intensity_range[0],
                                             self.headlight_intensity_range[1])
                
                # 创建光晕 mask
                y, x = torch.meshgrid(
                    torch.arange(H, device=device),
                    torch.arange(W, device=device)
                )
                dist = torch.sqrt((x - cx).float() ** 2 + (y - cy).float() ** 2)
                
                # 高斯光晕 + 指数衰减
                glare = torch.exp(-dist / (radius * 0.5)) * intensity
                
                # 添加放射状光芒（6条或8条）
                num_rays = np.random.choice([6, 8])
                angle = torch.atan2((y - cy).float(), (x - cx).float())
                rays = (torch.cos(angle * num_rays) * 0.3 + 0.7)
                glare = glare * rays
                
                # 颜色：白色或微黄（近光灯偏黄，远光灯偏白）
                if np.random.random() < 0.6:
                    color = torch.tensor([1.0, 1.0, np.random.uniform(0.85, 1.0)], 
                                        device=device).view(3, 1, 1)
                else:
                    color = torch.tensor([1.0, 0.95, np.random.uniform(0.7, 0.85)], 
                                        device=device).view(3, 1, 1)
                
                img[b] = img[b] + glare.unsqueeze(0) * color
        
        return img.clamp(0, 1)
    
    def _add_streetlight(self, img: torch.Tensor) -> torch.Tensor:
        """
        添加路灯效果
        
        路灯特点：
        - 位于道路两侧，固定高度
        - 橙黄色（钠灯）或白色（LED）
        - 有向下的光锥照亮路面
        
        固定位置区域：
        - 路灯沿道路两侧排列
        - Y: 图像高度的 15%-35%（灯杆顶部）
        - X: 左侧 (5%-25%) 和 右侧 (75%-95%)
        - 透视效果：越远的灯越靠近中心和上方
        """
        B, C, H, W = img.shape
        device = img.device
        
        # 预定义路灯位置（模拟道路两侧等距排列）
        # (x_ratio, y_ratio, size_scale) - size_scale 模拟透视（远小近大）
        streetlight_positions = [
            # 左侧路灯（从近到远）
            (0.08, 0.35, 1.0),   # 最近
            (0.12, 0.28, 0.8),
            (0.18, 0.22, 0.6),
            (0.25, 0.18, 0.4),   # 最远
            # 右侧路灯（从近到远）
            (0.92, 0.35, 1.0),   # 最近
            (0.88, 0.28, 0.8),
            (0.82, 0.22, 0.6),
            (0.75, 0.18, 0.4),   # 最远
        ]
        
        for b in range(B):
            if np.random.random() > self.streetlight_prob:
                continue
            
            num_lights = np.random.randint(self.streetlight_num_range[0],
                                          self.streetlight_num_range[1] + 1)
            
            # 随机选择路灯（但保持透视合理性）
            selected_positions = []
            available_left = [p for p in streetlight_positions if p[0] < 0.5]
            available_right = [p for p in streetlight_positions if p[0] > 0.5]
            
            for i in range(num_lights):
                # 交替选择左右两侧
                if i % 2 == 0 and available_left:
                    pos = available_left[np.random.randint(len(available_left))]
                elif available_right:
                    pos = available_right[np.random.randint(len(available_right))]
                elif available_left:
                    pos = available_left[np.random.randint(len(available_left))]
                else:
                    continue
                selected_positions.append(pos)
            
            for pos in selected_positions:
                # 位置加小扰动
                cx = int(pos[0] * W + np.random.randint(-10, 10))
                cy = int(pos[1] * H + np.random.randint(-5, 5))
                size_scale = pos[2]
                
                # 光源大小随距离变化
                radius = int(np.random.randint(15, 25) * size_scale)
                intensity = np.random.uniform(0.6, 1.0) * size_scale
                
                y, x = torch.meshgrid(
                    torch.arange(H, device=device),
                    torch.arange(W, device=device)
                )
                
                # 光源
                dist = torch.sqrt((x - cx).float() ** 2 + (y - cy).float() ** 2)
                light_source = torch.exp(-dist ** 2 / (2 * radius ** 2)) * intensity
                
                # 向下的光锥（照亮路面）
                cone_mask = (y > cy).float()
                cone_width = (y - cy).float().clamp(min=1) * (0.3 + 0.2 * size_scale)
                cone = torch.exp(-((x - cx).float() ** 2) / (2 * cone_width ** 2))
                cone = cone * cone_mask * 0.25 * size_scale
                
                glare = light_source + cone
                
                # 颜色：橙黄色（钠灯，老式）或白色（LED，新式）
                if np.random.random() < 0.5:  # 钠灯 - 橙黄色
                    color = torch.tensor([1.0, 0.7, 0.3], device=device).view(3, 1, 1)
                else:  # LED - 冷白色
                    color = torch.tensor([0.95, 0.95, 1.0], device=device).view(3, 1, 1)
                
                img[b] = img[b] + glare.unsqueeze(0) * color * 0.35
        
        return img.clamp(0, 1)
    
    def _add_neon_lights(self, img: torch.Tensor) -> torch.Tensor:
        """
        添加霓虹灯/广告牌效果
        
        特点：
        - 位于建筑物上（道路两侧）
        - 彩色光源（红、蓝、绿等）
        - 矩形形状（广告牌）
        - 有发光晕染
        
        固定位置区域：
        - 左侧建筑: X 0%-30%, Y 10%-45%
        - 右侧建筑: X 70%-100%, Y 10%-45%
        - 不会出现在道路中央上方（那是天空）
        """
        B, C, H, W = img.shape
        device = img.device
        
        # 预定义霓虹灯/广告牌位置（建筑物立面）
        # (x_ratio, y_ratio, w_scale, h_scale)
        neon_positions = [
            # 左侧建筑
            (0.08, 0.20, 1.0, 0.8),   # 左上
            (0.15, 0.30, 0.8, 1.0),   # 左中
            (0.05, 0.40, 0.6, 0.6),   # 左下
            (0.20, 0.15, 0.7, 0.5),   # 左上远
            # 右侧建筑  
            (0.92, 0.20, 1.0, 0.8),   # 右上
            (0.85, 0.30, 0.8, 1.0),   # 右中
            (0.95, 0.40, 0.6, 0.6),   # 右下
            (0.80, 0.15, 0.7, 0.5),   # 右上远
        ]
        
        for b in range(B):
            if np.random.random() > self.neon_prob:
                continue
            
            num_neons = np.random.randint(self.neon_num_range[0],
                                         self.neon_num_range[1] + 1)
            
            # 随机选择位置
            selected_positions = [neon_positions[np.random.randint(len(neon_positions))] 
                                 for _ in range(num_neons)]
            
            for pos in selected_positions:
                # 位置加小扰动
                cx = int(pos[0] * W + np.random.randint(-20, 20))
                cy = int(pos[1] * H + np.random.randint(-15, 15))
                
                # 确保在合理范围
                if pos[0] < 0.5:  # 左侧
                    cx = max(20, min(int(W * 0.35), cx))
                else:  # 右侧
                    cx = max(int(W * 0.65), min(W - 20, cx))
                cy = max(int(H * 0.08), min(int(H * 0.50), cy))
                
                # 大小
                base_w = np.random.randint(30, 80)
                base_h = np.random.randint(15, 45)
                w = int(base_w * pos[2])
                h = int(base_h * pos[3])
                
                y, x = torch.meshgrid(
                    torch.arange(H, device=device),
                    torch.arange(W, device=device)
                )
                
                # 矩形区域 + 发光晕染
                in_rect = ((x >= cx - w//2) & (x <= cx + w//2) & 
                          (y >= cy - h//2) & (y <= cy + h//2)).float()
                
                # 高斯晕染
                dist_x = torch.abs(x - cx).float() / (w * 1.2)
                dist_y = torch.abs(y - cy).float() / (h * 1.2)
                glow = torch.exp(-(dist_x ** 2 + dist_y ** 2))
                
                neon = in_rect * 0.7 + glow * 0.4
                
                # 随机颜色（常见广告牌颜色）
                colors = [
                    [1.0, 0.2, 0.2],   # 红（常见）
                    [0.2, 0.4, 1.0],   # 蓝（常见）
                    [0.2, 1.0, 0.3],   # 绿
                    [1.0, 0.8, 0.2],   # 黄/金色
                    [1.0, 0.4, 0.7],   # 粉红
                    [0.9, 0.9, 0.9],   # 白色
                ]
                # 红色和蓝色更常见
                weights = [0.25, 0.25, 0.15, 0.15, 0.1, 0.1]
                color_idx = np.random.choice(len(colors), p=weights)
                color = torch.tensor(colors[color_idx], device=device).view(3, 1, 1)
                
                intensity = np.random.uniform(0.25, 0.5)
                img[b] = img[b] + neon.unsqueeze(0) * color * intensity
        
        return img.clamp(0, 1)
    
    def _add_lens_flare(self, img: torch.Tensor) -> torch.Tensor:
        """
        添加镜头眩光效果
        
        当强光源直射镜头时产生的光学伪影
        """
        B, C, H, W = img.shape
        device = img.device
        
        for b in range(B):
            if np.random.random() > self.lens_flare_prob:
                continue
            
            # 光源位置
            cx = np.random.randint(W // 4, 3 * W // 4)
            cy = np.random.randint(H // 4, 3 * H // 4)
            
            y, x = torch.meshgrid(
                torch.arange(H, device=device),
                torch.arange(W, device=device)
            )
            
            # 主光晕
            dist = torch.sqrt((x - cx).float() ** 2 + (y - cy).float() ** 2)
            main_flare = torch.exp(-dist / 100) * 0.3
            
            # 次级光斑（镜头反射）
            for i in range(3):
                # 沿对角线方向
                offset = (i + 1) * 50
                fx = int(cx + offset * np.cos(np.pi / 4))
                fy = int(cy + offset * np.sin(np.pi / 4))
                
                if 0 <= fx < W and 0 <= fy < H:
                    dist_f = torch.sqrt((x - fx).float() ** 2 + (y - fy).float() ** 2)
                    secondary = torch.exp(-dist_f ** 2 / (20 ** 2)) * 0.1
                    main_flare = main_flare + secondary
            
            # 彩色边缘（色散）
            r_offset = 3
            img[b, 0] = img[b, 0] + torch.roll(main_flare, r_offset, dims=1)
            img[b, 1] = img[b, 1] + main_flare
            img[b, 2] = img[b, 2] + torch.roll(main_flare, -r_offset, dims=1)
        
        return img.clamp(0, 1)
    
    def forward(self, img: torch.Tensor) -> torch.Tensor:
        """
        应用所有夜间效果
        """
        img = self._add_streetlight(img)
        img = self._add_headlight_glare(img)
        img = self._add_neon_lights(img)
        img = self._add_lens_flare(img)
        return img


class LightDegradation(nn.Module):
    """
    光照退化模块 - 基于 LightDiff 的真实相机成像管道 + 真实夜间效果
    
    参考: LightDiff (https://github.com/jinlong17/LightDiff)
    
    模拟真实的低光照图像生成过程：
    1. Unprocess (RGB → RAW): 逆色调映射、逆Gamma、逆白平衡
    2. Low Light Corruption: 暗度降低、shot/read噪声
    3. ISP (RAW → RGB): 量化、白平衡、Gamma校正
    4. Real Night Effects: 车灯光晕、路灯、霓虹灯等
    """
    
    def __init__(self,
                 # 暗度参数
                 darkness_range: Tuple[float, float] = (0.01, 1.0),
                 darkness_mu: float = 0.1,
                 darkness_sigma: float = 0.08,
                 # Gamma 参数
                 gamma_range: Tuple[float, float] = (2.0, 3.5),
                 # 白平衡参数
                 red_gain_range: Tuple[float, float] = (1.9, 2.4),
                 blue_gain_range: Tuple[float, float] = (1.5, 1.9),
                 rgb_gain_mu: float = 0.8,
                 rgb_gain_sigma: float = 0.1,
                 # 量化参数
                 quantization_bits: List[int] = [12, 14, 16],
                 # 真实夜间效果开关
                 enable_real_night_effects: bool = True,
                 headlight_prob: float = 0.5,
                 streetlight_prob: float = 0.4,
                 neon_prob: float = 0.3,
                 lens_flare_prob: float = 0.2):
        super().__init__()
        
        self.darkness_range = darkness_range
        self.darkness_mu = darkness_mu
        self.darkness_sigma = darkness_sigma
        self.gamma_range = gamma_range
        self.red_gain_range = red_gain_range
        self.blue_gain_range = blue_gain_range
        self.rgb_gain_mu = rgb_gain_mu
        self.rgb_gain_sigma = rgb_gain_sigma
        self.quantization_bits = quantization_bits
        
        # 真实夜间效果模块
        self.enable_real_night_effects = enable_real_night_effects
        if enable_real_night_effects:
            self.night_effects = RealNightEffects(
                headlight_prob=headlight_prob,
                streetlight_prob=streetlight_prob,
                neon_prob=neon_prob,
                lens_flare_prob=lens_flare_prob
            )
        
        # 相机色彩矩阵 (CCM) - 不同相机的特性
        self.xyz2cams = [
            [[1.0234, -0.2969, -0.2266],
             [-0.5625, 1.6328, -0.0469],
             [-0.0703, 0.2188, 0.6406]],
            [[0.4913, -0.0541, -0.0202],
             [-0.613, 1.3513, 0.2906],
             [-0.1564, 0.2151, 0.7183]],
            [[0.838, -0.263, -0.0639],
             [-0.2887, 1.0725, 0.2496],
             [-0.0627, 0.1427, 0.5438]],
            [[0.6596, -0.2079, -0.0562],
             [-0.4782, 1.3016, 0.1933],
             [-0.097, 0.1581, 0.5181]]
        ]
        
        # RGB to XYZ 转换矩阵
        self.rgb2xyz = [[0.4124564, 0.3575761, 0.1804375],
                        [0.2126729, 0.7151522, 0.0721750],
                        [0.0193339, 0.1191920, 0.9503041]]
    
    def _apply_ccm(self, image: torch.Tensor, ccm: torch.Tensor) -> torch.Tensor:
        """应用色彩校正矩阵"""
        shape = image.shape
        image = image.reshape(-1, 3)
        image = torch.tensordot(image, ccm, dims=[[-1], [-1]])
        return image.reshape(shape)
    
    def _random_noise_levels(self) -> Tuple[float, float]:
        """生成随机的 shot noise 和 read noise"""
        log_min_shot = np.log(0.0001)
        log_max_shot = np.log(0.012)
        
        log_shot_noise = np.random.uniform(log_min_shot, log_max_shot)
        shot_noise = np.exp(log_shot_noise)
        
        # Read noise 与 shot noise 的线性关系
        log_read_noise = 2.18 * log_shot_noise + 1.20 + np.random.normal(scale=0.26)
        read_noise = np.exp(log_read_noise)
        
        return shot_noise, read_noise
    
    def _truncated_normal(self, lower: float, upper: float, 
                          mu: float, sigma: float) -> float:
        """生成截断正态分布的随机数"""
        from scipy import stats
        a = (lower - mu) / sigma
        b = (upper - mu) / sigma
        return stats.truncnorm(a, b, loc=mu, scale=sigma).rvs()
    
    def forward(self, img: torch.Tensor) -> torch.Tensor:
        """
        Args:
            img: [B, C, H, W] 白天图像 [0, 1]
        Returns:
            degraded: [B, C, H, W] 退化后的低光照图像
        """
        # 确保输入是 4D，处理 5D/6D 输入
        orig_shape = img.shape
        reshape_back = False
        
        if img.dim() == 6:
            # [B, T, num_cams, C, H, W] → [B*T*num_cams, C, H, W]
            B_orig, T, num_cams, C, H, W = orig_shape
            img = img.view(B_orig * T * num_cams, C, H, W)
            reshape_back = True
        elif img.dim() == 5:
            # [B, num_cams, C, H, W] → [B*num_cams, C, H, W]
            B_orig, num_cams, C, H, W = orig_shape
            img = img.view(B_orig * num_cams, C, H, W)
            reshape_back = True
        
        B, C, H, W = img.shape
        device = img.device
        epsilon = 1e-8
        
        # 对每张图像独立处理
        degraded_batch = []
        
        for b in range(B):
            img_single = img[b]  # [C, H, W]
            img_hwc = img_single.permute(1, 2, 0)  # [H, W, C]
            
            # ============================================
            # Stage 1: Unprocess (RGB → RAW)
            # ============================================
            
            # 1. 逆色调映射
            img1 = 0.5 - torch.sin(torch.asin(1.0 - 2.0 * img_hwc.clamp(0.001, 0.999)) / 3.0)
            
            # 2. 逆 Gamma
            gamma = np.random.uniform(self.gamma_range[0], self.gamma_range[1])
            img2 = torch.max(img1, torch.tensor(epsilon, device=device)) ** gamma
            
            # 3. sRGB → cRGB (相机色彩空间)
            xyz2cam = self.xyz2cams[np.random.randint(len(self.xyz2cams))]
            rgb2cam = np.matmul(xyz2cam, self.rgb2xyz)
            rgb2cam = rgb2cam / np.sum(rgb2cam, axis=-1, keepdims=True)
            rgb2cam = torch.from_numpy(rgb2cam).float().to(device)
            img3 = self._apply_ccm(img2, rgb2cam)
            img3 = img3.clamp(0, 1)
            
            # 4. 逆白平衡
            rgb_gain = np.random.normal(self.rgb_gain_mu, self.rgb_gain_sigma)
            red_gain = np.random.uniform(self.red_gain_range[0], self.red_gain_range[1])
            blue_gain = np.random.uniform(self.blue_gain_range[0], self.blue_gain_range[1])
            
            gains1 = torch.tensor([1.0/red_gain, 1.0, 1.0/blue_gain], device=device) * rgb_gain
            gains1 = gains1.view(1, 1, 3)
            img4 = img3 * gains1
            
            # ============================================
            # Stage 2: Low Light Corruption
            # ============================================
            
            # 5. 暗度降低 (truncated normal distribution)
            try:
                darkness = self._truncated_normal(
                    self.darkness_range[0], self.darkness_range[1],
                    self.darkness_mu, self.darkness_sigma
                )
            except:
                darkness = np.random.uniform(0.05, 0.3)
            
            img5 = img4 * darkness
            
            # 6. 添加 shot noise + read noise
            shot_noise, read_noise = self._random_noise_levels()
            variance = img5 * shot_noise + read_noise
            variance = torch.max(variance, torch.tensor(epsilon, device=device))
            noise = torch.randn_like(img5) * torch.sqrt(variance)
            img6 = img5 + noise
            
            # ============================================
            # Stage 3: ISP (RAW → RGB)
            # ============================================
            
            # 7. 量化噪声
            bits = np.random.choice(self.quantization_bits)
            quan_noise = torch.empty_like(img6).uniform_(-1/(255*bits), 1/(255*bits))
            img7 = img6 + quan_noise
            
            # 8. 白平衡
            gains2 = torch.tensor([red_gain, 1.0, blue_gain], device=device)
            gains2 = gains2.view(1, 1, 3)
            img8 = img7 * gains2
            
            # 9. cRGB → sRGB
            cam2rgb = torch.inverse(rgb2cam)
            img9 = self._apply_ccm(img8, cam2rgb)
            
            # 10. Gamma 校正
            img10 = torch.max(img9, torch.tensor(epsilon, device=device)) ** (1/gamma)
            
            # 转回 [C, H, W]
            img_out = img10.permute(2, 0, 1)
            degraded_batch.append(img_out)
        
        degraded = torch.stack(degraded_batch, dim=0)
        degraded = degraded.clamp(0, 1)
        
        # ============================================
        # Stage 4: Real Night Effects (可选)
        # ============================================
        if self.enable_real_night_effects and self.training:
            degraded = self.night_effects(degraded)
        
        # 如果输入是 5D，恢复原始形状
        if reshape_back and orig_shape is not None:
            degraded = degraded.view(orig_shape)
        
        return degraded


class NIMELoss(nn.Module):
    """
    NIME 监督训练损失
    
    训练流程：
    1. 白天图像 (GT) → 人工退化 → 夜间图像 (Input)
    2. NIME(夜间图像) → 增强图像 (Output)
    3. Loss = |Output - GT| + 辅助损失
    """
    
    def __init__(self,
                 # 主损失权重
                 reconstruction_weight: float = 1.0,
                 perceptual_weight: float = 0.1,
                 # 辅助损失权重
                 ssim_weight: float = 0.5,
                 gradient_weight: float = 0.2,
                 # 地图先验损失权重
                 map_prior_weight: float = 0.3,
                 # 退化参数（LightDiff 风格）
                 darkness_range: Tuple[float, float] = (0.01, 1.0)):
        super().__init__()
        
        self.reconstruction_weight = reconstruction_weight
        self.perceptual_weight = perceptual_weight
        self.ssim_weight = ssim_weight
        self.gradient_weight = gradient_weight
        self.map_prior_weight = map_prior_weight
        
        # 光照退化模块（新版本使用 LightDiff 风格噪声模型）
        self.degradation = LightDegradation(
            darkness_range=darkness_range
        )
    
    def forward(self,
                img_gt: torch.Tensor,
                enhanced: torch.Tensor,
                decomposition: Dict[str, torch.Tensor],
                priors: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        计算监督训练损失
        
        Args:
            img_gt: 白天图像 (Ground Truth) [B, 3, H, W]
            enhanced: 增强后的图像 [B, 3, H, W]
            decomposition: Retinex 分解结果
            priors: 地图元素先验
        """
        losses = {}
        
        # ==========================================
        # 1. 主损失：增强图像 vs GT
        # ==========================================
        
        # L1 重建损失
        loss_recon = F.l1_loss(enhanced, img_gt)
        losses['loss_recon'] = loss_recon * self.reconstruction_weight
        
        # SSIM 损失（结构相似性）
        loss_ssim = 1 - self._compute_ssim(enhanced, img_gt)
        losses['loss_ssim'] = loss_ssim * self.ssim_weight
        
        # 梯度损失（边缘保持）
        loss_grad = self._gradient_loss(enhanced, img_gt)
        losses['loss_gradient'] = loss_grad * self.gradient_weight
        
        # ==========================================
        # 2. 地图先验损失：地图区域增强更多
        # ==========================================
        map_prior = priors['combined_prior']
        
        # 在地图区域，增强后应该更接近 GT
        map_region = (map_prior > 0.3).float()
        loss_map = (map_region * (enhanced - img_gt).abs()).sum() / (map_region.sum() + 1e-8)
        losses['loss_map_prior'] = loss_map * self.map_prior_weight
        
        # ==========================================
        # 3. 辅助损失：Retinex 约束
        # ==========================================
        reflectance = decomposition['reflectance']
        illumination = decomposition['illumination']
        
        # 反射率平滑（边缘感知）
        img_grad = self._compute_gradient(img_gt)
        ref_grad = self._compute_gradient(reflectance)
        weight = torch.exp(-10 * img_grad)
        loss_ref_smooth = (weight * ref_grad).mean()
        losses['loss_ref_smooth'] = loss_ref_smooth * 0.1
        
        # 光照平滑
        illu_grad = self._compute_gradient(illumination)
        losses['loss_illu_smooth'] = illu_grad.mean() * 0.1
        
        # ==========================================
        # 总损失
        # ==========================================
        losses['loss_total'] = sum(v for k, v in losses.items() if k != 'loss_total')
        
        return losses
    
    def _compute_gradient(self, x: torch.Tensor) -> torch.Tensor:
        """计算图像梯度幅度"""
        grad_x = torch.abs(x[:, :, :, 1:] - x[:, :, :, :-1])
        grad_y = torch.abs(x[:, :, 1:, :] - x[:, :, :-1, :])
        grad_x = F.pad(grad_x, (0, 1, 0, 0))
        grad_y = F.pad(grad_y, (0, 0, 0, 1))
        return (grad_x + grad_y) / 2
    
    def _gradient_loss(self, pred: torch.Tensor, gt: torch.Tensor) -> torch.Tensor:
        """梯度损失 - 保持边缘"""
        pred_grad = self._compute_gradient(pred)
        gt_grad = self._compute_gradient(gt)
        return F.l1_loss(pred_grad, gt_grad)
    
    def _compute_ssim(self, pred: torch.Tensor, gt: torch.Tensor, 
                      window_size: int = 11) -> torch.Tensor:
        """计算 SSIM"""
        C1 = 0.01 ** 2
        C2 = 0.03 ** 2
        
        # 创建高斯窗口
        sigma = 1.5
        coords = torch.arange(window_size, dtype=torch.float32, device=pred.device) - window_size // 2
        g = torch.exp(-(coords ** 2) / (2 * sigma ** 2))
        g = g / g.sum()
        window = g.unsqueeze(0) * g.unsqueeze(1)
        window = window.unsqueeze(0).unsqueeze(0)
        window = window.expand(pred.size(1), 1, window_size, window_size)
        
        # 计算均值
        mu_pred = F.conv2d(pred, window, padding=window_size//2, groups=pred.size(1))
        mu_gt = F.conv2d(gt, window, padding=window_size//2, groups=gt.size(1))
        
        mu_pred_sq = mu_pred ** 2
        mu_gt_sq = mu_gt ** 2
        mu_pred_gt = mu_pred * mu_gt
        
        # 计算方差和协方差
        sigma_pred_sq = F.conv2d(pred ** 2, window, padding=window_size//2, groups=pred.size(1)) - mu_pred_sq
        sigma_gt_sq = F.conv2d(gt ** 2, window, padding=window_size//2, groups=gt.size(1)) - mu_gt_sq
        sigma_pred_gt = F.conv2d(pred * gt, window, padding=window_size//2, groups=pred.size(1)) - mu_pred_gt
        
        # SSIM
        ssim = ((2 * mu_pred_gt + C1) * (2 * sigma_pred_gt + C2)) / \
               ((mu_pred_sq + mu_gt_sq + C1) * (sigma_pred_sq + sigma_gt_sq + C2))
        
        return ssim.mean()


# ============================================================
# Part 7: MapTR Integration (与 MapTR 集成)
# ============================================================

class NIMEMapTREnhancer(nn.Module):
    """
    专门用于 MapTR 的 NIME 增强器封装
    """
    
    def __init__(self,
                 pretrained: str = None,
                 freeze: bool = False,
                 **kwargs):
        super().__init__()
        
        self.enhancer = NIMEEnhancer(**kwargs)
        self.freeze = freeze
        
        if pretrained is not None:
            self._load_pretrained(pretrained)
        
        if freeze:
            for param in self.enhancer.parameters():
                param.requires_grad = False
    
    def _load_pretrained(self, path: str):
        """加载预训练权重"""
        state_dict = torch.load(path, map_location='cpu')
        if 'state_dict' in state_dict:
            state_dict = state_dict['state_dict']
        self.enhancer.load_state_dict(state_dict, strict=False)
        print(f"Loaded NIME pretrained weights from {path}")
    
    def forward(self, img: torch.Tensor) -> torch.Tensor:
        """
        Args:
            img: MapTR 格式的输入图像
        Returns:
            enhanced: 增强后的图像
        """
        if self.freeze:
            with torch.no_grad():
                return self.enhancer(img)
        return self.enhancer(img)
