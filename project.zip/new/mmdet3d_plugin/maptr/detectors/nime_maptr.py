"""
NIME-MapTR: Neural-Inspired Map Element Enhancement for MapTR
=============================================================

将 NIME 增强器集成到 MapTR 的完整检测器
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import force_fp32
from mmdet.models import DETECTORS

from .maptr import MapTR

try:
    from ...models.enhancers.nime_enhancer import (
        NIMEEnhancer, NIMELoss, NIMEMapTREnhancer
    )
except ImportError:
    NIMEEnhancer = None
    NIMELoss = None
    NIMEMapTREnhancer = None


@DETECTORS.register_module()
class NIMEMapTR(MapTR):
    """
    NIME + MapTR 集成
    
    使用方式：
    1. 预训练 NIME 增强器
    2. 加载预训练权重，冻结增强器
    3. 微调 MapTR 检测头
    
    或者端到端联合训练
    """
    
    def __init__(self,
                 # NIME 参数
                 use_nime: bool = True,
                 nime_pretrained: str = None,
                 nime_freeze: bool = True,
                 nime_n_orientations: int = 8,
                 nime_n_scales: int = 4,
                 nime_integration_radius: int = 15,
                 nime_n_channels: int = 32,
                 # MapTR 原有参数
                 **kwargs):
        super().__init__(**kwargs)
        
        self.use_nime = use_nime
        
        if use_nime and NIMEEnhancer is not None:
            self.nime_enhancer = NIMEMapTREnhancer(
                pretrained=nime_pretrained,
                freeze=nime_freeze,
                n_orientations=nime_n_orientations,
                n_scales=nime_n_scales,
                integration_radius=nime_integration_radius,
                n_channels=nime_n_channels,
            )
            print(f"NIME Enhancer initialized (freeze={nime_freeze})")
        else:
            self.nime_enhancer = None
            if use_nime:
                print("Warning: NIMEEnhancer not available, skipping enhancement")
    
    def extract_img_feat(self, img, img_metas):
        """
        提取图像特征（在 backbone 之前进行增强）
        """
        # 应用 NIME 增强
        if self.use_nime and self.nime_enhancer is not None:
            B = img.size(0)
            
            # img: [B, num_cams, C, H, W]
            if img.dim() == 5:
                num_cams = img.size(1)
                # 展平为 [B*num_cams, C, H, W]
                img_flat = img.view(B * num_cams, *img.shape[2:])
                enhanced_flat = self.nime_enhancer(img_flat)
                img = enhanced_flat.view(B, num_cams, *enhanced_flat.shape[1:])
            else:
                img = self.nime_enhancer(img)
        
        # 调用父类方法
        return super().extract_img_feat(img, img_metas)
    
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      prev_bev=None):
        """
        训练前向传播
        """
        # 直接调用父类
        return super().forward_train(
            points=points,
            img_metas=img_metas,
            gt_bboxes_3d=gt_bboxes_3d,
            gt_labels_3d=gt_labels_3d,
            gt_labels=gt_labels,
            gt_bboxes=gt_bboxes,
            img=img,
            proposals=proposals,
            gt_bboxes_ignore=gt_bboxes_ignore,
            img_depth=img_depth,
            img_mask=img_mask,
            prev_bev=prev_bev,
        )
    
    def simple_test(self, img_metas, img=None, points=None, prev_bev=None, rescale=False):
        """
        推理
        """
        return super().simple_test(
            img_metas=img_metas,
            img=img,
            points=points,
            prev_bev=prev_bev,
            rescale=rescale
        )


# ============================================================
# NIME 独立预训练模块
# ============================================================

@DETECTORS.register_module()
class NIMEPretrainer(nn.Module):
    """
    NIME 预训练器 (监督学习版本)
    
    训练流程：
    1. 白天图像 (GT) → 人工退化 → 夜间图像 (Input)
    2. NIME(夜间图像) → 增强图像 (Output)
    3. Loss = |Output - GT| + 辅助损失
    """
    
    def __init__(self,
                 # NIME 参数
                 n_orientations: int = 8,
                 n_scales: int = 4,
                 integration_radius: int = 15,
                 n_channels: int = 32,
                 # Loss 权重
                 reconstruction_weight: float = 1.0,
                 ssim_weight: float = 0.5,
                 gradient_weight: float = 0.2,
                 map_prior_weight: float = 0.3,
                 # 退化参数（LightDiff 风格，使用 shot + read noise）
                 darkness_range: tuple = (0.01, 1.0),
                 # 真实夜间效果参数
                 enable_real_night_effects: bool = True,
                 headlight_prob: float = 0.5,
                 streetlight_prob: float = 0.4,
                 neon_prob: float = 0.3,
                 lens_flare_prob: float = 0.2,
                 # mmdet 必需参数（不使用但需要接受）
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 init_cfg=None):
        super().__init__()
        
        assert NIMEEnhancer is not None, "NIME modules not imported"
        
        # 增强器
        self.enhancer = NIMEEnhancer(
            n_orientations=n_orientations,
            n_scales=n_scales,
            integration_radius=integration_radius,
            n_channels=n_channels,
        )
        
        # 退化模块（支持真实夜间效果）
        from ...models.enhancers.nime_enhancer import LightDegradation
        self.degradation = LightDegradation(
            darkness_range=darkness_range,
            enable_real_night_effects=enable_real_night_effects,
            headlight_prob=headlight_prob,
            streetlight_prob=streetlight_prob,
            neon_prob=neon_prob,
            lens_flare_prob=lens_flare_prob,
        )
        
        # 损失函数（监督学习）
        self.loss_fn = NIMELoss(
            reconstruction_weight=reconstruction_weight,
            ssim_weight=ssim_weight,
            gradient_weight=gradient_weight,
            map_prior_weight=map_prior_weight,
        )
        # 共享退化模块
        self.loss_fn.degradation = self.degradation
        
        # ImageNet 归一化参数
        self.register_buffer('img_mean',
            torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1))
        self.register_buffer('img_std',
            torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1))
    
    def init_weights(self):
        """初始化权重（mmdet 训练器需要调用此方法）"""
        # 使用默认初始化，不做特殊处理
        pass
    
    def forward(self, img, img_metas=None, return_loss=True, **kwargs):
        """
        前向传播
        
        Args:
            img: [B, num_cams, C, H, W] 或 [B, C, H, W]
        """
        if return_loss:
            return self.forward_train(img, img_metas, **kwargs)
        else:
            return self.forward_test(img, img_metas, **kwargs)
    
    def forward_train(self, img, img_metas=None, **kwargs):
        """
        监督训练前向传播
        
        流程：
        1. 白天图像 → 人工退化 → 夜间图像
        2. NIME(夜间图像) → 增强图像
        3. Loss = |增强图像 - 白天图像|
        """
        # 处理多相机/时序输入，展平为 4D [N, C, H, W]
        # 输入可能是：
        # - 4D: [B, C, H, W]
        # - 5D: [B, num_cams, C, H, W]
        # - 6D: [B, queue_length, num_cams, C, H, W]
        if img.dim() == 6:
            # [B, queue_length, num_cams, C, H, W] → [B*queue_length*num_cams, C, H, W]
            B, T, num_cams, C, H, W = img.shape
            img = img.view(B * T * num_cams, C, H, W)
        elif img.dim() == 5:
            # [B, num_cams, C, H, W] → [B*num_cams, C, H, W]
            B, num_cams, C, H, W = img.shape
            img = img.view(B * num_cams, C, H, W)
        
        # 确保是 4D
        assert img.dim() == 4, f"Expected 4D tensor, got {img.dim()}D with shape {img.shape}"
        
        # 转换到 [0, 1] - 这是白天图像 (GT)
        # ImageNet 反归一化: img_original = img_normalized * std + mean
        img_gt = (img * self.img_std + self.img_mean) / 255.0
        img_gt = img_gt.clamp(0, 1)
        
        # Step 1: 人工退化 → 生成夜间图像
        img_degraded = self.loss_fn.degradation(img_gt)
        
        # Step 2: NIME 增强 → 恢复白天图像
        enhanced, intermediate = self.enhancer(img_degraded, return_intermediate=True)
        
        # Step 3: 计算监督损失 (增强图像 vs 白天GT)
        losses = self.loss_fn(
            img_gt,        # Ground Truth (白天图像)
            enhanced,      # 增强后的图像
            intermediate['decomposition'],
            intermediate['priors']
        )
        
        # 格式化损失
        formatted_losses = {}
        for k, v in losses.items():
            if k == 'loss_total':
                formatted_losses['loss'] = v
            else:
                formatted_losses[f'nime/{k}'] = v
        
        return formatted_losses
    
    def forward_test(self, img, img_metas=None, **kwargs):
        """测试前向传播"""
        if img.dim() == 5:
            B, num_cams, C, H, W = img.shape
            img_flat = img.view(B * num_cams, C, H, W)
        else:
            img_flat = img
            B = img.size(0)
            num_cams = 1
        
        # 增强
        enhanced = self.enhancer(img_flat)
        
        if img.dim() == 5:
            enhanced = enhanced.view(B, num_cams, *enhanced.shape[1:])
        
        return enhanced
    
    def train_step(self, data, optimizer):
        """训练步骤"""
        losses = self.forward(**data, return_loss=True)
        loss, log_vars = self._parse_losses(losses)
        outputs = dict(loss=loss, log_vars=log_vars, num_samples=len(data['img']))
        return outputs
    
    def val_step(self, data, optimizer=None):
        """验证步骤"""
        losses = self.forward(**data, return_loss=True)
        loss, log_vars = self._parse_losses(losses)
        outputs = dict(loss=loss, log_vars=log_vars, num_samples=len(data['img']))
        return outputs
    
    def _parse_losses(self, losses):
        """解析损失"""
        log_vars = dict()
        for name, value in losses.items():
            if isinstance(value, torch.Tensor):
                log_vars[name] = value.mean()
            elif isinstance(value, list):
                log_vars[name] = sum(_loss.mean() for _loss in value)
            else:
                raise TypeError(f'{name} is not a tensor or list of tensors')
        
        loss = sum(_value for _key, _value in log_vars.items()
                   if 'loss' in _key and 'nime/' not in _key)
        
        log_vars['loss'] = loss
        for name in log_vars:
            log_vars[name] = log_vars[name].item()
        
        return loss, log_vars


# ============================================================
# NIME 联合训练版本（推荐）
# ============================================================

@DETECTORS.register_module()
class NIMEMapTR_Joint(MapTR):
    """
    NIME + MapTR 联合训练版本
    
    核心改进：
    1. 训练时随机退化图像，让模型学习处理各种光照条件
    2. NIME 不冻结，检测 loss 会回传指导增强器学习
    3. 增强器学习"对检测有帮助的增强"，而非盲目恢复像素
    
    训练流程：
    ┌─────────────────────────────────────────────────────────┐
    │  img (可能是白天/夜间)                                    │
    │      ↓ [随机退化，训练时 50% 概率]                        │
    │  img_degraded                                            │
    │      ↓ [NIME 增强，可训练]                               │
    │  img_enhanced                                            │
    │      ↓ [MapTR Backbone + Head]                          │
    │  detection_loss ──→ 回传到 NIME，指导增强器              │
    └─────────────────────────────────────────────────────────┘
    """
    
    def __init__(self,
                 # NIME 参数
                 use_nime: bool = True,
                 nime_pretrained: str = None,
                 nime_n_orientations: int = 8,
                 nime_n_scales: int = 4,
                 nime_integration_radius: int = 15,
                 nime_n_channels: int = 32,
                 # 退化参数
                 degrade_prob: float = 0.5,  # 训练时退化概率
                 enable_real_night_effects: bool = True,
                 headlight_prob: float = 0.5,
                 streetlight_prob: float = 0.4,
                 neon_prob: float = 0.3,
                 lens_flare_prob: float = 0.2,
                 # MapTR 原有参数
                 **kwargs):
        super().__init__(**kwargs)
        
        self.use_nime = use_nime
        self.degrade_prob = degrade_prob
        
        if use_nime and NIMEEnhancer is not None:
            # NIME 增强器（可训练，不冻结！）
            self.nime_enhancer = NIMEEnhancer(
                n_orientations=nime_n_orientations,
                n_scales=nime_n_scales,
                integration_radius=nime_integration_radius,
                n_channels=nime_n_channels,
            )
            
            # 加载预训练权重（如果有）
            if nime_pretrained is not None:
                self._load_nime_pretrained(nime_pretrained)
            
            # 退化模块（只在训练时使用）
            from ...models.enhancers.nime_enhancer import LightDegradation
            self.degradation = LightDegradation(
                enable_real_night_effects=enable_real_night_effects,
                headlight_prob=headlight_prob,
                streetlight_prob=streetlight_prob,
                neon_prob=neon_prob,
                lens_flare_prob=lens_flare_prob,
            )
            
            print(f"NIME Joint Training initialized")
            print(f"  - Degrade prob: {degrade_prob}")
            print(f"  - Real night effects: {enable_real_night_effects}")
        else:
            self.nime_enhancer = None
            self.degradation = None
        
        # ImageNet 归一化参数
        self.register_buffer('img_mean',
            torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1))
        self.register_buffer('img_std',
            torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1))
    
    def _load_nime_pretrained(self, path: str):
        """加载 NIME 预训练权重"""
        import os
        if not os.path.exists(path):
            print(f"Warning: NIME pretrained not found: {path}")
            return
        
        state_dict = torch.load(path, map_location='cpu')
        if 'state_dict' in state_dict:
            state_dict = state_dict['state_dict']
        
        # 提取 enhancer 部分
        new_state_dict = {}
        for k, v in state_dict.items():
            if k.startswith('enhancer.'):
                new_state_dict[k[9:]] = v
        
        if new_state_dict:
            self.nime_enhancer.load_state_dict(new_state_dict, strict=False)
            print(f"Loaded NIME pretrained from {path}")
    
    def _apply_degradation(self, img: torch.Tensor) -> torch.Tensor:
        """
        对图像应用退化
        
        Args:
            img: [B, num_cams, C, H, W] ImageNet 归一化格式
        Returns:
            degraded: 退化后的图像
        """
        B, num_cams, C, H, W = img.shape
        
        # 转到 [0, 1]
        img_flat = img.view(B * num_cams, C, H, W)
        img_01 = (img_flat * self.img_std + self.img_mean) / 255.0
        img_01 = img_01.clamp(0, 1)
        
        # 退化
        degraded_01 = self.degradation(img_01)
        
        # 转回 ImageNet 格式
        degraded = (degraded_01 * 255.0 - self.img_mean) / self.img_std
        degraded = degraded.view(B, num_cams, C, H, W)
        
        return degraded
    
    def _apply_enhancement(self, img: torch.Tensor) -> torch.Tensor:
        """
        对图像应用 NIME 增强
        """
        B = img.size(0)
        
        if img.dim() == 5:
            num_cams = img.size(1)
            img_flat = img.view(B * num_cams, *img.shape[2:])
            enhanced_flat = self.nime_enhancer(img_flat)
            enhanced = enhanced_flat.view(B, num_cams, *enhanced_flat.shape[1:])
        else:
            enhanced = self.nime_enhancer(img)
        
        return enhanced
    
    def extract_img_feat(self, img, img_metas):
        """
        提取图像特征
        
        训练时：随机退化 + NIME 增强
        推理时：直接 NIME 增强
        """
        if self.use_nime and self.nime_enhancer is not None:
            # 训练时随机退化
            if self.training and self.degradation is not None:
                import random
                if random.random() < self.degrade_prob:
                    img = self._apply_degradation(img)
            
            # NIME 增强（训练和推理都用）
            img = self._apply_enhancement(img)
        
        return super().extract_img_feat(img, img_metas)
    
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      prev_bev=None):
        """训练前向传播"""
        return super().forward_train(
            points=points,
            img_metas=img_metas,
            gt_bboxes_3d=gt_bboxes_3d,
            gt_labels_3d=gt_labels_3d,
            gt_labels=gt_labels,
            gt_bboxes=gt_bboxes,
            img=img,
            proposals=proposals,
            gt_bboxes_ignore=gt_bboxes_ignore,
            img_depth=img_depth,
            img_mask=img_mask,
            prev_bev=prev_bev,
        )
    
    def simple_test(self, img_metas, img=None, points=None, prev_bev=None, rescale=False):
        """推理"""
        return super().simple_test(
            img_metas=img_metas,
            img=img,
            points=points,
            prev_bev=prev_bev,
            rescale=rescale
        )
