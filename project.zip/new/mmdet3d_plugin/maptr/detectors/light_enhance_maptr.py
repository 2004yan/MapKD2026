"""
LightEnhanceMapTR - Map-Aware Light Adaptation for Robust HD Map Construction

核心设计：
1. 光照自适应网络 (ZeroDCE): 自适应调整光照

2. 核心创新 - 双层 Map 元素感知约束：

   方向1: Map 元素类别感知约束
   - 车道线 (divider): 边缘/梯度约束（线性结构）
   - 人行横道 (ped_crossing): Gabor 纹理约束（周期性条纹）
   - 道路边界 (boundary): Laplacian 形状约束

   方向3: Map 几何先验约束
   - 车道线: 平行约束（方向场一致性）
   - 人行横道: 周期约束（FFT 幅度谱一致性）
   - 道路边界: 平滑约束（二阶梯度一致性）

3. 基础结构保护约束：
   - 边缘一致性: Sobel 边缘保护
   - 结构相似度 (SSIM): 整体结构保护
   - 相位一致性: 几何结构保护 (参考 FDA)
   - 高频保护: 纹理细节保护

4. 一致性学习: Teacher-Student 框架

训练流程：
- 输入: 归一化后的 img [B, N, C, H, W]
- Teacher Stream: img -> Backbone -> Head -> Loss_det
- Student Stream: img -> 实时扰动 -> 增强 -> Backbone -> Head
- Map 元素感知约束: 不同 Map 元素使用不同的保护策略
- 几何先验约束: 利用 Map 元素的固有几何特性
- 一致性约束: MSE(Feat_Student, Feat_Teacher)

推理流程：
- 任意图 -> 增强器 -> Backbone -> Head -> 输出

参考文献：
- ZeroDCE (CVPR 2020): 光照增强
- FDA (CVPR 2020): 频域域适应
- CLRNet (CVPR 2022): 车道线几何约束
- PolyLaneNet: 多项式车道线约束
"""

import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet.models import DETECTORS
from mmdet3d.models import builder
from mmcv.runner import force_fp32, auto_fp16

from .maptr import MapTR


class GPULightPerturbation(nn.Module):
    """
    GPU 上的光照扰动模块
    
    在 forward_train 中实时生成扰动图，避免 Pipeline 数据不一致问题
    
    支持的扰动类型：
    - darken: 变暗
    - brighten: 变亮
    - gamma: Gamma 变换
    - noise: 添加噪声
    """
    
    def __init__(self,
                 perturb_prob=0.8,
                 identity_prob=0.2,
                 darken_range=(0.3, 0.7),
                 brighten_range=(1.2, 1.8),
                 gamma_range=(0.5, 2.0),
                 noise_std_range=(0.02, 0.08)):
        super().__init__()
        self.perturb_prob = perturb_prob
        self.identity_prob = identity_prob
        self.darken_range = darken_range
        self.brighten_range = brighten_range
        self.gamma_range = gamma_range
        self.noise_std_range = noise_std_range
        
        self.perturb_types = ['darken', 'brighten', 'gamma', 'noise']
    
    def forward(self, img):
        """
        对图像进行光照扰动
        
        Args:
            img: [B*N, C, H, W] 或 [B, N, C, H, W]，范围 [0, 1]
        
        Returns:
            perturbed: 扰动后的图像，同输入形状
            perturb_type: 应用的扰动类型
        """
        # 决定是否进行扰动
        if not self.training or torch.rand(1).item() > self.perturb_prob:
            return img, 'identity'
        
        # 决定扰动类型
        if torch.rand(1).item() < self.identity_prob:
            return img, 'identity'
        
        # 随机选择扰动类型
        perturb_idx = torch.randint(0, len(self.perturb_types), (1,)).item()
        perturb_type = self.perturb_types[perturb_idx]
        
        if perturb_type == 'darken':
            factor = torch.empty(1).uniform_(self.darken_range[0], self.darken_range[1]).item()
            perturbed = img * factor
        elif perturb_type == 'brighten':
            factor = torch.empty(1).uniform_(self.brighten_range[0], self.brighten_range[1]).item()
            perturbed = img * factor
        elif perturb_type == 'gamma':
            gamma = torch.empty(1).uniform_(self.gamma_range[0], self.gamma_range[1]).item()
            perturbed = torch.pow(img.clamp(min=1e-8), gamma)
        elif perturb_type == 'noise':
            std = torch.empty(1).uniform_(self.noise_std_range[0], self.noise_std_range[1]).item()
            noise = torch.randn_like(img) * std
            perturbed = img + noise
        else:
            perturbed = img
            perturb_type = 'identity'
        
        return torch.clamp(perturbed, 0, 1), perturb_type


@DETECTORS.register_module()
class LightEnhanceMapTR(MapTR):
    """
    Map-Aware Light Adaptation for Robust HD Map Construction
    
    带光照增强和 Map 元素感知双层约束的 MapTR 检测器
    
    核心创新：
    1. Map 元素类别感知约束 - 不同元素使用不同保护策略
    2. Map 几何先验约束 - 利用元素固有几何特性
    
    Args:
        enhancer: 增强器配置
        img_norm_cfg: 图像归一化配置
        consistency_weight: 一致性损失权重
        identity_weight: 身份保持损失权重
        enhance_loss_weight: 增强器自身损失权重
        structure_loss_weight: 基础结构保护损失权重
        map_aware_loss_weight: Map 元素感知损失权重（核心创新）
        use_consistency_training: 是否使用一致性训练
        use_structure_loss: 是否使用基础结构保护损失
        use_map_aware_loss: 是否使用 Map 元素感知损失（核心创新）
        feature_consistency_layer: 特征一致性计算层
        perturb_cfg: 扰动配置
        structure_loss_cfg: 基础结构保护损失配置
        map_aware_loss_cfg: Map 元素感知损失配置（核心创新）
    """
    
    def __init__(self,
                 enhancer=None,
                 img_norm_cfg=None,
                 consistency_weight=1.0,
                 identity_weight=0.1,
                 enhance_loss_weight=0.1,
                 structure_loss_weight=1.0,
                 map_aware_loss_weight=1.0,
                 use_consistency_training=True,
                 use_structure_loss=True,
                 use_map_aware_loss=True,  # 核心创新开关
                 feature_consistency_layer='neck',
                 perturb_cfg=None,
                 structure_loss_cfg=None,
                 map_aware_loss_cfg=None,  # 核心创新配置
                 **kwargs):
        super(LightEnhanceMapTR, self).__init__(**kwargs)
        
        # 图像归一化配置（默认 ImageNet 标准）
        if img_norm_cfg is None:
            img_norm_cfg = dict(
                mean=[123.675, 116.28, 103.53],
                std=[58.395, 57.12, 57.375],
                to_rgb=True
            )
        self.img_norm_cfg = img_norm_cfg
        
        # 注册为 buffer，用于归一化/反归一化
        self.register_buffer('img_mean', 
            torch.tensor(img_norm_cfg['mean']).view(1, 3, 1, 1))
        self.register_buffer('img_std', 
            torch.tensor(img_norm_cfg['std']).view(1, 3, 1, 1))
        
        # 构建增强器
        if enhancer is not None:
            self.enhancer = builder.build_backbone(enhancer)
        else:
            self.enhancer = builder.build_backbone(
                dict(type='ZeroDCE', in_channels=3, hidden_channels=32, n_iter=8)
            )
        
        # GPU 光照扰动模块
        perturb_cfg = perturb_cfg or {}
        self.light_perturb = GPULightPerturbation(**perturb_cfg)
        
        self.consistency_weight = consistency_weight
        self.identity_weight = identity_weight
        self.enhance_loss_weight = enhance_loss_weight
        self.structure_loss_weight = structure_loss_weight
        self.map_aware_loss_weight = map_aware_loss_weight
        self.use_consistency_training = use_consistency_training
        self.use_structure_loss = use_structure_loss
        self.use_map_aware_loss = use_map_aware_loss
        self.feature_consistency_layer = feature_consistency_layer
        
        # 增强器损失
        from projects.mmdet3d_plugin.models.enhancers.zero_dce import ZeroDCELoss
        self.enhance_loss_fn = ZeroDCELoss()
        
        # ========== 基础结构保护损失 ==========
        if use_structure_loss:
            from projects.mmdet3d_plugin.models.losses.map_structure_loss import MapStructureLoss
            
            structure_loss_cfg = structure_loss_cfg or {}
            default_structure_cfg = dict(
                use_edge_loss=True,      # 边缘一致性
                use_ssim_loss=True,      # 结构相似度
                use_phase_loss=True,     # 相位一致性 (FDA)
                use_freq_loss=True,      # 高频保护
                edge_weight=1.0,
                ssim_weight=1.0,
                phase_weight=0.5,
                freq_weight=0.5,
                ssim_window_size=11,
                low_freq_ratio=0.1
            )
            default_structure_cfg.update(structure_loss_cfg)
            
            self.structure_loss_fn = MapStructureLoss(**default_structure_cfg)
        else:
            self.structure_loss_fn = None
        
        # ========== 核心创新：Map 元素感知的双层约束 ==========
        if use_map_aware_loss:
            from projects.mmdet3d_plugin.models.losses.map_aware_loss import MapAwareLightAdaptationLoss
            
            map_aware_loss_cfg = map_aware_loss_cfg or {}
            default_map_aware_cfg = dict(
                # 方向1：类别感知约束
                use_category_loss=True,
                num_classes=3,           # divider, ped_crossing, boundary
                lane_weight=1.0,         # 车道线边缘约束
                crossing_weight=1.0,     # 人行横道纹理约束
                boundary_weight=1.0,     # 道路边界形状约束
                # 方向3：几何先验约束
                use_geometry_loss=True,
                parallel_weight=1.0,     # 车道线平行约束
                smoothness_weight=1.0,   # 道路边界平滑约束
                periodicity_weight=1.0,  # 人行横道周期约束
                # 总权重
                category_loss_weight=1.0,
                geometry_loss_weight=1.0,
            )
            default_map_aware_cfg.update(map_aware_loss_cfg)
            
            self.map_aware_loss_fn = MapAwareLightAdaptationLoss(**default_map_aware_cfg)
        else:
            self.map_aware_loss_fn = None
    
    def denormalize(self, img):
        """
        反归一化：将 [-mean/std, (255-mean)/std] 范围的图像转换为 [0, 1]
        
        Args:
            img: [B*N, C, H, W]，归一化后的图像
        
        Returns:
            img_01: [B*N, C, H, W]，范围 [0, 1]
        """
        # img * std + mean -> [0, 255]
        # / 255 -> [0, 1]
        img_255 = img * self.img_std + self.img_mean
        img_01 = img_255 / 255.0
        return torch.clamp(img_01, 0, 1)
    
    def normalize(self, img_01):
        """
        归一化：将 [0, 1] 范围的图像转换为 [-mean/std, (255-mean)/std]
        
        Args:
            img_01: [B*N, C, H, W]，范围 [0, 1]
        
        Returns:
            img: [B*N, C, H, W]，归一化后的图像
        """
        # [0, 1] -> [0, 255]
        img_255 = img_01 * 255.0
        # (img - mean) / std
        img_norm = (img_255 - self.img_mean) / self.img_std
        return img_norm
    
    def enhance_images(self, img):
        """
        对图像进行光照增强
        
        完整流程：反归一化 -> 增强 -> 重新归一化
        
        Args:
            img: [B, N, C, H, W] 或 [B*N, C, H, W]，归一化后的图像
        
        Returns:
            enhanced: 增强后的图像，同输入形状和范围
        """
        original_shape = img.shape
        
        # 统一处理为 [B*N, C, H, W]
        if len(original_shape) == 5:
            B, N, C, H, W = original_shape
            img = img.reshape(B * N, C, H, W)
            need_reshape = True
        else:
            need_reshape = False
        
        # 反归一化到 [0, 1]
        img_01 = self.denormalize(img)
        
        # 增强（ZeroDCE 期望输入 [0, 1]）
        enhanced_01 = self.enhancer(img_01)
        
        # 重新归一化
        enhanced = self.normalize(enhanced_01)
        
        # 恢复形状
        if need_reshape:
            enhanced = enhanced.reshape(B, N, C, H, W)
        
        return enhanced
    
    def generate_perturbed_images(self, img):
        """
        生成扰动图像
        
        完整流程：反归一化 -> 扰动 -> 重新归一化
        
        Args:
            img: [B, N, C, H, W] 或 [B*N, C, H, W]，归一化后的图像
        
        Returns:
            perturbed: 扰动后的图像
            perturb_type: 扰动类型
        """
        original_shape = img.shape
        
        # 统一处理为 [B*N, C, H, W]
        if len(original_shape) == 5:
            B, N, C, H, W = original_shape
            img = img.reshape(B * N, C, H, W)
            need_reshape = True
        else:
            need_reshape = False
        
        # 反归一化到 [0, 1]
        img_01 = self.denormalize(img)
        
        # 生成扰动
        perturbed_01, perturb_type = self.light_perturb(img_01)
        
        # 重新归一化
        perturbed = self.normalize(perturbed_01)
        
        # 恢复形状
        if need_reshape:
            perturbed = perturbed.reshape(B, N, C, H, W)
        
        return perturbed, perturb_type
    
    def extract_img_feat_with_intermediate(self, img, img_metas, len_queue=None):
        """
        提取图像特征，同时返回中间特征用于一致性损失
        """
        B = img.size(0)
        if img is not None:
            if img.dim() == 5 and img.size(0) == 1:
                img.squeeze_()
            elif img.dim() == 5 and img.size(0) > 1:
                B, N, C, H, W = img.size()
                img = img.reshape(B * N, C, H, W)
            
            if self.use_grid_mask:
                img = self.grid_mask(img)

            img_feats = self.img_backbone(img)
            if isinstance(img_feats, dict):
                img_feats = list(img_feats.values())
        else:
            return None, None, None
        
        backbone_feats = img_feats
        
        if self.with_img_neck:
            img_feats = self.img_neck(img_feats)
        
        neck_feats = img_feats

        img_feats_reshaped = []
        for img_feat in img_feats:
            BN, C, H, W = img_feat.size()
            if len_queue is not None:
                img_feats_reshaped.append(img_feat.view(int(B/len_queue), len_queue, int(BN / B), C, H, W))
            else:
                img_feats_reshaped.append(img_feat.view(B, int(BN / B), C, H, W))
        
        return img_feats_reshaped, backbone_feats, neck_feats
    
    def compute_consistency_loss(self, feat_teacher, feat_student):
        """
        计算特征一致性损失
        """
        if isinstance(feat_teacher, (list, tuple)):
            feat_teacher = feat_teacher[0]
        if isinstance(feat_student, (list, tuple)):
            feat_student = feat_student[0]
        
        # 展平
        feat_teacher = feat_teacher.flatten(1)
        feat_student = feat_student.flatten(1)
        
        # L2 距离（Teacher 梯度截断）
        loss = F.mse_loss(feat_student, feat_teacher.detach())
        
        return loss
    
    def compute_identity_loss(self, img_original, img_enhanced):
        """
        计算身份保持损失
        """
        return F.l1_loss(img_enhanced, img_original)
    
    @force_fp32(apply_to=('img', 'points', 'prev_bev'))
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      ):
        """
        训练前向传播
        
        核心设计（无 Teacher-Student）：
        =================================
        训练时：
            原图 -> 人工扰动 -> Zero-DCE 增强 -> MapTR 检测 -> 检测损失
                        │                │
                        └─ 结构约束损失 ─┘
                        └─ Map 感知损失 ─┘
        
        Zero-DCE 通过两种监督信号学习：
        1. 检测损失：告诉 Zero-DCE "什么样的光照调整对检测有利"
        2. 结构损失：告诉 Zero-DCE "调整光照时不要破坏结构"
        
        推理时：
            任意光照图 -> Zero-DCE 自适应调整 -> MapTR 检测
        
        可选 Teacher-Student 模式：
            Teacher: 原图 -> 检测
            Student: 原图 -> 扰动 -> 增强 -> 检测
            一致性约束: 特征对齐
        """
        losses = dict()
        
        # ================== LiDAR 特征 ==================
        lidar_feat = None
        if self.modality == 'fusion':
            lidar_feat = self.extract_lidar_feat(points)
        
        # ================== 处理时序 ==================
        len_queue = img.size(1)
        prev_img = img[:, :-1, ...]
        img_current = img[:, -1, ...]  # 当前帧 [B, N, C, H, W]
        
        prev_img_metas = copy.deepcopy(img_metas)
        prev_bev = self.obtain_history_bev(prev_img, prev_img_metas) if len_queue > 1 else None
        
        img_metas_current = [each[len_queue-1] for each in img_metas]
        if not img_metas_current[0]['prev_bev_exists']:
            prev_bev = None
        
        # ================== 核心训练流程 ==================
        # 1. 在 GPU 上实时生成扰动图
        img_perturbed, perturb_type = self.generate_perturbed_images(img_current)
        
        # 2. 对扰动图进行增强（Zero-DCE 光照自适应）
        img_enhanced = self.enhance_images(img_perturbed)
        
        # 3. 提取增强后的特征
        if self.use_consistency_training:
            img_feats_enhanced, backbone_enhanced, neck_enhanced = \
                self.extract_img_feat_with_intermediate(img_enhanced, img_metas_current)
        else:
            img_feats_enhanced = self.extract_feat(img=img_enhanced, img_metas=img_metas_current)
        
        # 4. 检测损失（反向传播到 Zero-DCE，告诉它什么光照对检测好）
        losses_pts = self.forward_pts_train(
            img_feats_enhanced, lidar_feat, gt_bboxes_3d, gt_labels_3d, 
            img_metas_current, gt_bboxes_ignore, prev_bev
        )
        for k, v in losses_pts.items():
            losses[k] = v
        
        # ================== 可选：Teacher-Student 一致性 ==================
        if self.use_consistency_training:
            # Teacher Stream: 原图检测
            img_feats_teacher, backbone_teacher, neck_teacher = \
                self.extract_img_feat_with_intermediate(img_current, img_metas_current)
            
            # Teacher 检测损失（可选，主要用于对比）
            losses_pts_teacher = self.forward_pts_train(
                img_feats_teacher, lidar_feat, gt_bboxes_3d, gt_labels_3d,
                img_metas_current, gt_bboxes_ignore, prev_bev
            )
            for k, v in losses_pts_teacher.items():
                losses[f'teacher_{k}'] = v
            
            # 一致性损失
            if self.feature_consistency_layer == 'backbone':
                feat_t, feat_s = backbone_teacher, backbone_enhanced
            elif self.feature_consistency_layer == 'neck':
                feat_t, feat_s = neck_teacher, neck_enhanced
            else:
                feat_t, feat_s = img_feats_teacher, img_feats_enhanced
            
            loss_consistency = self.compute_consistency_loss(feat_t, feat_s)
            losses['loss_consistency'] = loss_consistency * self.consistency_weight
        
        # ================== 结构保护约束 ==================
        # 反归一化到 [0, 1]（损失函数期望的范围）
        B, N, C, H, W = img_enhanced.shape
        img_enhanced_flat = img_enhanced.reshape(B * N, C, H, W)
        img_perturbed_flat = img_perturbed.reshape(B * N, C, H, W)
        
        img_enhanced_01 = self.denormalize(img_enhanced_flat)
        img_perturbed_01 = self.denormalize(img_perturbed_flat)
        
        # 身份保持损失：对"正常光照"图像，增强器应该尽量不改变
        img_original_enhanced = self.enhance_images(img_current)
        loss_identity = self.compute_identity_loss(img_current, img_original_enhanced)
        losses['loss_identity'] = loss_identity * self.identity_weight
        
        # ZeroDCE 自身损失（曝光控制、颜色恒常、平滑性）
        loss_enhance, _ = self.enhance_loss_fn(img_enhanced_01, img_perturbed_01)
        losses['loss_enhance'] = loss_enhance * self.enhance_loss_weight
        
        # ========== 基础结构保护损失 ==========
        if self.use_structure_loss and self.structure_loss_fn is not None:
            structure_losses, _ = self.structure_loss_fn(
                img_perturbed_01, img_enhanced_01
            )
            for k, v in structure_losses.items():
                losses[k] = v * self.structure_loss_weight
        
        # ========== 核心创新：Map 元素感知的双层约束 ==========
        if self.use_map_aware_loss and self.map_aware_loss_fn is not None:
            map_aware_losses, _ = self.map_aware_loss_fn(
                img_perturbed_01, img_enhanced_01
            )
            for k, v in map_aware_losses.items():
                losses[k] = v * self.map_aware_loss_weight
        
        return losses
    
    def simple_test(self, img_metas, img=None, points=None, prev_bev=None, rescale=False, 
                    already_enhanced=False, **kwargs):
        """
        推理前向传播
        
        Args:
            already_enhanced: 是否已经增强过（避免双重增强）
        """
        # 只有在未增强时才进行增强
        if img is not None and not already_enhanced:
            img = self.enhance_images(img)
        
        return super().simple_test(img_metas, img, points, prev_bev, rescale, **kwargs)
    
    def forward_test(self, img_metas, img=None, points=None, **kwargs):
        """测试前向传播"""
        for var, name in [(img_metas, 'img_metas')]:
            if not isinstance(var, list):
                raise TypeError('{} must be a list, but got {}'.format(name, type(var)))
        
        img = [img] if img is None else img
        points = [points] if points is None else points
        
        # 在 forward_test 统一进行增强
        if img[0] is not None:
            img = [self.enhance_images(img[0])]
            already_enhanced = True
        else:
            already_enhanced = False
        
        if img_metas[0][0]['scene_token'] != self.prev_frame_info['scene_token']:
            self.prev_frame_info['prev_bev'] = None
        self.prev_frame_info['scene_token'] = img_metas[0][0]['scene_token']

        if not self.video_test_mode:
            self.prev_frame_info['prev_bev'] = None

        tmp_pos = copy.deepcopy(img_metas[0][0]['can_bus'][:3])
        tmp_angle = copy.deepcopy(img_metas[0][0]['can_bus'][-1])
        
        if self.prev_frame_info['prev_bev'] is not None:
            img_metas[0][0]['can_bus'][:3] -= self.prev_frame_info['prev_pos']
            img_metas[0][0]['can_bus'][-1] -= self.prev_frame_info['prev_angle']
        else:
            img_metas[0][0]['can_bus'][-1] = 0
            img_metas[0][0]['can_bus'][:3] = 0

        # 传递 already_enhanced=True 避免 simple_test 中双重增强
        new_prev_bev, bbox_results = self.simple_test(
            img_metas[0], img[0], points[0], prev_bev=self.prev_frame_info['prev_bev'],
            already_enhanced=already_enhanced, **kwargs
        )
        
        self.prev_frame_info['prev_pos'] = tmp_pos
        self.prev_frame_info['prev_angle'] = tmp_angle
        self.prev_frame_info['prev_bev'] = new_prev_bev
        
        return bbox_results
