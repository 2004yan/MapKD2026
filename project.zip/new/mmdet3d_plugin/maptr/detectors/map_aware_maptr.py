"""
Map-Aware Feature Alignment MapTR

核心创新：基于地图元素特质的跨光照特征对齐

训练流程：
1. 输入白天图像
2. 生成对应的合成夜间图像（GT 相同）
3. 分别提取特征
4. 施加三大地图感知一致性约束：
   - 梯度方向一致性（车道线/边界）
   - 频域一致性（人行横道）
   - BEV 几何一致性（整体拓扑）
5. 同时做检测任务

与通用光照增强的区别：
- 我们不是在像素空间做增强
- 而是在特征空间做对齐
- 利用地图元素的几何、频域、拓扑特性作为约束
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import warnings
from mmcv.runner import force_fp32, auto_fp16
from mmdet.models import DETECTORS
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector

from ..detectors.maptr import MapTR
from ...models.enhancers.light_degradation import DayNightPairGenerator
from ...models.losses.map_aware_consistency_loss import (
    MapAwareConsistencyLoss,
    GradientDirectionConsistencyLoss,
    FrequencyDomainConsistencyLoss,
    BEVGeometricConsistencyLoss
)


@DETECTORS.register_module()
class MapAwareMapTR(MapTR):
    """
    Map-Aware Feature Alignment MapTR
    
    在训练时：
    1. 用 DayNightPairGenerator 生成 (Day, Night) 图像对
    2. 分别提取特征
    3. 施加 MapAwareConsistencyLoss
    4. 同时做检测任务
    
    在推理时：
    与普通 MapTR 完全相同
    """
    
    def __init__(self,
                 # 继承 MapTR 的所有参数
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 video_test_mode=False,
                 # 新增参数
                 use_map_aware_training=True,
                 degradation_cfg=None,
                 consistency_loss_cfg=None,
                 consistency_loss_weight=1.0,
                 # 控制在哪个层级做一致性约束
                 align_img_feat=True,    # 图像特征层
                 align_bev_feat=True,    # BEV 特征层
                 init_cfg=None):
        
        super().__init__(
            use_grid_mask=use_grid_mask,
            pts_voxel_layer=pts_voxel_layer,
            pts_voxel_encoder=pts_voxel_encoder,
            pts_middle_encoder=pts_middle_encoder,
            pts_fusion_layer=pts_fusion_layer,
            img_backbone=img_backbone,
            pts_backbone=pts_backbone,
            img_neck=img_neck,
            pts_neck=pts_neck,
            pts_bbox_head=pts_bbox_head,
            img_roi_head=img_roi_head,
            img_rpn_head=img_rpn_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            video_test_mode=video_test_mode
        )
        
        self.use_map_aware_training = use_map_aware_training
        self.align_img_feat = align_img_feat
        self.align_bev_feat = align_bev_feat
        self.consistency_loss_weight = consistency_loss_weight
        
        # 光照退化生成器
        if degradation_cfg is None:
            degradation_cfg = dict(
                degradation_type='simple',
                darkness_range=(0.1, 0.4),
                gamma_range=(1.5, 2.5),
                noise_level=0.02,
                add_local_light=True
            )
        self.pair_generator = DayNightPairGenerator(**degradation_cfg)
        
        # Map-Aware 一致性 Loss
        if consistency_loss_cfg is None:
            consistency_loss_cfg = dict(
                direction_weight=1.0,
                frequency_weight=0.5,
                geometric_weight=0.5
            )
        self.consistency_loss = MapAwareConsistencyLoss(**consistency_loss_cfg)
    
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      prev_bev=None):
        """
        训练前向传播
        
        新增：Map-Aware Feature Alignment
        """
        losses = dict()
        
        # ========== 原始检测任务 ==========
        # 提取图像特征
        img_feats = self.extract_img_feat(img=img, img_metas=img_metas)
        
        # 提取 BEV 特征并计算检测 Loss
        outs = self.pts_bbox_head(img_feats, img_metas, prev_bev)
        loss_inputs = [gt_bboxes_3d, gt_labels_3d, outs]
        detection_losses = self.pts_bbox_head.loss(*loss_inputs, img_metas=img_metas)
        losses.update(detection_losses)
        
        # ========== Map-Aware Feature Alignment ==========
        if self.use_map_aware_training and self.training:
            consistency_losses = self._compute_consistency_losses(img, img_metas, img_feats)
            losses.update(consistency_losses)
        
        return losses
    
    def _compute_consistency_losses(self, img, img_metas, img_feats_day):
        """
        计算 Map-Aware 一致性 Loss
        
        Args:
            img: [B, N, C, H, W] 原始（白天）图像
            img_metas: 图像元信息
            img_feats_day: 白天图像的特征
        """
        losses = {}
        
        # 1. 生成夜间图像
        B, N, C, H, W = img.shape
        img_flat = img.view(B * N, C, H, W)
        
        # 归一化到 [0, 1]
        img_normalized = self._denormalize_img(img_flat)
        
        # 生成夜间版本
        _, img_night_normalized, degrade_params = self.pair_generator(img_normalized)
        
        # 归一化回网络输入格式
        img_night_flat = self._normalize_img(img_night_normalized)
        img_night = img_night_flat.view(B, N, C, H, W)
        
        # 2. 提取夜间图像特征
        img_feats_night = self.extract_img_feat(img=img_night, img_metas=img_metas)
        
        # 3. 在图像特征层计算一致性
        if self.align_img_feat and img_feats_day is not None:
            # 取最高分辨率的特征
            feat_day = img_feats_day[0] if isinstance(img_feats_day, (list, tuple)) else img_feats_day
            feat_night = img_feats_night[0] if isinstance(img_feats_night, (list, tuple)) else img_feats_night
            
            # 计算一致性 Loss
            consistency_losses = self.consistency_loss(feat_day, feat_night)
            
            for k, v in consistency_losses.items():
                losses[f'img_{k}'] = v * self.consistency_loss_weight
        
        # 4. 在 BEV 特征层计算一致性（如果有 BEV head）
        if self.align_bev_feat and hasattr(self, 'pts_bbox_head'):
            # 这里可以进一步扩展，获取 BEV 特征并计算一致性
            pass
        
        return losses
    
    def _denormalize_img(self, img: torch.Tensor) -> torch.Tensor:
        """
        将网络输入的归一化图像转回 [0, 1] 范围
        
        假设使用 ImageNet 归一化：
        mean = [123.675, 116.28, 103.53]
        std = [58.395, 57.12, 57.375]
        """
        mean = torch.tensor([123.675, 116.28, 103.53], device=img.device).view(1, 3, 1, 1)
        std = torch.tensor([58.395, 57.12, 57.375], device=img.device).view(1, 3, 1, 1)
        
        img_denorm = img * std + mean
        img_denorm = img_denorm / 255.0
        
        return img_denorm.clamp(0, 1)
    
    def _normalize_img(self, img: torch.Tensor) -> torch.Tensor:
        """
        将 [0, 1] 范围的图像转为网络输入格式
        """
        mean = torch.tensor([123.675, 116.28, 103.53], device=img.device).view(1, 3, 1, 1)
        std = torch.tensor([58.395, 57.12, 57.375], device=img.device).view(1, 3, 1, 1)
        
        img_norm = img * 255.0
        img_norm = (img_norm - mean) / std
        
        return img_norm


@DETECTORS.register_module()
class MapAwareMapTR_Pretrain(nn.Module):
    """
    Map-Aware Feature Alignment 预训练模型
    
    纯粹的特征对齐预训练，不做检测任务
    用于先训练一个光照不变的特征提取器
    """
    
    def __init__(self,
                 img_backbone,
                 img_neck=None,
                 degradation_cfg=None,
                 consistency_loss_cfg=None,
                 init_cfg=None):
        super().__init__()
        
        from mmdet.models import build_backbone, build_neck
        
        # 构建 backbone 和 neck
        self.img_backbone = build_backbone(img_backbone)
        if img_neck is not None:
            self.img_neck = build_neck(img_neck)
        else:
            self.img_neck = None
        
        # 光照退化生成器
        if degradation_cfg is None:
            degradation_cfg = dict(
                degradation_type='simple',
                darkness_range=(0.1, 0.4),
                gamma_range=(1.5, 2.5),
                noise_level=0.02
            )
        self.pair_generator = DayNightPairGenerator(**degradation_cfg)
        
        # Map-Aware 一致性 Loss
        if consistency_loss_cfg is None:
            consistency_loss_cfg = dict(
                direction_weight=1.0,
                frequency_weight=0.5,
                geometric_weight=0.5
            )
        self.consistency_loss = MapAwareConsistencyLoss(**consistency_loss_cfg)
        
        # ImageNet 归一化参数
        self.register_buffer('img_mean', 
                            torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1))
        self.register_buffer('img_std', 
                            torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1))
    
    def extract_feat(self, img):
        """提取图像特征"""
        x = self.img_backbone(img)
        if self.img_neck is not None:
            x = self.img_neck(x)
        return x
    
    def forward(self, img, img_metas=None, return_loss=True, **kwargs):
        """
        前向传播
        
        Args:
            img: [B, N, C, H, W] 或 [B, C, H, W] 输入图像
        """
        if return_loss:
            return self.forward_train(img)
        else:
            return self.forward_test(img)
    
    def forward_train(self, img):
        """训练前向传播"""
        # 处理维度
        if img.dim() == 5:  # [B, N, C, H, W]
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
        
        # 1. 反归一化到 [0, 1]
        img_denorm = (img * self.img_std + self.img_mean) / 255.0
        img_denorm = img_denorm.clamp(0, 1)
        
        # 2. 生成夜间图像
        _, img_night_denorm, _ = self.pair_generator(img_denorm)
        
        # 3. 归一化回网络输入
        img_day = img  # 原始输入
        img_night = (img_night_denorm * 255.0 - self.img_mean) / self.img_std
        
        # 4. 提取特征
        feat_day = self.extract_feat(img_day)
        feat_night = self.extract_feat(img_night)
        
        # 5. 计算一致性 Loss
        # 取最高分辨率特征
        if isinstance(feat_day, (list, tuple)):
            feat_day = feat_day[0]
            feat_night = feat_night[0]
        
        losses = self.consistency_loss(feat_day, feat_night)
        
        return losses
    
    def forward_test(self, img):
        """测试前向传播（只提取特征）"""
        if img.dim() == 5:
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
        
        feat = self.extract_feat(img)
        return feat
