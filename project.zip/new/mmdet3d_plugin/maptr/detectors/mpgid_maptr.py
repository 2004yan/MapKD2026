"""
MPGID-MapTR: Map-Prior Guided Intrinsic Decomposition for HD Map Construction

两阶段训练方案：
1. Stage 1 (预训练): 使用 Map Prior 自监督预训练 IID 网络
2. Stage 2 (微调): 用预训练的 IID 处理图像，然后微调 MapTR 检测器

核心创新：
- 在预训练阶段就引入 Map 元素先验
- 不需要 GT 标注，使用传统方法估计先验
- 预训练出的 IID 网络对 Map 检测更友好

ECCV 级别创新模块 (可通过配置开关控制):
- Multi-View Photometric Consistency: 多视角光度一致性
- BEV-Space Light Field: BEV 空间光照场建模
- Temporal Consistency: 时序一致性 (可选)
"""

import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmdet.models import DETECTORS, build_loss
from mmdet3d.models import builder
from mmcv.runner import force_fp32, auto_fp16
from mmcv.cnn import build_norm_layer

from .maptr import MapTR


@DETECTORS.register_module()
class MPGIDMapTR(MapTR):
    """
    MPGID-MapTR: Map-Prior Guided Intrinsic Decomposition for HD Map Construction
    
    Args:
        iid_cfg: IID 网络配置
        map_prior_cfg: Map Prior 估计器配置
        pretrain_loss_cfg: 预训练损失配置
        training_stage: 训练阶段 ('pretrain' 或 'finetune')
        pretrained_iid: 预训练 IID 权重路径
        use_albedo_only: 是否只使用 Albedo（不使用 Shading）
        freeze_iid: 微调时是否冻结 IID 网络
        img_norm_cfg: 图像归一化配置
        
        # ============ ECCV 级别创新模块开关 (消融实验) ============
        use_multi_view_consistency: 是否启用多视角光度一致性损失
        use_bev_light_field: 是否启用 BEV 空间光照场损失
        use_temporal_consistency: 是否启用时序一致性损失 (需要时序数据)
        
        # 模块配置
        multi_view_cfg: 多视角一致性损失配置
        bev_light_field_cfg: BEV 光照场损失配置
        temporal_cfg: 时序一致性损失配置
    """
    
    def __init__(self,
                 iid_cfg=None,
                 map_prior_cfg=None,
                 pretrain_loss_cfg=None,
                 training_stage='finetune',
                 pretrained_iid=None,
                 use_albedo_only=True,
                 freeze_iid=False,
                 img_norm_cfg=None,
                 # ============ ECCV 创新模块开关 ============
                 use_multi_view_consistency=False,  # 多视角一致性
                 use_bev_light_field=False,         # BEV 光照场
                 use_temporal_consistency=False,     # 时序一致性
                 # 模块配置
                 multi_view_cfg=None,
                 bev_light_field_cfg=None,
                 temporal_cfg=None,
                 # MapTR 参数
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 video_test_mode=False,
                 modality='vision',
                 lidar_encoder=None,
                 **kwargs):
        
        super(MPGIDMapTR, self).__init__(
            use_grid_mask=use_grid_mask,
            pts_voxel_layer=pts_voxel_layer,
            pts_voxel_encoder=pts_voxel_encoder,
            pts_middle_encoder=pts_middle_encoder,
            pts_fusion_layer=pts_fusion_layer,
            img_backbone=img_backbone,
            pts_backbone=pts_backbone,
            img_neck=img_neck,
            pts_neck=pts_neck,
            pts_bbox_head=pts_bbox_head,
            img_roi_head=img_roi_head,
            img_rpn_head=img_rpn_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            video_test_mode=video_test_mode,
            modality=modality,
            lidar_encoder=lidar_encoder,
        )
        
        self.training_stage = training_stage
        self.use_albedo_only = use_albedo_only
        self.freeze_iid = freeze_iid
        
        # 图像归一化配置
        if img_norm_cfg is None:
            self.img_norm_cfg = dict(
                mean=[123.675, 116.28, 103.53],
                std=[58.395, 57.12, 57.375],
                to_rgb=True
            )
        else:
            self.img_norm_cfg = img_norm_cfg
        
        # 构建 IID 网络
        if iid_cfg is not None:
            self.iid_network = self._build_iid_network(iid_cfg)
        else:
            # 默认 IID 网络
            from ...models.enhancers.iid_network import IIDNetworkLite
            self.iid_network = IIDNetworkLite(in_channels=3, base_channels=32)
        
        # 构建 Map Prior 估计器
        if map_prior_cfg is not None:
            self.map_prior_estimator = self._build_map_prior_estimator(map_prior_cfg)
        else:
            # 默认 Map Prior 估计器
            from ...models.enhancers.map_prior_estimator import FastMapPriorEstimator
            self.map_prior_estimator = FastMapPriorEstimator()
        
        # 构建预训练损失
        if pretrain_loss_cfg is not None:
            self.pretrain_loss = build_loss(pretrain_loss_cfg)
        else:
            # 默认预训练损失
            from ...models.losses.iid_pretrain_loss import IIDPretrainLoss
            self.pretrain_loss = IIDPretrainLoss()
        
        # 光照扰动一致性损失
        from ...models.losses.iid_pretrain_loss import LightPerturbationLoss
        self.light_perturb_loss = LightPerturbationLoss(loss_weight=5.0)  # 核心自监督信号，提高权重
        
        # 光照扰动器（用于自监督）
        self.light_perturbation = GPULightPerturbation()
        
        # ============ ECCV 级别创新模块 ============
        # 保存开关状态
        self.use_multi_view_consistency = use_multi_view_consistency
        self.use_bev_light_field = use_bev_light_field
        self.use_temporal_consistency = use_temporal_consistency
        
        # 初始化多视角一致性模块
        if use_multi_view_consistency:
            from ...models.losses.iid_pretrain_loss import MultiViewPhotometricLoss
            mv_cfg = multi_view_cfg or {}
            self.multi_view_loss = MultiViewPhotometricLoss(
                loss_weight=mv_cfg.get('loss_weight', 1.0),
                overlap_threshold=mv_cfg.get('overlap_threshold', 0.1),
                use_ssim=mv_cfg.get('use_ssim', True),
                ssim_weight=mv_cfg.get('ssim_weight', 0.85),
            )
            print("[MPGID] Multi-View Photometric Consistency: ENABLED")
        else:
            self.multi_view_loss = None
            print("[MPGID] Multi-View Photometric Consistency: DISABLED")
        
        # 初始化 BEV 光照场模块
        if use_bev_light_field:
            from ...models.losses.iid_pretrain_loss import BEVLightFieldLoss
            bev_cfg = bev_light_field_cfg or {}
            self.bev_light_field_loss = BEVLightFieldLoss(
                loss_weight=bev_cfg.get('loss_weight', 1.0),
                bev_h=bev_cfg.get('bev_h', 100),
                bev_w=bev_cfg.get('bev_w', 100),
                bev_range=bev_cfg.get('bev_range', [-50, 50, -25, 25]),
                smoothness_weight=bev_cfg.get('smoothness_weight', 0.5),
                consistency_weight=bev_cfg.get('consistency_weight', 0.5),
            )
            print("[MPGID] BEV Light Field: ENABLED")
        else:
            self.bev_light_field_loss = None
            print("[MPGID] BEV Light Field: DISABLED")
        
        # 初始化时序一致性模块
        if use_temporal_consistency:
            from ...models.losses.iid_pretrain_loss import TemporalConsistencyLoss
            temp_cfg = temporal_cfg or {}
            self.temporal_loss = TemporalConsistencyLoss(
                loss_weight=temp_cfg.get('loss_weight', 0.5),
            )
            print("[MPGID] Temporal Consistency: ENABLED")
        else:
            self.temporal_loss = None
            print("[MPGID] Temporal Consistency: DISABLED")
        
        # 加载预训练 IID 权重
        if pretrained_iid is not None:
            self._load_pretrained_iid(pretrained_iid)
        
        # 微调时冻结 IID
        if training_stage == 'finetune' and freeze_iid:
            self._freeze_iid_network()
    
    def _build_iid_network(self, cfg):
        """构建 IID 网络"""
        from ...models.enhancers.iid_network import IIDNetwork, IIDNetworkLite, RetinexNet
        
        # 重要：复制配置，避免修改原始字典
        cfg = cfg.copy() if cfg is not None else {}
        network_type = cfg.pop('type', 'IIDNetworkLite')
        
        if network_type == 'IIDNetwork':
            return IIDNetwork(**cfg)
        elif network_type == 'IIDNetworkLite':
            return IIDNetworkLite(**cfg)
        elif network_type == 'RetinexNet':
            return RetinexNet(**cfg)
        else:
            raise ValueError(f"Unknown IID network type: {network_type}")
    
    def _build_map_prior_estimator(self, cfg):
        """构建 Map Prior 估计器"""
        from ...models.enhancers.map_prior_estimator import MapPriorEstimator, FastMapPriorEstimator
        
        # 重要：复制配置，避免修改原始字典
        cfg = cfg.copy() if cfg is not None else {}
        estimator_type = cfg.pop('type', 'FastMapPriorEstimator')
        
        if estimator_type == 'MapPriorEstimator':
            return MapPriorEstimator(**cfg)
        elif estimator_type == 'FastMapPriorEstimator':
            return FastMapPriorEstimator()
        else:
            raise ValueError(f"Unknown Map Prior estimator type: {estimator_type}")
    
    def _load_pretrained_iid(self, pretrained_path):
        """
        加载预训练 IID 权重
        
        支持两种格式：
        1. mmcv checkpoint 格式: {'meta': ..., 'state_dict': {...}, 'optimizer': ...}
        2. 直接保存的 IID 权重: {'iid_network': {...}}
        """
        import os
        import warnings
        if os.path.exists(pretrained_path):
            checkpoint = torch.load(pretrained_path, map_location='cpu')
            
            # 处理 mmcv checkpoint 格式
            if 'state_dict' in checkpoint:
                # mmcv 保存的 checkpoint，state_dict 中的 key 带有模块前缀
                full_state_dict = checkpoint['state_dict']
                
                # 筛选出 IID 网络的权重（以 'iid_network.' 开头）
                iid_state_dict = {}
                for k, v in full_state_dict.items():
                    if k.startswith('iid_network.'):
                        # 去掉 'iid_network.' 前缀
                        new_key = k[len('iid_network.'):]
                        iid_state_dict[new_key] = v
                
                if len(iid_state_dict) > 0:
                    self.iid_network.load_state_dict(iid_state_dict)
                    print(f"[MPGID] Loaded pretrained IID from mmcv checkpoint: {pretrained_path}")
                    print(f"[MPGID] Loaded {len(iid_state_dict)} parameters for IID network")
                else:
                    warnings.warn(
                        f"[MPGID] No IID network weights found in checkpoint. "
                        f"Keys found: {list(full_state_dict.keys())[:10]}..."
                    )
            
            # 处理直接保存的 IID 权重格式
            elif 'iid_network' in checkpoint:
                self.iid_network.load_state_dict(checkpoint['iid_network'])
                print(f"[MPGID] Loaded pretrained IID from direct save: {pretrained_path}")
            
            # 假设整个 checkpoint 就是 IID 网络的 state_dict
            else:
                try:
                    self.iid_network.load_state_dict(checkpoint)
                    print(f"[MPGID] Loaded pretrained IID (raw state_dict): {pretrained_path}")
                except Exception as e:
                    warnings.warn(
                        f"[MPGID] Failed to load IID weights: {e}. "
                        f"Checkpoint keys: {list(checkpoint.keys())[:10]}..."
                    )
        else:
            warnings.warn(
                f"[MPGID] Pretrained IID weights not found at {pretrained_path}. "
                f"Using random initialization. Please run Stage 1 pretraining first!"
            )
    
    def _freeze_iid_network(self):
        """冻结 IID 网络"""
        for param in self.iid_network.parameters():
            param.requires_grad = False
        self.iid_network.eval()
        print("IID network frozen")
    
    def denormalize_img(self, img):
        """
        将 ImageNet 归一化的图像转换回 [0, 1] 范围
        
        Args:
            img: [B, N, C, H, W] 或 [B, C, H, W] 归一化图像
        
        Returns:
            img_01: [B, N, C, H, W] 或 [B, C, H, W] [0, 1] 范围图像
        """
        mean = torch.tensor(self.img_norm_cfg['mean'], device=img.device).view(1, 1, 3, 1, 1)
        std = torch.tensor(self.img_norm_cfg['std'], device=img.device).view(1, 1, 3, 1, 1)
        
        if img.dim() == 4:
            mean = mean.squeeze(1)
            std = std.squeeze(1)
        
        img_01 = img * std + mean
        img_01 = img_01 / 255.0
        img_01 = torch.clamp(img_01, 0, 1)
        
        return img_01
    
    def normalize_img(self, img_01):
        """
        将 [0, 1] 范围图像转换为 ImageNet 归一化
        
        Args:
            img_01: [B, N, C, H, W] 或 [B, C, H, W] [0, 1] 范围图像
        
        Returns:
            img_norm: ImageNet 归一化图像
        """
        mean = torch.tensor(self.img_norm_cfg['mean'], device=img_01.device).view(1, 1, 3, 1, 1)
        std = torch.tensor(self.img_norm_cfg['std'], device=img_01.device).view(1, 1, 3, 1, 1)
        
        if img_01.dim() == 4:
            mean = mean.squeeze(1)
            std = std.squeeze(1)
        
        img_255 = img_01 * 255.0
        img_norm = (img_255 - mean) / std
        
        return img_norm
    
    def process_with_iid(self, img):
        """
        使用 IID 网络处理图像
        
        Args:
            img: [B, N, C, H, W] ImageNet 归一化图像
        
        Returns:
            processed_img: 处理后的图像（归一化）
            albedo: [B, N, C, H, W] Albedo
            shading: [B, N, 1, H, W] Shading
        """
        B, N, C, H, W = img.shape
        
        # 反归一化到 [0, 1]
        img_01 = self.denormalize_img(img)
        
        # 重塑为 [B*N, C, H, W]
        img_flat = img_01.view(B * N, C, H, W)
        
        # IID 分解
        albedo, shading = self.iid_network(img_flat)
        
        # 重塑回 [B, N, C, H, W]
        albedo = albedo.view(B, N, C, H, W)
        shading = shading.view(B, N, 1, H, W)
        
        # 根据配置决定使用什么
        if self.use_albedo_only:
            processed_01 = albedo
        else:
            # 使用重建图像
            processed_01 = albedo * shading
        
        # 归一化回 ImageNet 格式
        processed_img = self.normalize_img(processed_01)
        
        return processed_img, albedo, shading
    
    def obtain_history_bev_with_iid(self, imgs_queue, img_metas_list):
        """
        获取历史 BEV 特征，但先用 IID 处理历史帧
        
        【重要】这是对原始 obtain_history_bev 的重写，确保历史帧也经过 IID 处理，
        保证历史帧和当前帧的特征空间一致。
        
        Args:
            imgs_queue: [B, len_queue, N, C, H, W] 历史帧图像（已归一化）
            img_metas_list: 对应的 img_metas
        
        Returns:
            prev_bev: 历史 BEV 特征
        """
        self.eval()
        
        with torch.no_grad():
            prev_bev = None
            bs, len_queue, num_cams, C, H, W = imgs_queue.shape
            
            # 先用 IID 处理所有历史帧
            # [B, len_queue, N, C, H, W] -> [B*len_queue, N, C, H, W]
            imgs_queue_flat = imgs_queue.reshape(bs * len_queue, num_cams, C, H, W)
            
            # IID 处理
            processed_imgs, _, _ = self.process_with_iid(imgs_queue_flat)
            
            # 提取特征
            img_feats_list = self.extract_feat(img=processed_imgs, len_queue=len_queue)
            
            # 逐帧处理 BEV
            for i in range(len_queue):
                img_metas = [each[i] for each in img_metas_list]
                if not img_metas[0]['prev_bev_exists']:
                    prev_bev = None
                img_feats = [each_scale[:, i] for each_scale in img_feats_list]
                prev_bev = self.pts_bbox_head(
                    img_feats, None, img_metas, prev_bev, only_bev=True)
            
            self.train()
            return prev_bev
    
    @force_fp32(apply_to=('img', 'points', 'prev_bev'))
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      ):
        """
        训练前向传播
        
        根据 training_stage 选择不同的训练流程
        """
        if self.training_stage == 'pretrain':
            return self.forward_pretrain(img, img_metas)
        else:
            return self.forward_finetune(
                points, img_metas, gt_bboxes_3d, gt_labels_3d,
                gt_labels, gt_bboxes, img, proposals,
                gt_bboxes_ignore, img_depth, img_mask
            )
    
    def forward_pretrain(self, img, img_metas):
        """
        Stage 1: 预训练 IID 网络
        
        使用自监督损失训练 IID 网络
        
        支持的损失模块 (通过配置开关控制):
        - 基础 IID 损失 (重建、平滑、结构保持等)
        - 光照扰动一致性损失
        - [可选] 多视角光度一致性损失
        - [可选] BEV 空间光照场损失
        - [可选] 时序一致性损失
        """
        losses = dict()
        
        # img: [B, queue_len, N, C, H, W]
        # 保存完整的时序数据用于时序一致性
        full_img = img
        
        # 只使用当前帧进行主要训练
        if img.dim() == 6:
            img = img[:, -1, ...]  # [B, N, C, H, W]
        
        B, N, C, H, W = img.shape
        
        # 反归一化到 [0, 1]
        img_01 = self.denormalize_img(img)
        img_flat = img_01.view(B * N, C, H, W)
        
        # 1. 估计 Map Prior
        with torch.no_grad():
            map_prior = self.map_prior_estimator(img_flat)  # [B*N, 1, H, W]
        
        # 2. IID 分解
        albedo, shading = self.iid_network(img_flat)
        
        # 3. 计算基础预训练损失
        pretrain_loss, loss_dict = self.pretrain_loss(
            albedo, shading, img_flat, map_prior
        )
        
        for k, v in loss_dict.items():
            losses[f'pretrain/{k}'] = v
        
        # 4. 光照扰动一致性损失（自监督核心）
        img_perturbed = self.light_perturbation(img_flat)
        albedo_perturbed, shading_perturbed = self.iid_network(img_perturbed)
        loss_perturb = self.light_perturb_loss(albedo, albedo_perturbed, map_prior)
        losses['pretrain/loss_light_perturb'] = loss_perturb
        
        # ============ ECCV 级别创新模块 ============
        
        # 5. 多视角光度一致性损失 [ECCV 创新]
        if self.use_multi_view_consistency and self.multi_view_loss is not None:
            # 重塑为多视角格式 [B, N, C, H, W]
            albedo_mv = albedo.view(B, N, C, H, W)
            map_prior_mv = map_prior.view(B, N, 1, H, W)
            
            loss_mv = self.multi_view_loss(albedo_mv, map_prior_mv)
            losses['pretrain/loss_multi_view'] = loss_mv
        
        # 6. BEV 空间光照场损失 [ECCV 创新]
        if self.use_bev_light_field and self.bev_light_field_loss is not None:
            # 重塑为多视角格式 [B, N, 1, H, W]
            shading_mv = shading.view(B, N, 1, H, W)
            map_prior_mv = map_prior.view(B, N, 1, H, W)
            
            loss_bev, bev_loss_dict = self.bev_light_field_loss(shading_mv, map_prior_mv)
            losses['pretrain/loss_bev_light_field'] = loss_bev
            
            # 添加细分损失
            for k, v in bev_loss_dict.items():
                losses[f'pretrain/bev_{k}'] = v
        
        # 7. 时序一致性损失 [ECCV 创新]
        if self.use_temporal_consistency and self.temporal_loss is not None:
            if full_img.dim() == 6 and full_img.size(1) > 1:
                # 获取上一帧
                img_prev = full_img[:, -2, ...]  # [B, N, C, H, W]
                img_prev_01 = self.denormalize_img(img_prev)
                img_prev_flat = img_prev_01.view(B * N, C, H, W)
                
                # 对上一帧进行 IID 分解
                with torch.no_grad():
                    albedo_prev, _ = self.iid_network(img_prev_flat)
                
                # 时序一致性损失
                loss_temporal = self.temporal_loss(albedo, albedo_prev)
                losses['pretrain/loss_temporal'] = loss_temporal
        
        return losses
    
    def forward_finetune(self,
                         points=None,
                         img_metas=None,
                         gt_bboxes_3d=None,
                         gt_labels_3d=None,
                         gt_labels=None,
                         gt_bboxes=None,
                         img=None,
                         proposals=None,
                         gt_bboxes_ignore=None,
                         img_depth=None,
                         img_mask=None):
        """
        Stage 2: 微调 MapTR 检测器
        
        使用预训练的 IID 网络处理图像，然后进行检测
        
        重要：历史帧和当前帧都需要经过 IID 处理，保证特征空间一致！
        """
        lidar_feat = None
        if self.modality == 'fusion':
            lidar_feat = self.extract_lidar_feat(points)
        
        len_queue = img.size(1)
        prev_img = img[:, :-1, ...]  # [B, len_queue-1, N, C, H, W]
        img = img[:, -1, ...]  # [B, N, C, H, W]
        
        # 使用 IID 处理当前帧图像
        if self.freeze_iid:
            with torch.no_grad():
                processed_img, albedo, shading = self.process_with_iid(img)
        else:
            processed_img, albedo, shading = self.process_with_iid(img)
        
        # 【重要修复】历史帧也需要经过 IID 处理，保持特征空间一致
        prev_img_metas = copy.deepcopy(img_metas)
        if len_queue > 1:
            # 处理历史帧
            prev_bev = self.obtain_history_bev_with_iid(prev_img, prev_img_metas)
        else:
            prev_bev = None
        
        img_metas = [each[len_queue-1] for each in img_metas]
        
        if not img_metas[0]['prev_bev_exists']:
            prev_bev = None
        
        # 提取特征（使用 IID 处理后的图像）
        img_feats = self.extract_feat(img=processed_img, img_metas=img_metas)
        
        losses = dict()
        
        # 检测损失
        losses_pts = self.forward_pts_train(
            img_feats, lidar_feat, gt_bboxes_3d,
            gt_labels_3d, img_metas,
            gt_bboxes_ignore, prev_bev
        )
        losses.update(losses_pts)
        
        # 可选：IID 正则化损失（防止微调时遗忘）
        if not self.freeze_iid:
            B, N, C, H, W = albedo.shape
            # img 此时已经是 [B, N, C, H, W]，直接使用
            img_01 = self.denormalize_img(img)
            img_flat = img_01.view(B * N, C, H, W)
            albedo_flat = albedo.view(B * N, C, H, W)
            shading_flat = shading.view(B * N, 1, H, W)
            
            with torch.no_grad():
                map_prior = self.map_prior_estimator(img_flat)
            
            # 重建损失（保持 IID 分解能力）
            recon = albedo_flat * shading_flat
            loss_recon = F.mse_loss(recon, img_flat)
            losses['finetune/loss_iid_recon'] = loss_recon * 0.1
        
        return losses
    
    def forward_test(self, img_metas, img=None, points=None, **kwargs):
        """测试前向传播
        
        【重要修复】
        原始 MapTR 测试时 img 是 [N, C, H, W] 格式（4D），直接传给 extract_feat
        extract_feat 中有对 4D 输入的处理逻辑
        
        但是 process_with_iid 需要 5D 输入 [B, N, C, H, W]
        所以我们需要：
        1. 添加 batch 维度进行 IID 处理
        2. 处理完后**不要 squeeze**，保持 [1, N, C, H, W] 格式
        3. 这样 extract_feat 会进入 img.dim() == 5 and img.size(0) == 1 分支
        """
        for var, name in [(img_metas, 'img_metas')]:
            if not isinstance(var, list):
                raise TypeError('{} must be a list, but got {}'.format(name, type(var)))
        
        img = [img] if img is None else img
        points = [points] if points is None else points
        
        if img_metas[0][0]['scene_token'] != self.prev_frame_info['scene_token']:
            self.prev_frame_info['prev_bev'] = None
        
        self.prev_frame_info['scene_token'] = img_metas[0][0]['scene_token']
        
        if not self.video_test_mode:
            self.prev_frame_info['prev_bev'] = None
        
        tmp_pos = copy.deepcopy(img_metas[0][0]['can_bus'][:3])
        tmp_angle = copy.deepcopy(img_metas[0][0]['can_bus'][-1])
        
        if self.prev_frame_info['prev_bev'] is not None:
            img_metas[0][0]['can_bus'][:3] -= self.prev_frame_info['prev_pos']
            img_metas[0][0]['can_bus'][-1] -= self.prev_frame_info['prev_angle']
        else:
            img_metas[0][0]['can_bus'][-1] = 0
            img_metas[0][0]['can_bus'][:3] = 0
        
        # 使用 IID 处理图像
        img_input = img[0]
        
        if img_input is not None:
            # 确保是 5D: [B, N, C, H, W]
            if img_input.dim() == 4:
                img_input = img_input.unsqueeze(0)  # [N, C, H, W] -> [1, N, C, H, W]
            
            with torch.no_grad():
                processed_img, _, _ = self.process_with_iid(img_input)
                # 【关键修复】不要 squeeze！保持 [1, N, C, H, W] 格式
                # 这样 extract_feat 会正确处理
        else:
            processed_img = None
        
        new_prev_bev, bbox_results = self.simple_test(
            img_metas[0], processed_img, points[0],
            prev_bev=self.prev_frame_info['prev_bev'], **kwargs
        )
        
        self.prev_frame_info['prev_pos'] = tmp_pos
        self.prev_frame_info['prev_angle'] = tmp_angle
        self.prev_frame_info['prev_bev'] = new_prev_bev
        
        return bbox_results
    
    def save_iid_weights(self, save_path):
        """保存 IID 网络权重（用于预训练后的保存）"""
        torch.save({
            'iid_network': self.iid_network.state_dict(),
            'map_prior_estimator': self.map_prior_estimator.state_dict() if hasattr(self.map_prior_estimator, 'state_dict') else None,
        }, save_path)
        print(f"Saved IID weights to {save_path}")


class GPULightPerturbation(nn.Module):
    """
    GPU 上的光照扰动
    
    用于自监督预训练：对图像施加不同的光照变换，
    分解出的 Albedo 应该保持一致
    """
    
    def __init__(self,
                 darkness_range=(0.3, 0.9),
                 brightness_range=(1.1, 1.5),
                 gamma_range=(0.7, 1.3),
                 noise_std_range=(0.0, 0.05)):
        super().__init__()
        self.darkness_range = darkness_range
        self.brightness_range = brightness_range
        self.gamma_range = gamma_range
        self.noise_std_range = noise_std_range
    
    def forward(self, img):
        """
        对图像施加随机光照扰动
        
        Args:
            img: [B, C, H, W] 范围 [0, 1]
        
        Returns:
            perturbed: 扰动后的图像
        """
        B = img.shape[0]
        device = img.device
        
        # 随机选择扰动类型
        perturb_type = torch.randint(0, 4, (B,), device=device)
        
        perturbed = img.clone()
        
        for i in range(B):
            if perturb_type[i] == 0:
                # 变暗
                factor = torch.empty(1, device=device).uniform_(*self.darkness_range)
                perturbed[i] = perturbed[i] * factor
            
            elif perturb_type[i] == 1:
                # 变亮
                factor = torch.empty(1, device=device).uniform_(*self.brightness_range)
                perturbed[i] = perturbed[i] * factor
            
            elif perturb_type[i] == 2:
                # Gamma 变换
                gamma = torch.empty(1, device=device).uniform_(*self.gamma_range)
                perturbed[i] = torch.pow(perturbed[i] + 1e-8, gamma)
            
            elif perturb_type[i] == 3:
                # 添加噪声
                std = torch.empty(1, device=device).uniform_(*self.noise_std_range)
                noise = torch.randn_like(perturbed[i]) * std
                perturbed[i] = perturbed[i] + noise
        
        return torch.clamp(perturbed, 0, 1)


@DETECTORS.register_module()
class MPGIDMapTR_Pretrain(MPGIDMapTR):
    """
    专门用于预训练的 MPGID-MapTR
    
    不需要 MapTR 的检测相关组件
    
    支持的消融实验开关:
    - use_multi_view_consistency: 多视角光度一致性
    - use_bev_light_field: BEV 空间光照场
    - use_temporal_consistency: 时序一致性
    """
    
    def __init__(self,
                 iid_cfg=None,
                 map_prior_cfg=None,
                 pretrain_loss_cfg=None,
                 img_norm_cfg=None,
                 init_cfg=None,
                 # ============ ECCV 创新模块开关 ============
                 use_multi_view_consistency=False,
                 use_bev_light_field=False,
                 use_temporal_consistency=False,
                 # 模块配置
                 multi_view_cfg=None,
                 bev_light_field_cfg=None,
                 temporal_cfg=None,
                 **kwargs):
        # 只初始化 IID 相关组件，不初始化 MapTR
        nn.Module.__init__(self)
        
        # mmcv BaseModule 需要的属性
        self._is_init = False
        self.init_cfg = init_cfg
        
        self.training_stage = 'pretrain'
        self.use_albedo_only = True
        self.freeze_iid = False
        
        # 图像归一化配置
        if img_norm_cfg is None:
            self.img_norm_cfg = dict(
                mean=[123.675, 116.28, 103.53],
                std=[58.395, 57.12, 57.375],
                to_rgb=True
            )
        else:
            self.img_norm_cfg = img_norm_cfg
        
        # 构建 IID 网络
        if iid_cfg is not None:
            self.iid_network = self._build_iid_network(iid_cfg.copy())
        else:
            from ...models.enhancers.iid_network import IIDNetworkLite
            self.iid_network = IIDNetworkLite(in_channels=3, base_channels=32)
        
        # 构建 Map Prior 估计器
        if map_prior_cfg is not None:
            self.map_prior_estimator = self._build_map_prior_estimator(map_prior_cfg.copy())
        else:
            from ...models.enhancers.map_prior_estimator import FastMapPriorEstimator
            self.map_prior_estimator = FastMapPriorEstimator()
        
        # 构建预训练损失
        if pretrain_loss_cfg is not None:
            self.pretrain_loss = build_loss(pretrain_loss_cfg)
        else:
            from ...models.losses.iid_pretrain_loss import IIDPretrainLoss
            self.pretrain_loss = IIDPretrainLoss()
        
        # 光照扰动一致性损失
        from ...models.losses.iid_pretrain_loss import LightPerturbationLoss
        self.light_perturb_loss = LightPerturbationLoss(loss_weight=5.0)
        
        # 光照扰动器
        self.light_perturbation = GPULightPerturbation()
        
        # ============ ECCV 级别创新模块 ============
        self.use_multi_view_consistency = use_multi_view_consistency
        self.use_bev_light_field = use_bev_light_field
        self.use_temporal_consistency = use_temporal_consistency
        
        # 初始化多视角一致性模块
        if use_multi_view_consistency:
            from ...models.losses.iid_pretrain_loss import MultiViewPhotometricLoss
            mv_cfg = multi_view_cfg or {}
            self.multi_view_loss = MultiViewPhotometricLoss(
                loss_weight=mv_cfg.get('loss_weight', 1.0),
                overlap_threshold=mv_cfg.get('overlap_threshold', 0.1),
                use_ssim=mv_cfg.get('use_ssim', True),
                ssim_weight=mv_cfg.get('ssim_weight', 0.85),
            )
            print("[MPGID-Pretrain] Multi-View Consistency: ENABLED")
        else:
            self.multi_view_loss = None
        
        # 初始化 BEV 光照场模块
        if use_bev_light_field:
            from ...models.losses.iid_pretrain_loss import BEVLightFieldLoss
            bev_cfg = bev_light_field_cfg or {}
            self.bev_light_field_loss = BEVLightFieldLoss(
                loss_weight=bev_cfg.get('loss_weight', 1.0),
                bev_h=bev_cfg.get('bev_h', 100),
                bev_w=bev_cfg.get('bev_w', 100),
                bev_range=bev_cfg.get('bev_range', [-50, 50, -25, 25]),
                smoothness_weight=bev_cfg.get('smoothness_weight', 0.5),
                consistency_weight=bev_cfg.get('consistency_weight', 0.5),
            )
            print("[MPGID-Pretrain] BEV Light Field: ENABLED")
        else:
            self.bev_light_field_loss = None
        
        # 初始化时序一致性模块
        if use_temporal_consistency:
            from ...models.losses.iid_pretrain_loss import TemporalConsistencyLoss
            temp_cfg = temporal_cfg or {}
            self.temporal_loss = TemporalConsistencyLoss(
                loss_weight=temp_cfg.get('loss_weight', 0.5),
            )
            print("[MPGID-Pretrain] Temporal Consistency: ENABLED")
        else:
            self.temporal_loss = None
    
    def _build_iid_network(self, cfg):
        """构建 IID 网络"""
        from ...models.enhancers.iid_network import IIDNetwork, IIDNetworkLite, RetinexNet
        
        network_type = cfg.pop('type', 'IIDNetworkLite')
        
        if network_type == 'IIDNetwork':
            return IIDNetwork(**cfg)
        elif network_type == 'IIDNetworkLite':
            return IIDNetworkLite(**cfg)
        elif network_type == 'RetinexNet':
            return RetinexNet(**cfg)
        else:
            raise ValueError(f"Unknown IID network type: {network_type}")
    
    def _build_map_prior_estimator(self, cfg):
        """构建 Map Prior 估计器"""
        from ...models.enhancers.map_prior_estimator import MapPriorEstimator, FastMapPriorEstimator
        
        estimator_type = cfg.pop('type', 'FastMapPriorEstimator')
        
        if estimator_type == 'MapPriorEstimator':
            return MapPriorEstimator(**cfg)
        elif estimator_type == 'FastMapPriorEstimator':
            return FastMapPriorEstimator()
        else:
            raise ValueError(f"Unknown Map Prior estimator type: {estimator_type}")
    
    def forward(self, return_loss=True, **kwargs):
        if return_loss:
            return self.forward_pretrain(kwargs.get('img'), kwargs.get('img_metas'))
        else:
            return {}
    
    def forward_pretrain(self, img, img_metas):
        """
        预训练前向传播
        
        支持消融实验的模块开关
        """
        losses = dict()
        
        # 保存完整的时序数据
        full_img = img
        
        # img: [B, queue_len, N, C, H, W] 或 [B, N, C, H, W]
        if img.dim() == 6:
            img = img[:, -1, ...]  # [B, N, C, H, W]
        
        B, N, C, H, W = img.shape
        
        # 反归一化到 [0, 1]
        img_01 = self.denormalize_img(img)
        img_flat = img_01.view(B * N, C, H, W)
        
        # 1. 估计 Map Prior
        with torch.no_grad():
            map_prior = self.map_prior_estimator(img_flat)
        
        # 2. IID 分解
        albedo, shading = self.iid_network(img_flat)
        
        # 3. 计算基础预训练损失
        pretrain_loss, loss_dict = self.pretrain_loss(
            albedo, shading, img_flat, map_prior
        )
        
        for k, v in loss_dict.items():
            losses[f'pretrain/{k}'] = v
        
        # 4. 光照扰动一致性损失
        img_perturbed = self.light_perturbation(img_flat)
        albedo_perturbed, shading_perturbed = self.iid_network(img_perturbed)
        
        loss_perturb = self.light_perturb_loss(albedo, albedo_perturbed, map_prior)
        losses['pretrain/loss_light_perturb'] = loss_perturb
        
        # ============ ECCV 级别创新模块 ============
        
        # 5. 多视角光度一致性损失 [消融实验]
        if self.use_multi_view_consistency and self.multi_view_loss is not None:
            albedo_mv = albedo.view(B, N, C, H, W)
            map_prior_mv = map_prior.view(B, N, 1, H, W)
            loss_mv = self.multi_view_loss(albedo_mv, map_prior_mv)
            losses['pretrain/loss_multi_view'] = loss_mv
        
        # 6. BEV 空间光照场损失 [消融实验]
        if self.use_bev_light_field and self.bev_light_field_loss is not None:
            shading_mv = shading.view(B, N, 1, H, W)
            map_prior_mv = map_prior.view(B, N, 1, H, W)
            loss_bev, bev_loss_dict = self.bev_light_field_loss(shading_mv, map_prior_mv)
            losses['pretrain/loss_bev_light_field'] = loss_bev
            for k, v in bev_loss_dict.items():
                losses[f'pretrain/bev_{k}'] = v
        
        # 7. 时序一致性损失 [消融实验]
        if self.use_temporal_consistency and self.temporal_loss is not None:
            if full_img.dim() == 6 and full_img.size(1) > 1:
                img_prev = full_img[:, -2, ...]
                img_prev_01 = self.denormalize_img(img_prev)
                img_prev_flat = img_prev_01.view(B * N, C, H, W)
                with torch.no_grad():
                    albedo_prev, _ = self.iid_network(img_prev_flat)
                loss_temporal = self.temporal_loss(albedo, albedo_prev)
                losses['pretrain/loss_temporal'] = loss_temporal
        
        return losses
    
    def denormalize_img(self, img):
        """反归一化"""
        mean = torch.tensor(self.img_norm_cfg['mean'], device=img.device).view(1, 1, 3, 1, 1)
        std = torch.tensor(self.img_norm_cfg['std'], device=img.device).view(1, 1, 3, 1, 1)
        
        if img.dim() == 4:
            mean = mean.squeeze(1)
            std = std.squeeze(1)
        
        img_01 = img * std + mean
        img_01 = img_01 / 255.0
        img_01 = torch.clamp(img_01, 0, 1)
        
        return img_01
    
    def save_iid_weights(self, save_path):
        """保存 IID 权重"""
        torch.save({
            'iid_network': self.iid_network.state_dict(),
        }, save_path)
        print(f"Saved IID weights to {save_path}")
