"""
Enhanced MapTR - 带光照增强插件的 MapTR
==========================================

这才是正确的架构：
1. 光照增强器作为前处理插件
2. 可以独立预训练增强器
3. 然后插入到 MapTR 前面

流程：
    原始图像 → [光照增强插件] → 增强图像 → MapTR Backbone → 检测结果
"""

import torch
import torch.nn as nn
from typing import Dict, List, Optional, Tuple
from mmcv.runner import force_fp32, auto_fp16
from mmdet.models import DETECTORS
from mmdet.models.builder import build_backbone, build_neck, build_head

from .maptr import MapTR
from ...models.enhancers.light_enhancer import LightEnhancer, MapTRLightEnhancer


@DETECTORS.register_module()
class EnhancedMapTR(MapTR):
    """
    带光照增强插件的 MapTR
    
    这是正确的做法：
    - 增强器是一个独立的前处理模块
    - 可以可视化增强效果
    - 可以单独预训练增强器
    
    使用方式：
    ```python
    model = dict(
        type='EnhancedMapTR',
        # 光照增强器配置
        light_enhancer=dict(
            method='retinex',
            pretrained='path/to/enhancer.pth',
            freeze=True  # 冻结增强器
        ),
        # 其他 MapTR 配置...
    )
    ```
    """
    
    def __init__(self,
                 # 光照增强器配置
                 light_enhancer: Optional[Dict] = None,
                 use_enhancer: bool = True,
                 # MapTR 基础配置
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 video_test_mode=False,
                 modality='vision',
                 **kwargs):
        
        super().__init__(
            use_grid_mask=use_grid_mask,
            pts_voxel_layer=pts_voxel_layer,
            pts_voxel_encoder=pts_voxel_encoder,
            pts_middle_encoder=pts_middle_encoder,
            pts_fusion_layer=pts_fusion_layer,
            img_backbone=img_backbone,
            pts_backbone=pts_backbone,
            img_neck=img_neck,
            pts_neck=pts_neck,
            pts_bbox_head=pts_bbox_head,
            img_roi_head=img_roi_head,
            img_rpn_head=img_rpn_head,
            train_cfg=train_cfg,
            test_cfg=test_cfg,
            pretrained=pretrained,
            video_test_mode=video_test_mode,
            modality=modality,
            **kwargs
        )
        
        self.use_enhancer = use_enhancer
        
        # 构建光照增强器
        if use_enhancer and light_enhancer is not None:
            enhancer_cfg = light_enhancer.copy()
            method = enhancer_cfg.pop('method', 'retinex')
            pretrained_path = enhancer_cfg.pop('pretrained', None)
            freeze = enhancer_cfg.pop('freeze', False)
            
            self.light_enhancer = MapTRLightEnhancer(
                method=method,
                pretrained=pretrained_path,
                freeze=freeze
            )
        else:
            self.light_enhancer = None
    
    def enhance_images(self, img: torch.Tensor) -> torch.Tensor:
        """
        对输入图像进行光照增强
        
        Args:
            img: [B, N, C, H, W] 或 [B*N, C, H, W] 输入图像
        Returns:
            enhanced: 增强后的图像，维度不变
        """
        if self.light_enhancer is None:
            return img
        
        # 处理维度
        original_shape = img.shape
        if img.dim() == 5:
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
        
        # 增强
        enhanced = self.light_enhancer(img)
        
        # 恢复维度
        if len(original_shape) == 5:
            enhanced = enhanced.view(B, N, C, H, W)
        
        return enhanced
    
    @force_fp32(apply_to=('img', 'points', 'prev_bev'))
    def forward_train(self,
                      points=None,
                      img_metas=None,
                      gt_bboxes_3d=None,
                      gt_labels_3d=None,
                      gt_labels=None,
                      gt_bboxes=None,
                      img=None,
                      proposals=None,
                      gt_bboxes_ignore=None,
                      img_depth=None,
                      img_mask=None,
                      prev_bev=None):
        """
        训练前向传播
        
        关键：先增强图像，再送入检测网络
        """
        # ========== 1. 光照增强 ==========
        if self.use_enhancer and self.light_enhancer is not None:
            # img 的形状是 [B, T, N, C, H, W]
            B, T, N, C, H, W = img.shape
            
            # 对所有帧进行增强
            img_flat = img.view(B * T * N, C, H, W)
            img_enhanced = self.light_enhancer(img_flat)
            img = img_enhanced.view(B, T, N, C, H, W)
        
        # ========== 2. 调用父类的训练逻辑 ==========
        return super().forward_train(
            points=points,
            img_metas=img_metas,
            gt_bboxes_3d=gt_bboxes_3d,
            gt_labels_3d=gt_labels_3d,
            gt_labels=gt_labels,
            gt_bboxes=gt_bboxes,
            img=img,
            proposals=proposals,
            gt_bboxes_ignore=gt_bboxes_ignore,
            img_depth=img_depth,
            img_mask=img_mask,
            prev_bev=prev_bev
        )
    
    def forward_test(self, img_metas, img=None, points=None, **kwargs):
        """
        测试前向传播
        
        同样先增强图像
        """
        # 增强图像
        if self.use_enhancer and self.light_enhancer is not None and img is not None:
            # img 可能是 list 或 tensor
            if isinstance(img, list):
                img = [self._enhance_single(i) for i in img]
            else:
                img = self._enhance_single(img)
        
        return super().forward_test(img_metas, img, points, **kwargs)
    
    def _enhance_single(self, img: torch.Tensor) -> torch.Tensor:
        """增强单个图像"""
        if img.dim() == 5:
            B, N, C, H, W = img.shape
            img_flat = img.view(B * N, C, H, W)
            enhanced = self.light_enhancer(img_flat)
            return enhanced.view(B, N, C, H, W)
        else:
            return self.light_enhancer(img)
    
    def visualize_enhancement(self, img: torch.Tensor, 
                              save_path: Optional[str] = None):
        """
        可视化增强效果
        
        Args:
            img: [B, N, C, H, W] 输入图像
            save_path: 保存路径
        """
        import matplotlib.pyplot as plt
        import numpy as np
        
        # 增强
        enhanced = self.enhance_images(img)
        
        # 反归一化用于可视化
        mean = torch.tensor([123.675, 116.28, 103.53]).view(1, 1, 3, 1, 1)
        std = torch.tensor([58.395, 57.12, 57.375]).view(1, 1, 3, 1, 1)
        
        img_vis = (img * std.to(img.device) + mean.to(img.device)) / 255.0
        enhanced_vis = (enhanced * std.to(enhanced.device) + mean.to(enhanced.device)) / 255.0
        
        img_vis = img_vis.clamp(0, 1).cpu().numpy()
        enhanced_vis = enhanced_vis.clamp(0, 1).cpu().numpy()
        
        # 画图
        B, N = img.shape[:2]
        fig, axes = plt.subplots(2, N, figsize=(4*N, 8))
        
        for i in range(N):
            axes[0, i].imshow(img_vis[0, i].transpose(1, 2, 0))
            axes[0, i].set_title(f'Original View {i}')
            axes[0, i].axis('off')
            
            axes[1, i].imshow(enhanced_vis[0, i].transpose(1, 2, 0))
            axes[1, i].set_title(f'Enhanced View {i}')
            axes[1, i].axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            print(f"Saved enhancement visualization to {save_path}")
        
        plt.close()
        return fig


@DETECTORS.register_module()
class EnhancedMapTR_Pretrain(nn.Module):
    """
    光照增强器预训练模型
    
    使用 Retinex 自监督损失预训练增强器
    
    预训练完成后，增强器可以插入到 EnhancedMapTR 中
    """
    
    def __init__(self,
                 method: str = 'retinex',
                 loss_cfg: Optional[Dict] = None):
        super().__init__()
        
        from ...models.enhancers.light_enhancer import (
            LightEnhancer, LightEnhancerLoss
        )
        
        self.enhancer = LightEnhancer(method=method)
        
        if loss_cfg is None:
            loss_cfg = dict(
                recon_weight=1.0,
                reflectance_smooth_weight=0.1,
                illumination_smooth_weight=0.1,
                color_constancy_weight=0.5
            )
        self.loss_fn = LightEnhancerLoss(**loss_cfg)
        
        # ImageNet 归一化参数
        self.register_buffer('img_mean',
            torch.tensor([123.675, 116.28, 103.53]).view(1, 3, 1, 1))
        self.register_buffer('img_std',
            torch.tensor([58.395, 57.12, 57.375]).view(1, 3, 1, 1))
    
    def forward(self, img, img_metas=None, return_loss=True, **kwargs):
        """前向传播"""
        if return_loss:
            return self.forward_train(img)
        else:
            return self.forward_test(img)
    
    def forward_train(self, img: torch.Tensor) -> Dict[str, torch.Tensor]:
        """训练前向传播"""
        # 处理维度
        if img.dim() == 6:  # [B, T, N, C, H, W]
            B, T, N, C, H, W = img.shape
            img = img.view(B * T * N, C, H, W)
        elif img.dim() == 5:  # [B, N, C, H, W]
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
        
        # 反归一化到 [0, 1]
        img_denorm = (img * self.img_std + self.img_mean) / 255.0
        img_denorm = img_denorm.clamp(0, 1)
        
        # 增强并获取分解结果
        enhanced, decomposition = self.enhancer(img_denorm, return_decomposition=True)
        
        # 计算自监督损失
        if 'reflectance' in decomposition and 'illumination' in decomposition:
            losses = self.loss_fn(
                img_denorm,
                decomposition['reflectance'],
                decomposition['illumination']
            )
        else:
            # Zero-DCE 方法的损失
            losses = {'loss_total': F.l1_loss(enhanced, img_denorm)}
        
        return losses
    
    def forward_test(self, img: torch.Tensor) -> torch.Tensor:
        """测试前向传播"""
        if img.dim() == 5:
            B, N, C, H, W = img.shape
            img = img.view(B * N, C, H, W)
        
        # 反归一化
        img_denorm = (img * self.img_std + self.img_mean) / 255.0
        img_denorm = img_denorm.clamp(0, 1)
        
        # 增强
        enhanced = self.enhancer(img_denorm)
        
        return enhanced
